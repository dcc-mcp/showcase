"""Build or independently verify explicit public projections of private native QA.

No Godot/native process is launched. Raw reports/owners/logs remain unchanged.
Snapshots, actions, world state, previews and proof hashes cannot be redacted.
Historical GDScript is archived as .gd.txt.gz, never as another importable .gd.
"""
from __future__ import annotations

import argparse
import copy
import gzip
import hashlib
import json
from pathlib import Path
import re
import zipfile

MAX_JSON = 64 * 1024 * 1024
PID_KEYS = {"engine_pid", "owned_engine_pid", "owned_pid", "runner_pid", "pid"}
PROTECTED = {"actions", "trace", "world", "actual_world", "core_state", "flags", "completed_events", "slice_complete", "campaign_complete", "floor_transforms", "mode", "seed", "root_seed", "sequence_state", "attempt_index", "preview", "actual_preview", "combat", "initial_full_snapshot", "full_final_snapshot", "full_pre_recovery_snapshot", "full_restored_snapshot", "pre_death_full_snapshot", "failed_full_snapshot", "recovered_full_snapshot", "runtime_identity", "legacy_identity"}
ABSOLUTE = re.compile(r"^[A-Za-z]:[\\/]|^/(?:home|Users)/|^\\\\")
EMBEDDED_ABSOLUTE = re.compile(r"[A-Za-z]:[\\/](?!/)")
SLOT_NONCE = re.compile(r"\b(qa50(?:r|c|sem|bad|replace)?|qa50-original3|qa50-wrong-event-target)-([0-9]+)")


def require(value, message):
    if not value:
        raise ValueError(message)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    with path.open("rb") as file:
        for block in iter(lambda: file.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_json(path):
    opener = gzip.open if path.name.endswith(".gz") else open
    with opener(path, "rb") as file:
        raw = file.read(MAX_JSON + 1)
    require(len(raw) <= MAX_JSON, "Bounded JSON size exceeded")
    return json.loads(raw)


def pointer(parts):
    return "/" + "/".join(str(part).replace("~", "~0").replace("/", "~1") for part in parts)


def parts(value):
    require(value.startswith("/"), "Exact RFC6901 pointer required")
    return [part.replace("~1", "/").replace("~0", "~") for part in value[1:].split("/")]


def at(value, location):
    for key in parts(location):
        value = value[int(key)] if isinstance(value, list) else value[key]
    return value


def projected(value):
    operations = []
    def walk(node, path=(), protected=False):
        if isinstance(node, dict):
            out = {}
            for key, child in node.items():
                require(not ABSOLUTE.search(key), "Absolute dictionary keys need explicit source-metadata handling")
                locked = protected or key in PROTECTED or key.endswith("_sha256")
                if key in PID_KEYS:
                    require(not protected, "PID unexpectedly appears inside an immutable proof subtree")
                    require(not isinstance(child, (dict, list)), "PID removal must be a scalar leaf")
                    operations.append({"op": "remove", "pointer": pointer(path + (key,)), "expected_raw_sha256": digest(child)})
                else:
                    out[key] = walk(child, path + (key,), locked)
            return out
        if isinstance(node, list):
            return [walk(child, path + (index,), protected) for index, child in enumerate(node)]
        if isinstance(node, str):
            public = node
            if ABSOLUTE.search(node):
                public = "[private-host-path:" + hashlib.sha256(node.encode()).hexdigest()[:16] + "]"
            else:
                require(not EMBEDDED_ABSOLUTE.search(node), "An embedded host path needs a reviewed exact replacement: " + pointer(path))
                public = SLOT_NONCE.sub(lambda match: match.group(1) + "-run-" + hashlib.sha256(match.group(2).encode()).hexdigest()[:10], node)
            if public != node:
                require(not protected, "Private metadata unexpectedly appears inside an immutable proof subtree: " + pointer(path))
                operations.append({"op": "replace", "pointer": pointer(path), "expected_raw_sha256": digest(node), "expected_public_sha256": digest(public)})
            return public
        return node
    return walk(value), operations


def proof_roots(value, path=()):
    result = []
    if isinstance(value, dict):
        for key, child in value.items():
            if key in PROTECTED or key.endswith("_sha256"):
                result.append({"pointer": pointer(path + (key,)), "sha256": digest(child)})
            else:
                result.extend(proof_roots(child, path + (key,)))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            result.extend(proof_roots(child, path + (index,)))
    return sorted(result, key=lambda item: item["pointer"])


def verify_projection(raw, public, operations):
    expected = copy.deepcopy(raw)
    seen = set()
    for operation in operations:
        location = operation["pointer"]
        require(location not in seen, "Duplicate projection operation")
        seen.add(location)
        tokens = parts(location)
        require(not any(token in PROTECTED or token.endswith("_sha256") for token in tokens), "Operation changes protected proof semantics")
        before = at(expected, location)
        require(digest(before) == operation["expected_raw_sha256"], "Projection raw scalar binding differs")
        parent = expected
        for key in tokens[:-1]: parent = parent[int(key)] if isinstance(parent, list) else parent[key]
        require(isinstance(parent, dict), "Deleting or replacing an array element is forbidden")
        key = tokens[-1]
        if operation["op"] == "remove":
            require(key in PID_KEYS and not isinstance(before, (dict, list)), "Only explicitly private PID scalar keys may be removed")
            del parent[key]
        elif operation["op"] == "replace":
            after = at(public, location)
            require(isinstance(before, str) and (ABSOLUTE.search(before) or SLOT_NONCE.search(before)), "Replacement is not declared host/slot metadata")
            require(digest(after) == operation["expected_public_sha256"], "Public replacement scalar differs")
            parent[key] = after
        else:
            raise ValueError("Unknown projection operation")
    require(canonical(expected) == canonical(public), "Unlisted change to public evidence")
    require(proof_roots(raw) == proof_roots(public), "Snapshot/actions/world/preview/proof hash changed")
    _, remaining = projected(public)
    require(not remaining, "Public host/PID/test-slot metadata was not fully projected")


def owner_safe(owner, kind):
    common = ["scope", "script", "toolchain", "complete", "priority_requested", "priority", "window", "gui_browser_or_capture", "observed_priority_class", "priority_below_normal_verified", "exit_code", "elapsed_seconds", "stderr_bytes", "stdout_sha256", "stderr_sha256", "sources_unchanged", "original_game_files_unchanged", "measurement_report_exists", "measurement_report_sha256", "measurement_passed", "accepted_by_launcher", "accepted", "report_passed", "fixture", "report", "fixture_sha256", "helper_sha256", "delivered_source_code_and_assets_match_after_import", "original_game_unchanged", "original_new_dependencies_unchanged", "pixels_or_real_input_claimed"]
    result = {key: owner[key] for key in common if key in owner}
    for key in ("source_hashes_before", "source_hashes_after", "source", "protected_original_game_files"):
        if key in owner: result[key] = owner[key]
    if kind == "scene":
        safe = {"step", "observed_priority_class", "below_normal_verified", "exit_code", "elapsed_seconds", "stderr_bytes", "stdout_sha256", "stderr_sha256"}
        result["steps"] = [{key: value for key, value in step.items() if key in safe} for step in owner["steps"]]
    public, _ = projected(result)
    return public


def verify_run(report, owner, kind, current):
    require(owner.get("exit_code", 0) in (0, 1, 2), "Unknown native exit status")
    if not current: return
    require(report.get("passed") is True, "A selected final producer did not pass")
    require(not report.get("errors"), "A selected final producer has errors")
    if kind == "scene":
        require(owner.get("accepted") is True and owner.get("complete") is True and owner.get("delivered_source_code_and_assets_match_after_import") is True and owner.get("original_game_unchanged") is True and owner.get("original_new_dependencies_unchanged") is True, "Final scene/source acceptance is incomplete")
        require(all(step["exit_code"] == 0 and step["stderr_bytes"] == 0 and step["observed_priority_class"] == 16384 for step in owner["steps"]), "Scene import/runtime has real errors or wrong priority")
        require(not report.get("pixels_reviewed") and not report.get("real_keyboard_mouse_touch_tested") and not report.get("browser_tested"), "Headless scene evidence unexpectedly claims visual/input/browser acceptance")
    elif kind == "legacy":
        require(owner.get("accepted") is True and owner.get("exit_code") == 0 and owner.get("stderr_bytes") == 0 and owner.get("observed_priority_class") == 16384, "Legacy fixture native generation did not pass")
        require(report["source_before"] == report["source_after"] and report["fixture_created"] is True, "Legacy source/fixture proof incomplete")
    else:
        require(owner.get("complete") is True and owner.get("exit_code") == 0 and owner.get("stderr_bytes") == 0 and owner.get("sources_unchanged") is True and owner.get("original_game_files_unchanged") is True and owner.get("observed_priority_class") == 16384, "Native owner acceptance is incomplete")
        require(owner["source_hashes_before"] == owner["source_hashes_after"], "Sources changed across the actual engine run")


def write_gzip(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as file:
        with gzip.GzipFile(filename="", mode="wb", fileobj=file, mtime=0) as packed: packed.write(raw)


def summarize_routes(reports, canonical_data):
    seen = set(); layouts = set(); counters = {key: 0 for key in ("cases", "events", "actions", "combat_comparisons", "door_revisits", "stock_refusals", "npc_once_refusals", "native_roundtrips")}
    rows = []
    routes = {route["name"]: route for route in canonical_data["validated_routes"]}
    for mode in ("classic_restart", "practice_checkpoint"):
        report = next(item for item in reports if item.get("suite") == "fifty_actual_authored_route_matrix/v1" and item.get("mode") == mode)
        require(report["passed"] is True and report["measurement_completed"] is True and len(report["cases"]) == 16, "Exactly the two official complete 16-case matrices are required")
        require(report["content_audit"]["unique_nonempty_authored_floors"] == 10, "Authored maps were empty/copies")
        for case in report["cases"]:
            identity = (mode, case["seed"], case["route"])
            require(identity not in seen and case["passed"] is True and case["authoritative_full_action_replay"]["ok"] is True, "Repeated or unverified route case")
            seen.add(identity); route = routes[case["route"]]; trace = case["trace"]
            require([event["event"] for event in trace] == route["events"], "Actual authored route order differs")
            final = case["full_final_snapshot"]; initial = case["initial_full_snapshot"]
            require(final["slice_complete"] is True and final["campaign_complete"] is False and final["core_state"]["won"] is False, "Ten-floor completion was mislabeled fifty-floor victory")
            for field in ("seed", "root_seed", "floor_transforms", "layout_sha256", "layout_signature", "attempt_index"):
                require(final[field] == initial[field], "Ordinary run layout/seed changed")
            for actual, expected in zip(trace, route["ledger"]):
                world = actual["actual_world"]; core = world["core_state"]
                for field in ("hp", "atk", "def", "gold", "keys"): require(core[field] == expected["state"][field], "Actual event budget differs")
                require(world["flags"] == expected["flags"] and world["completed_events"] == expected["completed_events"] and core["purchases"] == expected["purchases"] and len(core["cleared"]) == expected["cleared_count"], "Actual event flags/event/stock/world ledger differs")
            require(sorted(final["core_state"]["cleared"]) == sorted(route["final_cleared"]) and final["flags"] == route["final_flags"] and final["completed_events"] == route["completed_events"] and final["core_state"]["purchases"] == route["final_purchases"], "Actual final world differs from witness")
            flattened = []
            for event in trace:
                commands = copy.deepcopy(event["actions"])
                if event["selected_event_id"]: commands[-1]["selected_event_id"] = event["selected_event_id"]
                flattened.extend(commands)
            require(flattened == final["actions"] and len(flattened) == case["actual_actions"], "Full actual input path/journal coverage differs")
            counters["cases"] += 1; counters["events"] += case["events_checked"]; counters["actions"] += case["actual_actions"]
            for target, field in (("combat_comparisons", "preview_deduction_comparisons"), ("door_revisits", "door_revisit_checks"), ("stock_refusals", "stock_refusal_checks"), ("npc_once_refusals", "npc_once_checks")): counters[target] += case[field]
            counters["native_roundtrips"] += len(case["native_saves"]); layouts.add(initial["layout_sha256"])
            rows.append({"mode": mode, "seed": case["seed"], "route": case["route"], "events": case["events_checked"], "actual_actions": case["actual_actions"], "layout_sha256": initial["layout_sha256"], "final_budget": case["final_budget"], "slice_complete": True, "campaign_complete": False})
    require(len(seen) == 32 and len(layouts) == 8 and counters["combat_comparisons"] == 640, "Official bounded matrix coverage differs")
    return {**counters, "unique_layouts": len(layouts), "policies": 2, "authored_floors": 10, "target_floors": 50, "not_authored_floors": 40, "cases_table": rows, "scope": "32 mode/seed/route cases use eight actual D4 layouts and two authored policies. Calibration probes are not counted. No exhaustive-policy or human-duration claim."}


def build(args):
    spec = read_json(args.spec); root = args.spec.resolve().parent
    evidence = (root / spec.get("evidence_root", ".")).resolve(); repo = (root / spec["repo_root"]).resolve()
    require(not args.output.exists(), "Public output directory must be new")
    sources = []; reports = []; entries = []
    for run in spec["runs"]:
        require(re.fullmatch(r"[a-z0-9_-]+", run["id"]), "Unsafe public evidence label")
        require(not Path(run["report"]).is_absolute() and ".." not in Path(run["report"]).parts and not Path(run["owner"]).is_absolute() and ".." not in Path(run["owner"]).parts, "Evidence references must remain under their declared raw root")
        raw_path = evidence / run["report"]; owner_path = evidence / run["owner"]
        report = read_json(raw_path); owner = read_json(owner_path)
        current = run.get("role", "current") == "current"; kind = run.get("kind", "native")
        verify_run(report, owner, kind, current)
        if "measurement_report_sha256" in owner: require(owner["measurement_report_sha256"] == file_hash(raw_path), "Native owner does not bind actual report bytes")
        if kind == "native" and current:
            for relative, expected in owner["source_hashes_before"].items(): require(file_hash(repo / "scripts/godot_web/stairkeep/game" / relative) == expected, "Current source differs from measured native bytes: " + relative)
        for log_kind in ("stdout", "stderr"):
            if log_kind in run:
                log_path = evidence / run[log_kind]
                if log_kind + "_sha256" in owner: require(file_hash(log_path) == owner[log_kind + "_sha256"], "Native log binding differs")
                if current and log_kind == "stderr": require(log_path.stat().st_size == 0, "A real stderr error cannot be accepted from producer passed alone")
        if current and kind == "scene": require(report["measurement_completed"] is True, "Final scene checks incomplete")
        if current and report.get("suite") == "fifty_full_native_save_semantics/v1": require(report["evidence"]["tamper_cases_tested"] == 14 and report["evidence"]["tamper_coverage_complete"] is True and report["evidence"]["actual_legacy21_slot_tested"] is True, "Partial probe cannot replace the complete genuine-slot semantic suite")
        public, operations = projected(report); verify_projection(report, public, operations)
        member = "reports/" + run["id"] + ".json.gz"
        owner_member = "owners/" + run["id"] + ".json.gz"
        entries.append({"id": run["id"], "role": run.get("role", "current"), "kind": kind, "classification": run.get("classification", "accepted_current"), "raw_file": run["report"], "raw_sha256": file_hash(raw_path), "raw_bytes": raw_path.stat().st_size, "public_member": member, "public_json_sha256": digest(public), "projection_operations": operations, "immutable_proof_roots": proof_roots(report), "owner_raw_file": run["owner"], "owner_raw_sha256": file_hash(owner_path), "owner_public_member": owner_member})
        sources.append((member, canonical(public).encode())); sources.append((owner_member, canonical(owner_safe(owner, kind)).encode()))
        if current: reports.append(report)
    data = read_json(repo / "scripts/godot_web/stairkeep/game/fifty/data/content.json")
    summary = {"schema_version": 1, "suite": "fifty_first_chapter_native_evidence/v1", "passed": True, "routes": summarize_routes(reports, data), "runs": [{"id": entry["id"], "role": entry["role"], "classification": entry["classification"], "raw_sha256": entry["raw_sha256"], "public_member": entry["public_member"]} for entry in entries],
               "current_suite_checks": [{"suite": report.get("suite"), "checks": len(report.get("checks", [])), "passed": report.get("passed"), "elapsed_ms": report.get("elapsed_ms")} for report in reports if report.get("suite") != "fifty_actual_authored_route_matrix/v1"],
               "human_pixels_reviewed": False, "real_keyboard_mouse_touch_tested": False, "browser_play_persistence_tested": False, "scope": "Original 1-10 authored slice toward 50. Headless native checks and direct UI instrumentation only. Failed/historical runs remain classified; no historical producer passed flag overrides real exit/stderr/resource failure. Complete route/world/action/snapshot/preview/hash semantics are unchanged by host-metadata projection."}
    history = []
    for item in spec.get("source_history", []):
        path = evidence / item["path"]; raw = path.read_bytes(); sha = file_hash(path)
        require(sha == item["sha256"], "Historical source snapshot differs from its measured/reconstructed binding")
        member = "source-history/" + path.name + ".txt.gz"
        require(not member.endswith(".gd"), "Historical class_name files must not be importable Godot scripts")
        sources.append((member, raw)); history.append({"member": member, "source_sha256": sha, "provenance": item["provenance"], "bound_run": item.get("bound_run")})
    auxiliary = []
    for item in spec.get("auxiliary", []):
        path = evidence / item["path"]
        raw = read_json(path); public, operations = projected(raw)
        verify_projection(raw, public, operations)
        member = "auxiliary/" + item["id"] + ".json.gz"
        sources.append((member, canonical(public).encode()))
        auxiliary.append({"id": item["id"], "role": item["role"], "raw_file": item["path"], "raw_sha256": file_hash(path), "public_member": member, "public_json_sha256": digest(public), "projection_operations": operations, "immutable_proof_roots": proof_roots(raw)})
    args.output.mkdir(parents=True)
    for member, raw in sources: write_gzip(args.output / member, raw)
    for entry in entries:
        path = args.output / entry["public_member"]; entry["public_member_sha256"] = file_hash(path); entry["public_member_bytes"] = path.stat().st_size
    for item in auxiliary:
        item["public_member_sha256"] = file_hash(args.output / item["public_member"])
    manifest = {"schema_version": 1, "suite": "fifty_public_projection_manifest/v1", "builder_sha256": file_hash(Path(__file__)), "spec_sha256": file_hash(args.spec), "records": entries, "auxiliary": auxiliary, "source_history": history, "member_scope": "archive-root", "raw_reports_modified": False, "raw_owner_reports_distributed": False, "projection_policy": "Only explicit PID scalar removal and exact host-path/test-slot-nonce metadata aliases. Typed gameplay/proof roots are byte-canonical equal after JSON decoding. Historical source is text.gz, not duplicate class_name .gd."}
    (args.output / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (args.output / "validation.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (args.output / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    verify(args.output, evidence)
    if args.archive:
        require(not args.archive.exists() and not args.archive.resolve().is_relative_to(args.output.resolve()), "Archive must be new and outside its source directory")
        with zipfile.ZipFile(args.archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for path in sorted(args.output.rglob("*")):
                if path.is_file(): archive.write(path, path.relative_to(args.output).as_posix())
    print(json.dumps({"passed": True, "records": len(entries), "route_cases": summary["routes"]["cases"], "projection_edits": sum(len(entry["projection_operations"]) for entry in entries), "output": str(args.output), "archive_sha256": file_hash(args.archive) if args.archive else None}))


def verify(public_root, evidence_root):
    manifest = read_json(public_root / "manifest.json")
    for record in manifest["records"]:
        raw_path = evidence_root / record["raw_file"]; public_path = public_root / record["public_member"]
        require(file_hash(raw_path) == record["raw_sha256"] and file_hash(public_path) == record["public_member_sha256"], "Raw/projected artifact bytes changed")
        raw = read_json(raw_path); public = read_json(public_path)
        require(digest(public) == record["public_json_sha256"], "Public JSON binding differs")
        verify_projection(raw, public, record["projection_operations"])
        require(proof_roots(raw) == record["immutable_proof_roots"], "Manifest omits or changes proof-root receipts")
        owner = read_json(evidence_root / record["owner_raw_file"])
        require(file_hash(evidence_root / record["owner_raw_file"]) == record["owner_raw_sha256"], "Private owner bytes changed")
        require(canonical(read_json(public_root / record["owner_public_member"])) == canonical(owner_safe(owner, record["kind"])), "Public owner is not the exact safe whitelist projection")
    for source in manifest["source_history"]:
        path = public_root / source["member"]
        with gzip.open(path, "rb") as file: raw = file.read(MAX_JSON + 1)
        require(hashlib.sha256(raw).hexdigest() == source["source_sha256"] and not path.name.endswith(".gd"), "Historical source bytes/safe extension differ")
    for record in manifest.get("auxiliary", []):
        raw_path = evidence_root / record["raw_file"]; public_path = public_root / record["public_member"]
        require(file_hash(raw_path) == record["raw_sha256"] and file_hash(public_path) == record["public_member_sha256"], "Auxiliary evidence bytes changed")
        raw = read_json(raw_path); public = read_json(public_path)
        require(digest(public) == record["public_json_sha256"], "Auxiliary public JSON binding differs")
        verify_projection(raw, public, record["projection_operations"])
        require(proof_roots(raw) == record["immutable_proof_roots"], "Auxiliary proof root changed")
    return True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    build_parser = sub.add_parser("build"); build_parser.add_argument("--spec", type=Path, required=True); build_parser.add_argument("--output", type=Path, required=True); build_parser.add_argument("--archive", type=Path)
    verifier = sub.add_parser("verify"); verifier.add_argument("--public-root", type=Path, required=True); verifier.add_argument("--raw-root", type=Path, required=True)
    args = parser.parse_args()
    if args.command == "build": build(args)
    else:
        verify(args.public_root, args.raw_root)
        print(json.dumps({"passed": True, "scope": "Exact raw/public projection, private owner whitelist, immutable proof and history-source byte comparisons; no native execution."}))


if __name__ == "__main__": main()
