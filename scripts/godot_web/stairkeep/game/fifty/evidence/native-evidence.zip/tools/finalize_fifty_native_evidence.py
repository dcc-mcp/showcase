"""Finalize an already verified native-only evidence projection; never runs Godot."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import zipfile


README = """# First chapter: native evidence

This bundle records the authored floors 1–10 toward a 50-floor target. Floors 11–50 are not authored. `passed` in `validation.json` describes the bounded native suites and this evidence projection. It does not accept the complete 50-floor campaign, visual quality, real keyboard/mouse/touch play, browser HTTP play, browser persistence, or export. Export receipts are separate.

The parent coordinator executed the original Godot 4.7.2 binary at BelowNormal priority in isolated, task-owned user directories. Current accepted runs have exit 0, empty stderr, unchanged bound sources, and unchanged original game files. These are headless rule tests and direct production UI method instrumentation. No new native process was launched to prepare this archive.

## Actual accepted coverage

| Suite | Scope |
|---|---|
| D4 geometry | 75 checks against an independently generated, previously tested Python geometry oracle; all eight transforms, directions and destination-floor stair endpoints. This does not certify the old Python content schema for this runtime. |
| Runtime smoke | 35 checks: explicit modes, combat boundaries, typed attachments, full world reset/checkpoint behavior, native slots, and current failed Classic import/load refusal. |
| Authored routes | 32 actual cases: two modes × seeds 1–8 × two authored policies; **eight unique layouts**, 3,344 resource events and 19,108 successful API actions. All end with `slice_complete=true`, `core_state.won=false`, `campaign_complete=false`. |
| Route assertions | 640 preview/actual combat comparisons; 352 door revisits with one key charge; 144 finite-stock refusals; 96 exhausted NPC interactions; two full native F5 roundtrips. Each event's real action path is retained. |
| Finite combat death | 16 checks across both modes. A legal low-supply route reaches F3 at HP 111, damage 160 and terminal HP −49. Ordinary/unconfirmed attacks leave state unchanged; explicit death and mode-specific recovery use the same preview. |
| Save semantics | 26 checks and all 14 mutations: HP, gold, flags, stock, checkpoint, actions, history, consumed IDs, recovery count, future reference, foreign identity, future version, mode and checksum. Illegal changes are rejected even after attacker-recomputed checksums; current state and owned disk bytes stay unchanged. |
| Save update | Five checks of actual valid existing-slot replacement and fresh full readback. This is a single-writer test, not a power-loss certification. |
| Direction event | 12 checks over two seeds, using an isolated synthetic standalone enter event: wrong direction does not reward, correct direction rewards once, and replay validates. Production content events remain interaction events. |
| Legacy fixture | A genuine, newly owned old-21 Save v2 file was created and freshly loaded with the old authoritative runtime, then rejected by the new save namespace. No pre-existing user slot was accessed. An old-3 owned slot was also rejected. |
| Final scene | 26 checks after real resource import: settled node layout, resources, no default mode, direct UI actions, failed/completed recovery priority, finite death display, quantities and typed available-event effects. This is not a pixel or real-input acceptance. |

The route collector and this builder independently compare each actual ledger, final resources/flags/events/purchases/cleared sets, unchanged run seed/transforms/layout, and the complete action sequence. Blade ends at HP 77 / ATK 57 / DEF 19 / gold 418; Bulwark ends at HP 183 / ATK 45 / DEF 28 / gold 333. Both have zero yellow and blue keys. These two authored policies do not prove arbitrary strategies or hours of play. Complete checkpoint world restoration retains the documented audit transaction history. Failed Classic blocks old-slot import in the current instance; a fresh explicitly selected instance may resume a manual save. No persistent permadeath guarantee is claimed.

## Historical failures retained

Five historical run reports remain classified separately from the ten current records. The initial Classic assertion wrongly expected empty session audit after restart; the required whole-session journal was preserved. The attached-enter-event test found one real runtime boundary defect. Its second old fixture overlapped an existing object, so that old refusal is not evidence of a second typed guard; the corrected legal fixture is a later green check. The initial scene producer's pass flag was rejected because actual stderr contained 581,254 bytes of missing-import resource errors. A separate scene driver used a wrong Save method name and produced no scene report; the auxiliary assessment records the actual driver failure. The completed-and-failed modal case was red before the recovery-priority fix, then green. Final quantity display checks use the final view revision. Superseded green runs and probes are not additional independent cases.

Historical `.gd` bytes are stored as `.gd.txt.gz`, avoiding duplicate Godot `class_name` registration. Each source has an exact SHA and a provenance label. Some old sources were reconstructed later and matched the measured SHA; that is explicitly different from a contemporaneous capture. Final frozen source copies were made after measurement and are labelled accordingly.

## Evidence and privacy projection

`manifest.json` inside the ZIP uses archive-root member names. It binds every original raw report SHA, projected canonical JSON SHA, compressed member SHA, exact RFC6901 leaf removal/replacement, and immutable proof-root hashes. Original private reports are unchanged and are not distributed. Public owner receipts use a fixed safe whitelist, preserving source and process outcome evidence while omitting host paths/PIDs. Exact test-slot nonce aliases affect metadata only. Seeds, modes, actions, snapshots, world/core state, flags, previews, combat results, and proof hashes are unchanged. Hashes of original slot files still identify the original bytes; metadata aliases do not claim to create equivalent renamed files.

`summary.json` and `validation.json` contain the re-counted cases and bounded scope. Gzip report members can be read with any gzip/JSON tool. `source-history/` contains source bytes, and `auxiliary/` retains the genuine legacy fixture, historical assessments and attributed static reviews. The content author reviewed route records separately from the runtime implementation; the runtime author reviewed the final view separately from its implementation. These notes are attributed static reviews, not native executions by those reviewers.

`tools/build_fifty_qa_evidence.py verify --public-root EXTRACTED --raw-root PRIVATE_OUTPUT` repeats exact raw/public and protected-tree comparisons when the original private output is available. `tools/spec.json` records the private-source relative names and source bindings. Public-only integrity can be checked against the outer delivery manifest and ZIP CRC, then the internal member SHA values. The delivery manifest beside the ZIP adds its SHA/CRC receipt without a circular self-hash.
"""


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_new(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != raw:
            raise ValueError("Refusing to replace a different existing artifact: " + str(path))
    else:
        path.write_bytes(raw)


def dumped(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", type=Path, required=True)
    parser.add_argument("--raw-root", type=Path, required=True)
    parser.add_argument("--builder", type=Path, required=True)
    parser.add_argument("--spec", type=Path, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--delivery", type=Path, required=True)
    args = parser.parse_args()
    if args.archive.exists():
        raise ValueError("New archive path required")
    module_spec = importlib.util.spec_from_file_location("fifty_evidence_builder", args.builder)
    builder = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(builder)
    builder.verify(args.stage, args.raw_root)
    manifest_path = args.stage / "manifest.json"
    manifest = json.loads(manifest_path.read_bytes())
    if "bundle_files" in manifest:
        raise ValueError("Stage was already finalized")
    assert sha(args.builder) == manifest["builder_sha256"]
    assert sha(args.spec) == manifest["spec_sha256"]
    write_new(args.stage / "README.md", README.encode())
    extra = {"tools/build_fifty_qa_evidence.py": args.builder,
             "tools/spec.json": args.spec,
             "tools/finalize_fifty_native_evidence.py": Path(__file__)}
    for member, path in extra.items():
        write_new(args.stage / member, path.read_bytes())
    validation = json.loads((args.stage / "validation.json").read_bytes())
    records = manifest["records"] + manifest.get("auxiliary", [])
    validation["publication_projection"] = {
        "passed": True, "raw_and_public_typed_tree_comparison": True,
        "raw_reports_modified": False, "owner_receipts_exact_safe_whitelist": True,
        "report_records": len(manifest["records"]),
        "auxiliary_records": len(manifest.get("auxiliary", [])),
        "history_source_byte_matches": len(manifest["source_history"]),
        "exact_leaf_projection_operations": sum(len(r["projection_operations"]) for r in records),
        "protected_subtrees_equal": sum(len(r["immutable_proof_roots"]) for r in records),
        "scope": "Native bundle and privacy projection only; not visual, browser, export or 50-floor acceptance."}
    (args.stage / "validation.json").write_bytes(dumped(validation))
    manifest["bundle_files"] = [{"member": p.relative_to(args.stage).as_posix(), "sha256": sha(p), "bytes": p.stat().st_size}
        for p in sorted(args.stage.rglob("*")) if p.is_file() and p != manifest_path]
    manifest_path.write_bytes(dumped(manifest))
    builder.verify(args.stage, args.raw_root)
    for item in manifest["bundle_files"]:
        assert sha(args.stage / item["member"]) == item["sha256"]
    args.archive.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(args.stage.rglob("*")):
            if path.is_file():
                member = path.relative_to(args.stage).as_posix()
                assert not member.endswith(".gd")
                info = zipfile.ZipInfo(member, (1980, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                archive.writestr(info, path.read_bytes(), compresslevel=9)
    with zipfile.ZipFile(args.archive) as archive:
        assert archive.testzip() is None
        members = archive.namelist()
        assert len(members) == len(set(members))
        assert set(members) == {p.relative_to(args.stage).as_posix() for p in args.stage.rglob("*") if p.is_file()}
    delivery_manifest = dict(manifest)
    delivery_manifest["delivery"] = {"member": "native-evidence.zip", "sha256": sha(args.archive),
        "bytes": args.archive.stat().st_size, "crc_all_members_passed": True,
        "members": len(members), "internal_manifest_sha256": sha(manifest_path),
        "internal_validation_sha256": sha(args.stage / "validation.json"),
        "README_sha256": sha(args.stage / "README.md"), "member_scope": "archive-root"}
    args.delivery.mkdir(parents=True, exist_ok=True)
    write_new(args.delivery / "native-evidence.zip", args.archive.read_bytes())
    write_new(args.delivery / "manifest.json", dumped(delivery_manifest))
    write_new(args.delivery / "validation.json", (args.stage / "validation.json").read_bytes())
    write_new(args.delivery / "README.md", (args.stage / "README.md").read_bytes())
    print(json.dumps({"passed": True, "delivery": str(args.delivery), "archive": delivery_manifest["delivery"],
        "manifest_sha256": sha(args.delivery / "manifest.json"),
        "validation_sha256": sha(args.delivery / "validation.json"),
        "projection": validation["publication_projection"]}))


if __name__ == "__main__":
    main()
