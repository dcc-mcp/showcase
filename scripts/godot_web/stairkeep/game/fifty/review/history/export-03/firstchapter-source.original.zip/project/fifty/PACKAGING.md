# First-chapter source and Web preparation

Use the existing Godot project. The original `project.godot`, main scene, old
three-floor export, 21-floor laboratory, evidence and shared templates stay
unchanged. The coordinator's `prepare_firstchapter_export.py prepare` copies a
bounded production allowlist to a new owned output. Only that copy receives the
preview main scene `res://fifty/view/preview.tscn`, independent preview app name
and Web preset. Its source ZIP includes the portable project, recipes and full
license/source notices, without tests/tools/evidence or private QA reports.

The existing official 4.7.2 no-thread release ZIP is 10,245,903 bytes, SHA-256
`d3ee2f08cef0cf3cf6678a6355a92a8db48ccdd35cbd2e8bfd5f0e8a0b4032a0`.
Selected template and notice bytes are freshly checked against the inherited
whole-archive verification receipt. No download, install or template upgrade is
part of this preparation. MIT engine notices, bundled third-party copyright,
Kenney CC0, pinned official demo MIT and project MIT notices are retained.

The preset uses Compatibility, GDScript, `script_export_mode=0`,
`variant/thread_support=false`, `variant/extensions_support=false`, and PWA off.
Text mode is necessary because the runtime hashes the original `res://*.gd`
bytes. The official 4.7.2 enum assigns Text to 0; the GDScript export plugin
converts other modes to `.gdc`. See the official
[preset enum](https://raw.githubusercontent.com/godotengine/godot/4.7.2-stable/editor/export/editor_export_preset.h)
and [export plugin](https://raw.githubusercontent.com/godotengine/godot/4.7.2-stable/modules/gdscript/register_types.cpp).
The complete original `content.json`, including witnesses, is copied byte for
byte. Size reduction must not change authoritative content or rule hashes.

Only the explicit `export` subcommand starts the coordinator-provided existing
Godot executable. It isolates APPDATA/LOCALAPPDATA/XDG caches inside the owned
output, uses the verified custom templates, and runs headless import followed by
headless Web release export. It verifies actual JS/WASM bytes against the
selected template, confirms no thread pools or service worker, retains notices,
and rechecks original sources and preset. Nothing is published or served.
Each version/import/export phase uses a hidden BelowNormal process, records
actual WinAPI priority/process times and dynamic private owner receipts, and
requires exit 0 with stderr 0. There is no automatic deadline or process kill;
the coordinator observes progress and owns intervention. Sources and declared
protected files are checked before and after every phase.

The external `probe_firstchapter_pck.gd` has two coordinator-executed phases.
First capture real native runtime identities and complete seed-1 snapshots for
both explicit modes from the original project. Then run the original engine
with `--main-pack <new index.pck>` and the external script, from an empty owned
working directory with no `--path`. That phase verifies packed raw GD/data/
license/source bytes, confirms the old main scene and QA directories are absent,
exercises explicit mode selection, and compares complete identity/snapshot
results with the real native reference. This prevents a source-project fallback
from being mistaken for PCK validation.

Preparation is not an export receipt. Export and a headless PCK probe are not
browser HTTP play, native pixel/input, CJK glyph, audio or Web storage acceptance.
Floors 1–10 are a first chapter toward a 50-floor target; floors 11–50 are not
implemented. Original concepts are reference images, not new runtime captures.
