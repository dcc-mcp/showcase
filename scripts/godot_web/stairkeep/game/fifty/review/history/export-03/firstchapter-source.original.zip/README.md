# Stairkeep first chapter source

This is a staged copy of the existing project with a separate preview name and main scene. Floors 1–10 are implemented toward a 50-floor target. Run `project/project.godot` with Godot 4.7.2.stable.official.ed1daf0bf. Tests/tools/evidence and historical projects are not bundled. Full QA sources remain in the reviewed repository.

Export uses verified official local no-thread templates, GDScript Text mode 0, Compatibility, no extensions/PWA/service worker. Provide an existing verified template directory to the recipe prepare command; it rewrites only a new copy. The portable preset has no private absolute template paths. Browser play, native pixels/input, CJK glyphs, audio and durable Web saves are not accepted here.
