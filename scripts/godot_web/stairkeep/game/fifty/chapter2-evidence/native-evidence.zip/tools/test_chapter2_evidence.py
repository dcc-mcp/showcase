"""Bounded, rerunnable positive/negative tests for the chapter-two evidence collector.
Only JSON/source bytes are read. No Godot, network, GUI, installed binary inspection.
"""
from __future__ import annotations
import argparse
import copy
import json
from pathlib import Path
import build_chapter2_evidence as builder
import chapter2_evidence_projection as projection


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--spec", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    if args.output.exists(): raise ValueError("New self-test report required")
    spec, raw_root, project = builder.load_spec(args.spec)
    checks = []

    def test(name, callback, reject=False):
        try:
            callback()
        except ValueError as error:
            checks.append({"name": name, "passed": reject, "expected_rejection": reject, "observed": type(error).__name__, "reason": str(error)[:300]})
        else:
            checks.append({"name": name, "passed": not reject, "expected_rejection": reject})

    raw = {"engine_pid": 12345, "native_path": "user://qa2profile-12345.json", "host": "P:/private-owned/report.json",
           "seed": "00000001", "world": {"core_state": {"hp": 77, "keys": {"yellow": 0}}, "flags": {"x": True}},
           "trace": [{"actions": [{"kind": "move", "dx": 1, "dy": 0}]}],
           "ordinary_play_key_cut_proof": {"complete": True, "reachable_cells_floor_id_x_y": [[1, 2, 3]], "goal_or_adjacent_relaxed_reachable": False}}
    public, operations = projection.projected(raw)
    test("exact_metadata_projection_passes", lambda: projection.verify_projection(raw, public, operations))

    def changed(path, value):
        altered = copy.deepcopy(public)
        cursor = altered
        for key in path[:-1]: cursor = cursor[key]
        cursor[path[-1]] = value
        projection.verify_projection(raw, altered, operations)

    test("hp_rewrite_rejected", lambda: changed(["world", "core_state", "hp"], 78), True)
    test("bool_to_integer_rewrite_rejected", lambda: changed(["world", "flags", "x"], 1), True)
    test("seed_rewrite_rejected", lambda: changed(["seed"], "00000002"), True)
    test("actual_action_rewrite_rejected", lambda: changed(["trace", 0, "actions", 0, "dx"], -1), True)
    test("key_cut_graph_rewrite_rejected", lambda: changed(["ordinary_play_key_cut_proof", "reachable_cells_floor_id_x_y", 0, 1], 99), True)
    test("undeclared_metadata_change_rejected", lambda: projection.verify_projection(raw, public, operations[:-1]), True)
    broken = copy.deepcopy(operations); broken[0]["expected_raw_sha256"] = "0" * 64
    test("wrong_raw_leaf_binding_rejected", lambda: projection.verify_projection(raw, public, broken), True)
    test("repeated_leaf_operation_rejected", lambda: projection.verify_projection(raw, public, operations + operations[:1]), True)
    test("array_element_deletion_rejected", lambda: projection.verify_projection(raw, public, operations + [{"op": "remove", "pointer": "/trace/0", "expected_raw_sha256": projection.digest(raw["trace"][0])}]), True)
    unknown = copy.deepcopy(operations); unknown[0]["op"] = "truncate"
    test("unknown_projection_opcode_rejected", lambda: projection.verify_projection(raw, public, unknown), True)
    test("private_field_inside_world_refuses_projection", lambda: projection.projected({"world": {"engine_pid": 1}}), True)

    runs = {run["role"]: run for run in spec["runs"]}
    matrices = {role: builder.read_json(builder.bounded_path(raw_root, runs[role]["report"])) for role in ("matrix_classic", "matrix_practice")}
    data = builder.read_json(project / "fifty/data/chapter2-content.json")
    matrix_summary = builder.summarize_matrix(matrices, data)
    test("final_exact_32_matrix_passes", lambda: builder.require(matrix_summary["cases"] == 32 and matrix_summary["actions"] == 44512 and matrix_summary["events"] == 6432 and matrix_summary["preview_actual_comparisons"] == 1280 and matrix_summary["unique_layouts"] == 8, "Final actual coverage changed"))
    partial = dict(matrices["matrix_practice"]); partial["cases"] = partial["cases"][:2]
    test("two_case_probe_cannot_substitute_for_matrix", lambda: builder.summarize_matrix({**matrices, "matrix_practice": partial}, data), True)
    duplicate = dict(matrices["matrix_practice"]); duplicate["cases"] = list(duplicate["cases"]); duplicate["cases"][-1] = duplicate["cases"][0]
    test("repeated_case_cannot_count_as_independent_sample", lambda: builder.summarize_matrix({**matrices, "matrix_practice": duplicate}, data), True)
    case_incomplete = dict(matrices["matrix_classic"]); case_incomplete["completed_cases"] = 15
    test("incomplete_matrix_footer_rejected", lambda: builder.summarize_matrix({**matrices, "matrix_classic": case_incomplete}, data), True)
    old_owner = builder.read_json(raw_root / "chapter2-route-keen-classic-probe-01.owner.json")
    old_report = builder.read_json(raw_root / "chapter2-route-keen-classic-probe-01.json")
    test("old_pre_cache_source_cannot_count_as_current", lambda: builder.verify_current_sources(old_report, old_owner, project, spec["expected_current_sources"]), True)
    role = "matrix_classic"; report = matrices[role]
    owner = builder.read_json(builder.bounded_path(raw_root, runs[role]["owner"]))
    raw_sha = builder.file_hash(builder.bounded_path(raw_root, runs[role]["report"]))
    bad_owner = dict(owner); bad_owner["complete"] = False
    test("live_owner_cannot_be_terminal_evidence", lambda: builder.verify_owner(report, bad_owner, raw_sha, True), True)
    bad_owner = dict(owner); bad_owner["stderr_bytes"] = 1
    test("producer_pass_does_not_override_actual_stderr", lambda: builder.verify_owner(report, bad_owner, raw_sha, True), True)
    bad_owner = dict(owner); bad_owner["report_sha256"] = "0" * 64
    test("wrong_report_receipt_binding_rejected", lambda: builder.verify_owner(report, bad_owner, raw_sha, True), True)
    missing = copy.deepcopy(spec)
    for run in missing["runs"]:
        if run["role"] == "scene": run["report"] = "__deliberately_missing_scene_for_negative_test__.json"
    test("missing_scene_never_claims_readiness", lambda: builder.require(builder.readiness(missing, raw_root)["ready_for_validation"] is False, "Missing role became ready"))
    test("actual_cache_AB_same_commands_world_passes", lambda: builder.validate_cache_ab(raw_root, spec))
    test("original_first_chapter_artifacts_unchanged", lambda: builder.protected_artifacts(spec, args.spec))
    actual_save = builder.read_json(raw_root / "chapter2-save-profiles-02.json")
    work, omissions = builder.prepare_projection(actual_save, "save_profiles")
    projected_save, leaf_operations = projection.projected(work)
    test("four_exact_duplicate_carriers_preserve_primary_worlds", lambda: builder.verify_report_projection(actual_save, projected_save, "save_profiles", leaf_operations, omissions))
    altered_save = copy.deepcopy(actual_save); altered_save["evidence"]["full_first_snapshot"]["core_state"]["hp"] += 1
    test("carrier_duplicate_mismatch_rejected", lambda: builder.prepare_projection(altered_save, "save_profiles"), True)
    test("opaque_carrier_in_unapproved_role_rejected", lambda: builder.prepare_projection(actual_save, "auxiliary"), True)
    tampered_omissions = copy.deepcopy(omissions); tampered_omissions[0]["original_canonical_payload_sha256"] = "0" * 64
    test("false_opaque_carrier_receipt_rejected", lambda: builder.verify_report_projection(actual_save, projected_save, "save_profiles", leaf_operations, tampered_omissions), True)
    scene_run = runs["scene"]; gate = builder.read_json(raw_root / scene_run["report"]); gate_owner = builder.read_json(raw_root / scene_run["owner"])
    test("explicit_scene_denial_is_blocked_not_executed", lambda: builder.verify_blocked_scene(gate, gate_owner, spec["expected_current_sources"]))
    false_gate = dict(gate); false_gate["scene_executed"] = True
    test("blocked_scene_cannot_claim_execution", lambda: builder.verify_blocked_scene(false_gate, gate_owner, spec["expected_current_sources"]), True)
    test("measured_test_capture_allows_only_declared_unexecuted_QA_followup", lambda: builder.verify_current_sources(report, owner, project, spec["expected_current_sources"], spec.get("measured_source_snapshots"), raw_root))
    result = {"suite": "chapter2_evidence_bounded_collector_selftests/v1", "passed": all(item["passed"] for item in checks),
              "checks": checks, "check_count": len(checks), "expected_negative_cases": sum(item["expected_rejection"] for item in checks),
              "builder_sha256": builder.file_hash(Path(builder.__file__)), "projection_core_sha256": builder.file_hash(Path(projection.__file__)),
              "test_source_sha256": builder.file_hash(Path(__file__)), "spec_sha256": builder.file_hash(args.spec),
              "native_runs": 0, "scope": "Bounded Python evidence/schema/privacy tests, not game runtime/input/visual tests. Controlled bad in-memory copies never modify raw files or original first-chapter evidence."}
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": result["passed"], "checks": len(checks), "expected_negative_cases": result["expected_negative_cases"], "report": str(args.output)}))
    if not result["passed"]: raise SystemExit(1)


if __name__ == "__main__": main()
