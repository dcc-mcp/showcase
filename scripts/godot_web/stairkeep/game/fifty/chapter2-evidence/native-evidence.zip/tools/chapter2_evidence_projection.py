"""Chapter-two typed evidence projection core, derived from the frozen v1 builder.
No v1 evidence file is modified. Protect new chapter-two state and proof roots.

No Godot/native process is launched. Raw reports/owners/logs remain unchanged.
Snapshots, actions, world state, previews and proof hashes cannot be redacted.
Historical GDScript is archived as .gd.txt.gz, never as another importable .gd.
"""
from __future__ import annotations

import argparse
import copy
import gzip
import hashlib
import json
from pathlib import Path
import re
import zipfile

MAX_JSON = 64 * 1024 * 1024
PRIVATE_SCALAR_KEYS = {"engine_pid", "owned_engine_pid", "owned_pid", "runner_pid", "owned_launcher_pid", "pid", "raw_traceback"}
PROTECTED = {"full_bad_branch_snapshot", "full_terminal_state", "checkpoint_world", "full_first_snapshot", "full_second_snapshot", "initial_winning_witness", "ordinary_play_key_cut_proof", "prefix_actual_trace", "bad_branch_actual_trace", "recovery_actual_trace", "suffix", "actions", "trace", "world", "actual_world", "core_state", "flags", "completed_events", "slice_complete", "campaign_complete", "floor_transforms", "mode", "seed", "root_seed", "sequence_state", "attempt_index", "preview", "actual_preview", "combat", "initial_full_snapshot", "full_final_snapshot", "full_pre_recovery_snapshot", "full_restored_snapshot", "pre_death_full_snapshot", "failed_full_snapshot", "recovered_full_snapshot", "runtime_identity", "legacy_identity"}
ABSOLUTE = re.compile(r"^[A-Za-z]:[\\/]|^/(?:home|Users)/|^\\\\")
EMBEDDED_ABSOLUTE = re.compile(r"[A-Za-z]:[\\/](?!/)")
SLOT_NONCE = re.compile(r"\b(qa50(?:r|c|sem|bad|replace|c2)?|qa50-original3|qa50-wrong-event-target|qa2legacy|qa2profile|qa2foreign)-([0-9]+)")


def require(value, message):
    if not value:
        raise ValueError(message)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    with path.open("rb") as file:
        for block in iter(lambda: file.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_json(path):
    opener = gzip.open if path.name.endswith(".gz") else open
    with opener(path, "rb") as file:
        raw = file.read(MAX_JSON + 1)
    require(len(raw) <= MAX_JSON, "Bounded JSON size exceeded")
    return json.loads(raw)


def pointer(parts):
    return "/" + "/".join(str(part).replace("~", "~0").replace("/", "~1") for part in parts)


def parts(value):
    require(value.startswith("/"), "Exact RFC6901 pointer required")
    return [part.replace("~1", "/").replace("~0", "~") for part in value[1:].split("/")]


def at(value, location):
    for key in parts(location):
        value = value[int(key)] if isinstance(value, list) else value[key]
    return value


def projected(value):
    operations = []
    def walk(node, path=(), protected=False):
        if isinstance(node, dict):
            out = {}
            for key, child in node.items():
                require(not ABSOLUTE.search(key), "Absolute dictionary keys need explicit source-metadata handling")
                locked = protected or key in PROTECTED or key.endswith("_sha256")
                if key in PRIVATE_SCALAR_KEYS:
                    require(not protected, "PID unexpectedly appears inside an immutable proof subtree")
                    require(not isinstance(child, (dict, list)), "PID removal must be a scalar leaf")
                    operations.append({"op": "remove", "pointer": pointer(path + (key,)), "expected_raw_sha256": digest(child)})
                else:
                    out[key] = walk(child, path + (key,), locked)
            return out
        if isinstance(node, list):
            return [walk(child, path + (index,), protected) for index, child in enumerate(node)]
        if isinstance(node, str):
            public = node
            if ABSOLUTE.search(node):
                public = "[private-host-path:" + hashlib.sha256(node.encode()).hexdigest()[:16] + "]"
            else:
                require(not EMBEDDED_ABSOLUTE.search(node), "An embedded host path needs a reviewed exact replacement: " + pointer(path))
                public = SLOT_NONCE.sub(lambda match: match.group(1) + "-run-" + hashlib.sha256(match.group(2).encode()).hexdigest()[:10], node)
            if public != node:
                require(not protected, "Private metadata unexpectedly appears inside an immutable proof subtree: " + pointer(path))
                operations.append({"op": "replace", "pointer": pointer(path), "expected_raw_sha256": digest(node), "expected_public_sha256": digest(public)})
            return public
        return node
    return walk(value), operations


def proof_roots(value, path=()):
    result = []
    if isinstance(value, dict):
        for key, child in value.items():
            if key in PROTECTED or key.endswith("_sha256"):
                result.append({"pointer": pointer(path + (key,)), "sha256": digest(child)})
            else:
                result.extend(proof_roots(child, path + (key,)))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            result.extend(proof_roots(child, path + (index,)))
    return sorted(result, key=lambda item: item["pointer"])


def verify_projection(raw, public, operations):
    expected = copy.deepcopy(raw)
    seen = set()
    for operation in operations:
        location = operation["pointer"]
        require(location not in seen, "Duplicate projection operation")
        seen.add(location)
        tokens = parts(location)
        require(not any(token in PROTECTED or token.endswith("_sha256") for token in tokens), "Operation changes protected proof semantics")
        before = at(expected, location)
        require(digest(before) == operation["expected_raw_sha256"], "Projection raw scalar binding differs")
        parent = expected
        for key in tokens[:-1]: parent = parent[int(key)] if isinstance(parent, list) else parent[key]
        require(isinstance(parent, dict), "Deleting or replacing an array element is forbidden")
        key = tokens[-1]
        if operation["op"] == "remove":
            require(key in PRIVATE_SCALAR_KEYS and not isinstance(before, (dict, list)), "Only explicitly private metadata scalar keys may be removed")
            del parent[key]
        elif operation["op"] == "replace":
            after = at(public, location)
            require(isinstance(before, str) and (ABSOLUTE.search(before) or SLOT_NONCE.search(before)), "Replacement is not declared host/slot metadata")
            require(digest(after) == operation["expected_public_sha256"], "Public replacement scalar differs")
            parent[key] = after
        else:
            raise ValueError("Unknown projection operation")
    require(canonical(expected) == canonical(public), "Unlisted change to public evidence")
    require(proof_roots(raw) == proof_roots(public), "Snapshot/actions/world/preview/proof hash changed")
    _, remaining = projected(public)
    require(not remaining, "Public host/PID/test-slot metadata was not fully projected")


DERIVED_FROM_V1_BUILDER_SHA256 = '5ddd57997f76a679d68cb28bb940af97e8c8a7eb7efc6fb9a8c392dfe54013ba'
