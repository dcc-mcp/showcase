"""Seal the partial chapter-two logic evidence. No native/GUI/network action."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile
import build_chapter2_evidence as builder

README = """# Chapter two: logic passed; scene blocked

`overall_scope=logic_passed_scene_blocked`, `logic_passed=true`, `full_acceptance=false`. Top-level `passed=false` intentionally retains the missing scene acceptance. This is an original authored 1–20 slice toward 50; floors 21–50 are unmade. The name 阶塔 remains provisional.

The parent coordinator executed the original engine for the completed logic runs. No native, GUI, browser, network or installed-binary inspection was performed to build this evidence. Original private reports are byte-preserved and bound by SHA. The original first-chapter evidence ZIP and its three accompanying files were hashed before and after this new package and remain unchanged.

## What actually passed

- Two final-source matrices: Classic 16 plus Practice 16, seeds 1–8 × policies `keen`/`reserve`. These are 32 distinct mode/seed/policy cases with **eight layouts**, 6,432 resource events, 44,512 actual API actions and 1,280 preview/actual combat comparisons.
- 576 opened-gate revisits, 992 two-way stair roundtrips, 320 finite-stock refusals and 224 exhausted NPC interactions. All authored event resources, flags, completed events, stock and final cleared sets were rechecked against the canonical ledger. Every event path flattens to its complete actual action journal.
- Keen ends HP 227 / ATK 111 / DEF 32 / gold 733; Reserve ends HP 244 / ATK 106 / DEF 34 / gold 733. Both have zero yellow/blue keys, `slice_complete=true`, `core_state.won=false` and `campaign_complete=false`.
- Two real checkpoint recoveries (20 assertions): F11/F15 restore complete world/resources/stock/flags/events and the configured checkpoint prefix, then actual API suffixes reach F20. Audit transactions are retained. F11 discards captured F15; F15 has no later configured checkpoint to discard.
- Two real bad-key-choice cases (28 assertions): complete initial prefixes and bad branches are executed without resource setters or teleporting. The later worlds have a complete conservative cross-floor yellow-key cut certificate. The same initial seed has a separately replayed winning witness; this is **not initial unsatisfiability**. Explicit abandonment is labelled `abandoned`, then full checkpoint restoration and actual winning suffixes pass. Unknown/budget exhaustion is never called a proof. This is a key-cut result for two exact worlds, not a generic combat/resource solver or all-strategy guarantee.
- Final-source save-profile run: 24 checks, including actual chapter1/chapter2 namespace isolation, cross-profile native load/decode/import rejection, existing foreign-slot overwrite refusal, full native roundtrip and old-v1 byte preservation. The genuine frozen-v1 payload is 5,006 bytes with SHA `ace0ca57f3c42501075537b1706f7ba614d485acd72ce40647a471a3bf0cb824`; it is private, not redistributed or re-signed. Its native creation/fresh-load receipt and reproducible source recipe are included.

Calibration/benchmark cases do not add independent matrix samples. Immutable-content hash memoization changed process time for the exact same 1,403-action case from 39.359 s to 5.234 s. Initial/final complete snapshots differ only in their declared rules fingerprint; actual commands and resources are equal. This is wall/process runtime, **not FPS or input latency**. Both historical and final code bindings remain distinct.

## Explicit blockers and unexecuted code

The scene import attempt stopped at `subprocess.Popen / CreateProcess` with `PermissionError [WinError 5] Access is denied`. No Godot process was created, no import ran and no scene ran. The original owner remains `complete=false`, with an independent `ACCESS-GATE` denial receipt. No retry, alternate route, old scene substitution, pixel/real-input/browser acceptance or full 50-floor acceptance is claimed.

The 32 logic reports bind the actual `chapter2_replay.gd` SHA `19a569299222a2bbd6b138b048a60329faf9d64b4b761d1e87413531b5f22123`. A later QA-only optional `--native-save` branch fix supplies the profile to `Save.slot_path` and checks the actual file/SHA. Current source SHA is `06dc26e8dbbc8b54979f5e34251a0644dd8636b775675a7ee55042a37919159a`. That optional branch was disabled in every matrix case and the fix has **not** been run because of the access block. The exact measured source, current unexecuted source and minimal diff are preserved. Production runtime/content/save/data fingerprints still match the completed runs; no production exception is allowed.

## Public projection and reproducibility

This is **not** described as pure metadata-leaf projection of every report. Exactly four approved opaque duplicate carriers in final SaveProfiles are withheld: `/checks/10/details/payload`, `/checks/10/details/text`, `/checks/14/details/payload`, `/checks/14/details/text`. Each replacement records the original UTF-8 text bytes/SHA or canonical payload SHA, the retained primary snapshot pointer, exact duplicate equality and a source recipe. Full primary world/actions/snapshots remain unchanged at `/evidence/full_first_snapshot` and `/evidence/full_second_snapshot`. Original nonces and checksums are never changed, recomputed or re-signed. References are not loadable save envelopes.

Other projections are exact declared PID/private traceback leaf removals and host/test-metadata aliases. Seeds, modes, actions, world/core state, flags, previews, key-cut certificates and their hashes are preserved. Owner documents use an explicit safe whitelist. The non-final pre-cache SaveProfiles01 report remains private and unchanged; it is not counted as current coverage. An initial aggregation attempt refused its extra opaque carriers, which was a packaging-boundary safeguard, not a game failure.

`manifest.json` inside the ZIP uses archive-root member paths, original raw SHA, public canonical/compressed SHA, exact projection operations, four carrier omission receipts and preserved proof-root hashes. Historical Godot sources are `.gd.txt.gz`, preventing duplicate `class_name` registration. `auxiliary/` includes attributed static reviews, the independent source review, the unexecuted QA delta and 30 bounded collector self-tests (22 expected negative cases); these are not native game runs. Static reviewers are explicitly distinguished from the parent native executor.

`tools/build_chapter2_evidence.py verify --stage EXTRACTED --raw-root PRIVATE_OUTPUT` repeats exact raw/public checks where the original private output is available. Public-only integrity uses the outer delivery manifest, ZIP CRC and internal member hashes. Public metadata aliases do not claim to recreate renamed slot-file bytes. The source recipe can generate a new independent owned fixture; the original opaque identity remains private.
"""


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def dumped(value): return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()
def write_new(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != raw: raise ValueError("Refusing different existing artifact: " + str(path))
    else: path.write_bytes(raw)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", type=Path, required=True)
    parser.add_argument("--spec", type=Path, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--delivery", type=Path, required=True)
    args = parser.parse_args()
    spec, raw_root, _ = builder.load_spec(args.spec)
    builder.verify(args.stage, raw_root)
    builder.protected_artifacts(spec, args.spec)
    summary = builder.read_json(args.stage / "validation.json")
    assert summary["logic_passed"] is True and summary["full_acceptance"] is False and summary["passed"] is False
    manifest = builder.read_json(args.stage / "manifest.json")
    assert "bundle_files" not in manifest and not args.archive.exists()
    manifest["omitted_historical_reports"] = spec.get("omitted_historical_reports", [])
    write_new(args.stage / "README.md", README.encode())
    for name in ("build_chapter2_evidence.py", "chapter2_evidence_projection.py", "test_chapter2_evidence.py", "finalize_chapter2_evidence.py"):
        write_new(args.stage / "tools" / name, (Path(__file__).parent / name).read_bytes())
    write_new(args.stage / "tools/spec.json", args.spec.read_bytes())
    manifest["bundle_files"] = [{"member": path.relative_to(args.stage).as_posix(), "sha256": sha(path), "bytes": path.stat().st_size}
        for path in sorted(args.stage.rglob("*")) if path.is_file() and path.name != "manifest.json"]
    (args.stage / "manifest.json").write_bytes(dumped(manifest))
    builder.verify(args.stage, raw_root)
    with zipfile.ZipFile(args.archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(args.stage.rglob("*")):
            if path.is_file():
                member = path.relative_to(args.stage).as_posix(); assert not member.endswith(".gd")
                info = zipfile.ZipInfo(member, (1980, 1, 1, 0, 0, 0)); info.compress_type = zipfile.ZIP_DEFLATED
                archive.writestr(info, path.read_bytes(), compresslevel=9)
    with zipfile.ZipFile(args.archive) as archive:
        assert archive.testzip() is None
        members = archive.namelist(); assert len(members) == len(set(members))
    manifest["delivery"] = {"member": "native-evidence.zip", "sha256": sha(args.archive), "bytes": args.archive.stat().st_size,
        "crc_all_members_passed": True, "members": len(members), "internal_manifest_sha256": sha(args.stage / "manifest.json"),
        "internal_validation_sha256": sha(args.stage / "validation.json"), "README_sha256": sha(args.stage / "README.md")}
    for name in ("validation.json", "README.md"): write_new(args.delivery / name, (args.stage / name).read_bytes())
    write_new(args.delivery / "native-evidence.zip", args.archive.read_bytes())
    write_new(args.delivery / "manifest.json", dumped(manifest))
    builder.protected_artifacts(spec, args.spec)
    print(json.dumps({"projection_and_crc_passed": True, "logic_passed": True, "full_acceptance": False,
        "overall_scope": "logic_passed_scene_blocked", "records": len(manifest["records"]), "auxiliary": len(manifest.get("auxiliary", [])),
        "carrier_omissions": sum(len(item["carrier_omissions"]) for item in manifest["records"]),
        "protected_roots": sum(len(item["immutable_proof_roots"]) for item in manifest["records"]),
        "leaf_operations": sum(len(item["projection_operations"]) for item in manifest["records"]),
        "archive": manifest["delivery"], "manifest_sha256": sha(args.delivery / "manifest.json"), "delivery": str(args.delivery)}))


if __name__ == "__main__": main()
