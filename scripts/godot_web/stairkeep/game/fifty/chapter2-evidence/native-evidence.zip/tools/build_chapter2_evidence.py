"""Read-only aggregation/public projection for chapter two. Never launches native/GUI/network.

The v1 archive and evidence tree are inputs to neither writing nor replacement.
Final build refuses missing or incomplete mandatory suites, mixed runtime hashes,
probe substitution, repeated matrix samples and unlisted gameplay projection edits.
"""
from __future__ import annotations
import argparse
import copy
import gzip
import hashlib
import json
from pathlib import Path
import re
import zipfile

import chapter2_evidence_projection as projection

require = projection.require
canonical = projection.canonical
digest = projection.digest
file_hash = projection.file_hash
read_json = projection.read_json
REQUIRED = {"matrix_classic", "matrix_practice", "recovery", "choices", "save_profiles", "scene", "legacy_fixture"}
FINAL_ROLES = REQUIRED - {"legacy_fixture"}
SUITES = {
    "matrix_classic": "fifty_chapter2_actual_authored_route_matrix/v1",
    "matrix_practice": "fifty_chapter2_actual_authored_route_matrix/v1",
    "recovery": "fifty_chapter2_actual_checkpoint_recovery/v1",
    "choices": "fifty_chapter2_real_key_choice_counterexamples/v1",
    "save_profiles": "fifty_chapter2_native_save_profile_isolation/v1",
    "legacy_fixture": "fifty_chapter2_old_v1_native_fixture/v1",
    "scene": "fifty-chapter2-preview-instrumented-scene/v1",
}
OPAQUE_DUPLICATES = {
    "/checks/10/details/payload": "/evidence/full_first_snapshot",
    "/checks/14/details/payload": "/evidence/full_second_snapshot",
}


def set_pointer(value, location, replacement):
    tokens = projection.parts(location)
    target = value
    for key in tokens[:-1]: target = target[int(key)] if isinstance(target, list) else target[key]
    target[tokens[-1]] = replacement


def opaque_locations(value, path=()):
    result = []
    if isinstance(value, dict):
        if value.get("format_id") == "stairkeep-fifty-save" and isinstance(value.get("snapshot"), dict): result.append(projection.pointer(path))
        for key, child in value.items(): result.extend(opaque_locations(child, path + (key,)))
    elif isinstance(value, list):
        for index, child in enumerate(value): result.extend(opaque_locations(child, path + (index,)))
    elif isinstance(value, str) and value.startswith("{"):
        try: decoded = json.loads(value)
        except ValueError: decoded = None
        if isinstance(decoded, dict) and decoded.get("format_id") == "stairkeep-fifty-save": result.append(projection.pointer(path))
    return result


def prepare_projection(raw, role):
    """Only four approved duplicate carriers may be withheld; primary worlds stay exact."""
    found = set(opaque_locations(raw))
    expected = set(OPAQUE_DUPLICATES) | {p.removesuffix("payload") + "text" for p in OPAQUE_DUPLICATES}
    if role != "save_profiles":
        require(not found, "An unapproved opaque artifact carrier must not have its nonce rewritten")
        return raw, []
    require(found == expected, "Opaque carrier omissions are limited to the four explicitly approved JSON pointers")
    working = copy.deepcopy(raw); omissions = []
    identity_keys = ("content_id", "content_sha256", "rules_sha256", "variant_spec", "snapshot_schema")
    for payload_path, retained_path in OPAQUE_DUPLICATES.items():
        payload = projection.at(raw, payload_path); retained = projection.at(raw, retained_path)
        text_path = payload_path.removesuffix("payload") + "text"; text = projection.at(raw, text_path)
        require(set(payload) == {"format_id", "save_version", "slot_id", "mode", "runtime_identity", "snapshot", "snapshot_sha256", "payload_sha256"}, "Unknown envelope shape is not an approved omission")
        require(canonical(payload["snapshot"]) == canonical(retained) and canonical(json.loads(text)) == canonical(payload), "Omitted payload/text must duplicate the retained exact primary snapshot and each other")
        require(payload["mode"] == retained["mode"] and canonical(payload["runtime_identity"]) == canonical({key: retained[key] for key in identity_keys}), "Opaque wrapper identity differs from its retained world")
        replacement = {"carrier_omission": True, "kind": "opaque_save_envelope",
                       "original_canonical_payload_sha256": digest(payload), "original_payload_integrity_sha256": payload["payload_sha256"],
                       "original_snapshot_integrity_sha256": payload["snapshot_sha256"], "retained_snapshot_json_pointer": retained_path,
                       "retained_snapshot_canonical_sha256": digest(retained), "duplicate_snapshot_verified_equal": True,
                       "source_recipe": "FiftySave.encode_slot on the real source runtime. Original nonce and checksums are never changed or re-signed; the opaque carrier is withheld, not a loadable public payload."}
        set_pointer(working, payload_path, replacement)
        payload_omission = {"pointer": payload_path, "kind": "typed_envelope", "original_canonical_payload_sha256": digest(payload),
                            "original_canonical_payload_utf8_bytes": len(canonical(payload).encode()),
                            "retained_snapshot_json_pointer": retained_path, "retained_snapshot_canonical_sha256": digest(retained),
                            "duplicate_snapshot_verified_equal": True, "replacement": replacement}
        omissions.append(payload_omission)
        text_replacement = {"carrier_omission": True, "kind": "opaque_serialized_save_text", "original_utf8_text_bytes": len(text.encode()),
                            "original_utf8_text_sha256": hashlib.sha256(text.encode()).hexdigest(), "original_canonical_payload_sha256": digest(payload),
                            "payload_reference_json_pointer": payload_path, "retained_snapshot_json_pointer": retained_path,
                            "retained_snapshot_canonical_sha256": digest(retained), "duplicate_snapshot_verified_equal": True}
        set_pointer(working, text_path, text_replacement)
        omissions.append({"pointer": text_path, "kind": "serialized_envelope", "original_utf8_text_bytes": len(text.encode()),
                          "original_utf8_text_sha256": hashlib.sha256(text.encode()).hexdigest(), "original_canonical_payload_sha256": digest(payload),
                          "retained_snapshot_json_pointer": retained_path, "retained_snapshot_canonical_sha256": digest(retained),
                          "duplicate_snapshot_verified_equal": True, "replacement": text_replacement})
    return working, omissions


def preserved_original_roots(raw, omissions):
    prefixes = [item["pointer"] for item in omissions]
    return [root for root in projection.proof_roots(raw) if not any(root["pointer"] == prefix or root["pointer"].startswith(prefix + "/") for prefix in prefixes)]


def verify_report_projection(raw, public, role, operations, omissions):
    working, expected_omissions = prepare_projection(raw, role)
    require(canonical(expected_omissions) == canonical(omissions), "Opaque omission mapping is not the exact approved byte/snapshot binding")
    projection.verify_projection(working, public, operations)
    for root in preserved_original_roots(raw, omissions):
        require(digest(projection.at(public, root["pointer"])) == root["sha256"], "A primary gameplay/proof root changed")


def bounded_path(root, relative):
    path = Path(relative)
    require(not path.is_absolute() and ".." not in path.parts, "References must remain under declared input root")
    return root / path


def load_spec(path):
    spec = read_json(path)
    root = path.resolve().parent
    raw_root = (root / spec.get("raw_root", ".")).resolve()
    project = (root / spec["project_root"]).resolve()
    roles = [run["role"] for run in spec["runs"] if run["role"] in REQUIRED]
    require(len(roles) == len(set(roles)), "Mandatory evidence roles cannot be counted twice")
    require(set(roles) == REQUIRED, "Explicitly list all mandatory final evidence roles")
    ids = [run["id"] for run in spec["runs"]]
    require(len(ids) == len(set(ids)) and all(re.fullmatch(r"[a-z0-9_-]+", value) for value in ids), "Unique safe artifact IDs required")
    return spec, raw_root, project


def readiness(spec, raw_root):
    pending = []
    for run in spec["runs"]:
        if run["role"] not in REQUIRED: continue
        for key in ("report", "owner"):
            path = bounded_path(raw_root, run[key])
            if not path.is_file(): pending.append({"role": run["role"], "missing": run[key]})
        owner_path = bounded_path(raw_root, run["owner"])
        if owner_path.is_file() and read_json(owner_path).get("complete") is not True and run.get("kind") != "blocked_access_gate":
            pending.append({"role": run["role"], "owner_not_terminal": run["owner"]})
    return {"ready_for_validation": not pending, "pending": pending,
            "scope": "Presence/completion inventory only; not a passed native/projection result."}


def owner_safe(owner):
    fields = {"started_utc", "ended_utc", "complete", "script", "source", "requested_priority",
              "creation_no_window", "no_timeout_or_kill", "gui_or_browser_started",
              "executable_bytes_rechecked", "observed_priority_class", "exit_code", "elapsed_seconds",
              "stderr_bytes", "stdout_sha256", "stderr_sha256", "report_sha256", "measurement_passed",
              "source_unchanged", "protected_source_and_artifacts_unchanged", "accepted",
              "delivered_source_code_and_assets_match_after_import", "original_game_unchanged",
              "original_new_dependencies_unchanged", "pixels_or_real_input_claimed"}
    safe = {key: owner[key] for key in fields if key in owner}
    if "steps" in owner:
        keys = {"step", "observed_priority_class", "below_normal_verified", "exit_code", "elapsed_seconds", "stderr_bytes", "stdout_sha256", "stderr_sha256"}
        safe["steps"] = [{key: value for key, value in step.items() if key in keys} for step in owner["steps"]]
    public, _ = projection.projected(safe)
    return public


def verify_owner(report, owner, raw_sha, current):
    require(owner.get("complete") is True and owner.get("accepted") is True,
            "Final/benchmark native owner must have reached accepted terminal state")
    require(owner.get("report_sha256", owner.get("measurement_report_sha256")) == raw_sha,
            "Owner does not bind exact report bytes")
    if "steps" in owner:
        require(owner.get("delivered_source_code_and_assets_match_after_import") is True and
                owner.get("original_game_unchanged") is True and owner.get("original_new_dependencies_unchanged") is True,
                "Scene stage source/asset acceptance is incomplete")
        require(all(step["exit_code"] == 0 and step["stderr_bytes"] == 0 and step["observed_priority_class"] == 16384
                    for step in owner["steps"]), "Scene import or scene run has actual errors/wrong priority")
    else:
        require(owner.get("exit_code") == 0 and owner.get("stderr_bytes") == 0 and owner.get("observed_priority_class") == 16384,
                "Actual native exit/stderr/priority failed")
        require(owner.get("source_unchanged") is True and owner.get("protected_source_and_artifacts_unchanged") is True,
                "Bound source or protected original artifacts changed during execution")
    require(report.get("passed") is True and not report.get("errors"), "Producer did not pass its actual assertions")
    require(all(item.get("passed") is True for item in report.get("checks", [])), "A producer check contradicts its top-level passed flag")
    if current: require(report.get("measurement_completed") is True, "A partial probe cannot substitute for completed mandatory coverage")


def verify_current_sources(report, owner, project, expected, measured_snapshots=None, raw_root=None):
    source = owner.get("source", {})
    require(source, "Current source map missing from owner receipt")
    def verify_file(relative, sha):
        actual = file_hash(bounded_path(project, relative))
        if actual == sha: return
        delta = (measured_snapshots or {}).get(relative)
        require(relative == "fifty/tests/chapter2_replay.gd" and delta and raw_root is not None,
                "Current delivered source differs from measured source: " + relative)
        require(delta["measured_sha256"] == sha and delta["current_unexecuted_sha256"] == actual and
                file_hash(bounded_path(raw_root, delta["measured_source_snapshot"])) == sha and delta["status"] == "not-tested_optional_native_save_followup",
                "Test-source delta lacks exact archived measured/current bindings")
    for relative, sha in expected.items():
        require(source.get(relative) == sha, "Mixed runtime/data fingerprint in current suite: " + relative)
    for relative, sha in source.items():
        verify_file(relative, sha)
    for relative, sha in report.get("source_hashes", report.get("bound_source_hashes", {})).items():
        key = relative.removeprefix("res://")
        require(source.get(key, sha) == sha, "Producer/owner source binding differs: " + key)
        verify_file(key, sha)


def verify_blocked_scene(report, owner, expected):
    require(report.get("schema") == "stairkeep-access-gate/v1" and report.get("status") == "denied", "Missing explicit actual access denial receipt")
    require(all(report.get(field) is False for field in ("process_created", "import_executed", "scene_executed", "retry_or_alternate_route_attempted", "full_acceptance")), "Denied import must never be counted as an executed scene")
    require(owner.get("complete") is False and owner.get("steps") == [], "Original incomplete owner and absence of engine steps must be retained")
    for relative, sha in expected.items(): require(owner.get("source", {}).get(relative) == sha, "Blocked source intention did not bind the final logic source")


def summarize_matrix(reports, data):
    require(data["content_id"] == "stairkeep-fifty-chapter2/v1", "Wrong canonical content profile")
    require(data["manifest"]["authored_floors"] == list(range(1, 21)) and data["manifest"]["not_authored_floors"] == list(range(21, 51)), "Not the actual twenty-floor authored scope")
    routes = {route["name"]: route for route in data["validated_routes"]}
    require(set(routes) == {"keen", "reserve"}, "Exactly two authored witness policies required")
    object_kinds = {item["id"]: item["kind"] for floor in data["floors"] for item in floor["objects"]}
    seen = set(); layouts = set(); rows = []
    counts = {key: 0 for key in ("cases", "events", "actions", "preview_actual_comparisons", "door_revisits", "stair_roundtrips", "stock_refusals", "npc_repeat_refusals")}
    for role, mode in (("matrix_classic", "classic_restart"), ("matrix_practice", "practice_checkpoint")):
        report = reports[role]
        require(report["suite"] == SUITES[role] and report["mode"] == mode and len(report["cases"]) == 16 and report["case_offset"] == 0 and report["requested_cases"] == 16 and report["completed_cases"] == 16,
                "Final matrix must be its complete official sixteen cases; probes are not matrix shards")
        require(report["content_audit"]["unique_nonempty_authored_floors"] == 20, "Empty/copied authored maps cannot count")
        for case in report["cases"]:
            identity = (mode, case["seed"], case["route"])
            require(identity not in seen and case["passed"] is True and case["authoritative_full_action_replay"]["ok"] is True,
                    "Repeated or unverified route case")
            seen.add(identity)
            route = routes[case["route"]]; trace = case["trace"]
            require(len(trace) == len(route["events"]) == len(route["ledger"]) == case["events_checked"] == 201,
                    "Actual event ledger coverage is incomplete")
            require([event["event"] for event in trace] == route["events"], "Actual resource event order differs")
            initial = case["initial_full_snapshot"]; final = case["full_final_snapshot"]
            require(final["slice_complete"] is True and final["campaign_complete"] is False and final["core_state"]["won"] is False,
                    "Twenty-floor slice mislabeled full fifty-floor campaign victory")
            for field in ("seed", "root_seed", "floor_transforms", "layout_sha256", "layout_signature", "attempt_index", "content_id", "content_sha256", "rules_sha256"):
                require(canonical(initial[field]) == canonical(final[field]), "Ordinary run identity/layout changed")
            for actual, expected in zip(trace, route["ledger"]):
                world = actual["actual_world"]; core = world["core_state"]
                for field in ("hp", "atk", "def", "gold", "keys"):
                    require(canonical(core[field]) == canonical(expected["state"][field]), "Actual event resource budget differs")
                require(world["flags"] == expected["flags"] and world["completed_events"] == expected["completed_events"] and core["purchases"] == expected["purchases"] and len(core["cleared"]) == expected["cleared_count"] and world["slice_complete"] == expected["slice_complete"],
                        "Actual event flags/stock/completed world differs")
                if "selected_event_id" in expected: require(actual["selected_event_id"] == expected["selected_event_id"], "Wrong actual NPC/event branch")
            require(sorted(final["core_state"]["cleared"]) == sorted(route["final_cleared"]) and final["flags"] == route["final_flags"] and final["completed_events"] == route["completed_events"] and final["core_state"]["purchases"] == route["final_purchases"], "Final authored world differs")
            flattened = []
            for event in trace:
                commands = copy.deepcopy(event["actions"])
                if event["selected_event_id"]: commands[-1]["selected_event_id"] = event["selected_event_id"]
                flattened.extend(commands)
            require(flattened == final["actions"] and len(flattened) == case["actual_actions"], "Actual complete action journal differs from event paths")
            expected_combats = sum(object_kinds.get(event) == "enemy" for event in route["events"])
            require(expected_combats == case["preview_deduction_comparisons"] == 40, "Actual combat preview/deduction coverage differs")
            require([cp["floor_id"] for cp in final["checkpoints"]] == [1, 5, 11, 15], "Configured checkpoint coverage differs")
            counts["cases"] += 1; counts["events"] += len(trace); counts["actions"] += len(flattened)
            for target, field in (("preview_actual_comparisons", "preview_deduction_comparisons"), ("door_revisits", "door_revisit_checks"), ("stair_roundtrips", "stair_roundtrip_checks"), ("stock_refusals", "stock_refusal_checks"), ("npc_repeat_refusals", "npc_once_checks")):
                counts[target] += case[field]
            layouts.add(initial["layout_sha256"])
            rows.append({"mode": mode, "seed": case["seed"], "route": case["route"], "events": len(trace), "actual_actions": len(flattened), "layout_sha256": initial["layout_sha256"], "final_budget": case["final_budget"]})
    expected_ids = {(mode, f"{seed:08x}", route) for mode in ("classic_restart", "practice_checkpoint") for seed in range(1, 9) for route in ("keen", "reserve")}
    require(seen == expected_ids and len(layouts) == 8, "Expected 32 unique mode/seed/policy cases and eight layouts exactly")
    return {**counts, "unique_layouts": len(layouts), "policies": ["keen", "reserve"], "cases_table": rows,
            "authored_floors": 20, "target_floors": 50, "not_authored_floors": 30,
            "scope": "Two complete final-source matrices, not a union of overlapping probes. No exhaustive strategy, 10k-run, physical input/browser, human-duration or full-fifty-floor claim."}


def validate_special_roles(reports):
    recovery = reports["recovery"]
    require({c["checkpoint_id"] for c in recovery["cases"]} == {"entry_11", "entry_15"} and len(recovery["cases"]) == 2,
            "Both actual late checkpoint cases are required")
    for case in recovery["cases"]:
        require(case["passed"] is True and case["suffix"]["ok"] is True and case["suffix"]["authoritative_full_replay"]["ok"] is True,
                "Restored world without actual verified winning suffix is insufficient")
        require(canonical(case["full_restored_snapshot"]["core_state"]) == canonical(case["checkpoint_world"]["core_state"]), "Checkpoint core was not restored exactly")
        require(case["full_restored_snapshot"]["flags"] == case["checkpoint_world"]["flags"] and case["full_restored_snapshot"]["completed_events"] == case["checkpoint_world"]["completed_events"], "Checkpoint flags/events differ")
    choices = reports["choices"]
    require(len(choices["cases"]) == 2 and {c["id"] for c in choices["cases"]} == {"bad_early_side_gate_f11", "bad_early_side_gate_f15"}, "Both exact bad-choice cases are required")
    for case in choices["cases"]:
        require(case["passed"] is True and case["classification"] == "known_key_cut" and case["ordinary_play_key_cut_proof"]["complete"] is True,
                "Unknown/no-strategy-found cannot substitute for a complete key-cut certificate")
        require(case["authoritative_full_action_replay"]["ok"] is True and case["full_final_snapshot"]["slice_complete"] is True,
                "Key-cut recovery must actually finish the restored suffix")
    save = reports["save_profiles"]
    require(save["evidence"]["profile_isolation_complete"] is True and save["evidence"]["old_v1_owned_slot_tested"] is True,
            "Save profile probe omits native legacy fixture coverage")
    require(save["evidence"]["old_v1_fixture_sha256"] == "ace0ca57f3c42501075537b1706f7ba614d485acd72ce40647a471a3bf0cb824",
            "The genuine legacy slot fixture identity changed")
    scene = reports["scene"]
    require(scene.get("status") == "denied" and scene.get("scene_executed") is False, "This partial bundle must explicitly retain the actual scene block")
    return {"recovery_cases": 2, "key_cut_counterexamples": 2, "native_save_checks": len(save.get("checks", [])),
            "scene_checks": 0, "scene_status": "blocked", "legacy_fixture_payload_distributed": False,
            "key_cut_scope": "Exact two later ordinary-play zero-yellow-key worlds; no generic combat solver and no initial unsatisfiability claim."}


def validate_cache_ab(raw_root, spec):
    item = spec["cache_ab"]
    before_path = bounded_path(raw_root, item["before_report"]); after_path = bounded_path(raw_root, item["after_report"])
    before = read_json(before_path); after = read_json(after_path)
    bc = before["cases"][0]; ac = after["cases"][0]
    require(bc["seed"] == ac["seed"] and bc["route"] == ac["route"] and bc["mode"] == ac["mode"] and bc["actual_actions"] == ac["actual_actions"] == 1403, "Cache A/B must compare the exact same actual case")
    require(bc["trace"] != [] and [event["actions"] for event in bc["trace"]] == [event["actions"] for event in ac["trace"]] and bc["full_final_snapshot"]["actions"] == ac["full_final_snapshot"]["actions"], "A/B actual action sequences differ")
    for field in ("initial_full_snapshot", "full_final_snapshot"):
        b = copy.deepcopy(bc[field]); a = copy.deepcopy(ac[field])
        require(b["rules_sha256"] != a["rules_sha256"], "Cache source revision must have a distinct rules fingerprint")
        b["rules_sha256"] = a["rules_sha256"]
        require(canonical(b) == canonical(a), "A/B full snapshot differs beyond its one declared top-level rules fingerprint")
    bo = read_json(bounded_path(raw_root, item["before_owner"])); ao = read_json(bounded_path(raw_root, item["after_owner"]))
    verify_owner(before, bo, file_hash(before_path), False); verify_owner(after, ao, file_hash(after_path), False)
    return {"passed": True, "before_report_sha256": file_hash(before_path), "after_report_sha256": file_hash(after_path),
            "actual_actions_equal": 1403, "full_snapshot_comparison_allowed_difference": ["/initial_full_snapshot/rules_sha256", "/full_final_snapshot/rules_sha256"],
            "before_process_seconds": bo["elapsed_seconds"], "after_process_seconds": ao["elapsed_seconds"],
            "scope": "Same actual route, initial/final complete snapshots and commands except the declared code fingerprint. Wall/process runtime, not FPS or input latency. Raw snapshots are never normalized for publication."}


def write_gzip(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as handle:
        with gzip.GzipFile(filename="", mode="wb", fileobj=handle, mtime=0) as packed: packed.write(raw)


def dump_new(path, value):
    require(not path.exists(), "Refusing to overwrite an existing artifact")
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def protected_artifacts(spec, spec_path):
    root = (spec_path.resolve().parent / spec.get("protected_root", "..")).resolve()
    bound = spec.get("protected_first_chapter_artifacts", {})
    require(len(bound) >= 4, "Original first-chapter evidence must be bound before a new archive is built")
    for relative, expected in bound.items():
        require(file_hash(bounded_path(root, relative)) == expected, "An original first-chapter evidence artifact changed: " + relative)
    return dict(bound)


def build(args):
    spec, raw_root, project = load_spec(args.spec)
    original_artifacts = protected_artifacts(spec, args.spec)
    inventory = readiness(spec, raw_root)
    require(inventory["ready_for_validation"], "Missing/incomplete mandatory evidence: " + json.dumps(inventory["pending"]))
    require(not args.output.exists(), "New chapter-two output directory required; v1 evidence is never replaced")
    reports = {}; entries = []; sources = []
    for run in spec["runs"]:
        report_path = bounded_path(raw_root, run["report"]); owner_path = bounded_path(raw_root, run["owner"])
        report = read_json(report_path); owner = read_json(owner_path); role = run["role"]
        current = role in FINAL_ROLES
        blocked = role == "scene" and run.get("kind") == "blocked_access_gate"
        if blocked: verify_blocked_scene(report, owner, spec["expected_current_sources"])
        else:
            verify_owner(report, owner, file_hash(report_path), current)
            if role in SUITES: require(report["suite"] == SUITES[role], "Wrong native suite for mandatory role")
            if current: verify_current_sources(report, owner, project, spec["expected_current_sources"], spec.get("measured_source_snapshots"), raw_root)
        for stream in ("stdout", "stderr"):
            if stream in run:
                stream_path = bounded_path(raw_root, run[stream])
                require(file_hash(stream_path) == owner[stream + "_sha256"], "Actual log bytes differ from owner binding")
                if current and stream == "stderr": require(stream_path.stat().st_size == 0, "Real stderr cannot be masked by producer pass")
        working, omissions = prepare_projection(report, role)
        public, operations = projection.projected(working)
        verify_report_projection(report, public, role, operations, omissions)
        safe = owner_safe(owner)
        member = "reports/" + run["id"] + ".json.gz"; owner_member = "owners/" + run["id"] + ".json.gz"
        sources.extend([(member, canonical(public).encode()), (owner_member, canonical(safe).encode())])
        entries.append({"id": run["id"], "role": role, "classification": run.get("classification", "current_bounded_suite"), "raw_report": run["report"], "raw_sha256": file_hash(report_path), "raw_bytes": report_path.stat().st_size, "public_member": member, "public_json_sha256": digest(public), "projection_operations": operations, "carrier_omissions": omissions, "immutable_proof_roots": preserved_original_roots(report, omissions), "raw_owner": run["owner"], "raw_owner_sha256": file_hash(owner_path), "owner_public_member": owner_member, "owner_public_json_sha256": digest(safe)})
        if role in REQUIRED: reports[role] = report
    canonical_data = read_json(project / "fifty/data/chapter2-content.json")
    matrix = summarize_matrix(reports, canonical_data)
    if spec.get("measured_source_snapshots"):
        require(all(case.get("native_saves") == [] for role in ("matrix_classic", "matrix_practice") for case in reports[role]["cases"]), "Unexecuted optional-save followup cannot replace a measured native-save branch")
    specialized = validate_special_roles(reports)
    cache_ab = validate_cache_ab(raw_root, spec)
    legacy = reports["legacy_fixture"]
    require(legacy["fixture_sha256"] == "ace0ca57f3c42501075537b1706f7ba614d485acd72ce40647a471a3bf0cb824" and legacy["fixture_bytes"] == 5006 and legacy["fresh_native_load_passed"] is True and legacy["complete_snapshot_equal"] is True and legacy["native_bytes_unchanged_after_load"] is True, "Actual old native fixture receipt differs")
    source_history = []
    for item in spec.get("source_history", []):
        path = bounded_path(raw_root, item["path"])
        require(file_hash(path) == item["sha256"], "Historical source bytes differ")
        member = "source-history/" + path.name + ".txt.gz"
        require(not any(member == prior["member"] for prior in source_history), "Repeated source archive name")
        sources.append((member, path.read_bytes()))
        source_history.append({"member": member, "source_sha256": item["sha256"], "provenance": item["provenance"]})
    auxiliary = []
    for item in spec.get("auxiliary", []):
        path = bounded_path(raw_root, item["path"]); raw = read_json(path)
        working, omissions = prepare_projection(raw, "auxiliary")
        public, operations = projection.projected(working)
        verify_report_projection(raw, public, "auxiliary", operations, omissions)
        member = "auxiliary/" + item["id"] + ".json.gz"
        sources.append((member, canonical(public).encode()))
        auxiliary.append({"id": item["id"], "raw_file": item["path"], "raw_sha256": file_hash(path), "public_member": member, "public_json_sha256": digest(public), "projection_operations": operations})
    args.output.mkdir(parents=True)
    for member, raw in sources: write_gzip(args.output / member, raw)
    for entry in entries:
        for key in ("public_member", "owner_public_member"):
            entry[key + "_sha256"] = file_hash(args.output / entry[key])
    for item in source_history: item["member_sha256"] = file_hash(args.output / item["member"])
    for item in auxiliary: item["member_sha256"] = file_hash(args.output / item["public_member"])
    summary = {"schema_version": 1, "suite": "fifty_chapter2_bounded_native_evidence/v1", "passed": False, "logic_passed": True, "full_acceptance": False, "overall_scope": "logic_passed_scene_blocked", "scene": {"status": "blocked", "process_created": False, "import_executed": False, "scene_executed": False, "reason": reports["scene"]["reason"]}, "matrix": matrix,
               "specialized": specialized, "cache_ab": cache_ab, "legacy_fixture": {"payload_distributed": False, "payload_sha256": legacy["fixture_sha256"], "payload_bytes": 5006, "source_recipe": "res://fifty/tests/chapter2_legacy_fixture.gd", "native_origin_report_member": next(e["public_member"] for e in entries if e["role"] == "legacy_fixture"), "scope": "Original payload is private and byte-bound; slot metadata aliases do not rename or recompute that payload's checksums."},
               "human_pixels_reviewed": False, "real_keyboard_mouse_touch_tested": False, "browser_play_persistence_tested": False,
               "scope": "Bounded native tests and typed public evidence projection only. Twenty authored floors toward fifty, thirty unmade; no visual, real input, browser, deployment, human-duration or full-campaign acceptance."}
    manifest = {"schema_version": 1, "suite": "chapter2_public_projection_manifest/v1", "overall_scope": "logic_passed_scene_blocked", "logic_passed": True, "full_acceptance": False, "member_scope": "archive-root", "builder_sha256": file_hash(Path(__file__)), "projection_core_sha256": file_hash(Path(projection.__file__)), "spec_sha256": file_hash(args.spec), "records": entries, "source_history": source_history, "raw_reports_modified": False, "raw_owner_reports_distributed": False, "legacy_fixture_payload_distributed": False, "protected_first_chapter_artifacts": original_artifacts, "protected_policy": sorted(projection.PROTECTED), "scope": "Exact PID/host metadata leaf projection plus exactly four explicitly documented opaque duplicate carrier omissions. Not a claim of pure metadata-only projection of every report. All primary world/actions/snapshots/preview/key-cut/hash roots stay exact; duplicate omitted snapshots equal retained primary references. Original opaque nonces/checksums never re-signed. Owner documents use a fixed whitelist. v1 evidence untouched; scene blocked before process creation."}
    summary["qa_source_followups"] = spec.get("measured_source_snapshots", {})
    manifest["qa_source_followups"] = spec.get("measured_source_snapshots", {})
    manifest["auxiliary"] = auxiliary
    dump_new(args.output / "summary.json", summary)
    dump_new(args.output / "validation.json", {**summary, "projection": {"records": len(entries), "exact_leaf_operations": sum(len(e["projection_operations"]) for e in entries), "protected_roots": sum(len(e["immutable_proof_roots"]) for e in entries), "history_source_bytes_verified": len(source_history)}})
    dump_new(args.output / "manifest.json", manifest)
    verify(args.output, raw_root)
    require(protected_artifacts(spec, args.spec) == original_artifacts, "Original artifacts changed during new aggregation")
    if args.archive:
        require(not args.archive.exists() and not args.archive.resolve().is_relative_to(args.output.resolve()), "New archive outside stage required")
        with zipfile.ZipFile(args.archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for path in sorted(args.output.rglob("*")):
                if path.is_file():
                    member = path.relative_to(args.output).as_posix()
                    require(not member.endswith(".gd"), "Historical Godot classes may only be archived as text.gz")
                    archive.write(path, member)
        with zipfile.ZipFile(args.archive) as archive: require(archive.testzip() is None, "ZIP CRC failure")
    print(json.dumps({"projection_passed": True, "logic_passed": True, "full_acceptance": False, "overall_scope": "logic_passed_scene_blocked", "output": str(args.output), "matrix": {k: v for k, v in matrix.items() if k != "cases_table"}, "archive_sha256": file_hash(args.archive) if args.archive else None}))


def verify(stage, raw_root):
    manifest = read_json(stage / "manifest.json")
    require(manifest["protected_policy"] == sorted(projection.PROTECTED), "Verifier projection policy differs")
    for entry in manifest["records"]:
        raw_path = bounded_path(raw_root, entry["raw_report"]); raw = read_json(raw_path)
        public_path = stage / entry["public_member"]; public = read_json(public_path)
        require(file_hash(raw_path) == entry["raw_sha256"] and file_hash(public_path) == entry["public_member_sha256"] and digest(public) == entry["public_json_sha256"], "Raw/public report binding differs")
        verify_report_projection(raw, public, entry["role"], entry["projection_operations"], entry["carrier_omissions"])
        require(preserved_original_roots(raw, entry["carrier_omissions"]) == entry["immutable_proof_roots"], "Protected-root receipt omitted or changed")
        owner_path = bounded_path(raw_root, entry["raw_owner"])
        safe_path = stage / entry["owner_public_member"]
        require(file_hash(owner_path) == entry["raw_owner_sha256"] and file_hash(safe_path) == entry["owner_public_member_sha256"], "Owner original/public bytes differ")
        safe = read_json(safe_path)
        require(canonical(safe) == canonical(owner_safe(read_json(owner_path))) and digest(safe) == entry["owner_public_json_sha256"], "Owner whitelist projection differs")
    for item in manifest["source_history"]:
        path = stage / item["member"]
        require(file_hash(path) == item["member_sha256"], "Historical compressed-source bytes differ")
        with gzip.open(path, "rb") as source: raw = source.read(projection.MAX_JSON + 1)
        require(hashlib.sha256(raw).hexdigest() == item["source_sha256"], "Historical source bytes differ")
    for item in manifest.get("auxiliary", []):
        raw_path = bounded_path(raw_root, item["raw_file"]); public_path = stage / item["public_member"]
        require(file_hash(raw_path) == item["raw_sha256"] and file_hash(public_path) == item["member_sha256"], "Auxiliary raw/public bytes changed")
        raw = read_json(raw_path); public = read_json(public_path)
        require(digest(public) == item["public_json_sha256"], "Auxiliary canonical bytes changed")
        projection.verify_projection(raw, public, item["projection_operations"])
    return True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    inventory = sub.add_parser("check-inputs"); inventory.add_argument("--spec", type=Path, required=True)
    builder = sub.add_parser("build"); builder.add_argument("--spec", type=Path, required=True); builder.add_argument("--output", type=Path, required=True); builder.add_argument("--archive", type=Path)
    verifier = sub.add_parser("verify"); verifier.add_argument("--stage", type=Path, required=True); verifier.add_argument("--raw-root", type=Path, required=True)
    args = parser.parse_args()
    if args.command == "check-inputs":
        spec, raw_root, _ = load_spec(args.spec); print(json.dumps(readiness(spec, raw_root)))
    elif args.command == "build": build(args)
    else: verify(args.stage, args.raw_root); print(json.dumps({"passed": True, "scope": "Raw/public typed protection and owner whitelist/source byte comparison; no new native run."}))


if __name__ == "__main__": main()
