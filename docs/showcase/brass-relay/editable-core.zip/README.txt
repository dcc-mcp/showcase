BRASS RELAY / A four-bar study

Open blender/brass-animation.blend for the editable 97-pose animation, or the hero and plan BLENDs for their saved cameras. Open freecad/parts/*.FCStd for 13 editable parameter/boolean parts; STEP/STL exchanges are under freecad/exchange. CAD units are millimetres. Blender illustration coordinates are CAD mm / 20, with unchanged axes. The assembled view is in Blender; this is not a constrained FreeCAD assembly.

The full native package includes kdenlive/project.kdenlive with all 98 relative media PNGs. The compact editable core omits the image sequence, so its Kdenlive timeline requires the full package's unchanged kdenlive/media directory or the identical media from the original delivered package. Install DejaVu Sans separately. The included font notice remains intact.

The corrected editor retains 390 native Dynamic Text filters. Actual GUI observation was limited to the two closing stack entries and first closing text field; all 390 serialized identities/styles, untouched save/reopen, and all 432 output frames were checked. Parameter editing/Undo is excluded. See validation.json and METHODS.md for exact scope.

The full native archive retains the earlier look-development image and both 1600x1000 masters. The earlier image has a different camera/resolution and is not a matched-pose comparison. The compact core includes only two small viewing previews.

The scene illustrates sampled prescribed kinematics; no dynamics, stress, manufacturing, safety, continuous collision or exact seamless-pixel-loop claim. Read LICENSES.md before reuse: this package grants no additional artwork or source-asset license.
