---
name: reaper-film-score
description: Author distinct original native MIDI scores with stock REAPER instruments for three public showcase films.
license: MIT
metadata:
  dcc-mcp:
    dcc: reaper
    version: "0.1.0"
    tags: [music, midi, score, animation, sound-design]
    tools: tools.yaml
---
# Native showcase scoring
Bounded original note recipes for Crystal Freight, Brass Relay and Orbit Post Office. Music is authored as editable MIDI items and rendered by actual stock REAPER ReaSynth instances. Procedural mechanical/accent WAVs are explicitly separate mathematically synthesized sources, never claimed as recorded Foley or native instruments. All video artwork/animation rights and original files remain unchanged. The tool accepts only the three fixed case IDs and new output directories, and requires an empty clean project.
