import json,wave,hashlib
from pathlib import Path
from dcc_mcp_core.skill import skill_entry,skill_success
from .native import R,audit
@skill_entry
def main(project_dir: str):
 root=Path(project_dir).resolve();p,_,current,_=R.EnumProjects(-1,'',4096)
 if Path(current).resolve()!=root/'Score.rpp' or R.IsProjectDirty(p):raise RuntimeError('Open the matching clean native score first')
 recipe=json.loads((root/'score-recipe.json').read_text());duration=recipe['duration_seconds'];out=root/'score-master.wav'
 if out.exists():raise FileExistsError('Refusing to overwrite score render')
 for name,value in [('RENDER_FILE',str(root)),('RENDER_PATTERN','score-master'),('RENDER_FORMAT','evaw'),('RENDER_FORMAT2','')]:R.GetSetProjectInfo_String(p,name,value,True)
 for name,value in [('RENDER_SETTINGS',0),('RENDER_BOUNDSFLAG',0),('RENDER_STARTPOS',0),('RENDER_ENDPOS',duration),('RENDER_CHANNELS',2),('RENDER_SRATE',48000),('RENDER_TAILFLAG',0),('RENDER_ADDTOPROJ',0),('RENDER_DITHER',16),('RENDER_NORMALIZE',1+4+512+1024),('RENDER_NORMALIZE_TARGET',10**(-3/20)),('RENDER_FADEIN',.015),('RENDER_FADEOUT',.22)]:R.GetSetProjectInfo(p,name,value,True)
 R.Main_OnCommand(42230,0)
 with wave.open(str(out),'rb') as f:
  if f.getframerate()!=48000 or f.getnchannels()!=2 or f.getsampwidth()!=3 or f.getnframes()!=int(duration*48000):raise RuntimeError('Unexpected native output format/duration')
  pcm=f.readframes(f.getnframes())
 R.GetSetProjectInfo_String(p,'RENDER_FILE','.',True);R.Main_SaveProjectEx(p,str(root/'Score.rpp'),8)
 return skill_success('Actual stock instruments rendered to picture duration',output=str(out),duration=duration,frames=int(duration*48000),sample_rate=48000,bit_depth=24,channels=2,sha256=hashlib.sha256(out.read_bytes()).hexdigest(),pcm_sha256=hashlib.sha256(pcm).hexdigest(),**{'native_score':audit()})
