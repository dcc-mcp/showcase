from dcc_mcp_core.skill import skill_entry,skill_success
from reapy_boost import reascript_api as R
@skill_entry
def main():
 p=R.EnumProjects(-1,'',4096)[0]
 if R.CountTracks(p) or R.IsProjectDirty(p):raise RuntimeError('Requires empty clean project')
 R.InsertTrackAtIndex(0,True);tr=R.GetTrack(p,0)
 try:
  fx=R.TrackFX_AddByName(tr,'ReaSynth (Cockos)',False,1)
  if fx<0:raise RuntimeError('Stock ReaSynth unavailable')
  params=[]
  for i in range(R.TrackFX_GetNumParams(tr,fx)):
   raw=R.TrackFX_GetParam(tr,fx,i,0,0)
   params.append(dict(index=i,name=R.TrackFX_GetParamName(tr,fx,i,'',256)[4],raw=list(raw),formatted=R.TrackFX_GetFormattedParamValue(tr,fx,i,'',256)[4]))
  return skill_success('Actual stock instrument schema',fx=R.TrackFX_GetFXName(tr,fx,'',256)[3],params=params)
 finally:
  R.DeleteTrack(tr);R.GetSetProjectInfo(p,'DIRTY',0,True)
