from dcc_mcp_core.skill import skill_entry,skill_success
from .native import audit
@skill_entry
def main():return skill_success('Actual native score audited',**audit())
