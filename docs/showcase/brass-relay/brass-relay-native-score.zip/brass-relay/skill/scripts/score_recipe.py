"""Fixed original native MIDI score recipes plus procedural SFX sources.
MIT code; new original audio CC0-1.0. Visual rights remain unchanged.
Generate through the typed DCC-MCP tool; actual MIDI/instruments/render live in REAPER.
"""
import json,hashlib,importlib.util
from pathlib import Path
CASES={'crystal-freight-native-film':20,'brass-relay':18,'orbit-post-office':7}
def generate(output_dir,case_id):
 if case_id not in CASES:raise ValueError('Unknown case_id')
 root=Path(output_dir).resolve()
 if root.exists() and any(root.iterdir()):raise FileExistsError('Use a new empty output directory')
 root.mkdir(parents=True,exist_ok=True);duration=CASES[case_id]
 tracks=[]
 def track(name,events,gain,pan,hint):
  tracks.append(dict(name=name,type='midi',notes=[dict(start_seconds=float(t),duration_seconds=float(min(d,duration-t-.02)),pitch=int(p),velocity=int(v)) for t,d,p,v in events if t<duration-.03],gain_linear=gain,pan=pan,timbre_hint=hint))
 if case_id=='crystal-freight-native-film':
  title='Crystal Freight — A Little Quarry Journey'
  chords=[(0,4,[60,64,67,74]),(4,3,[57,60,64,71]),(7,3,[53,57,60,67]),(10,4,[55,59,62,69]),(14,4,[60,64,67,74]),(18,2,[48,60,64,67])]
  melody=[(0,72),(.75,76),(1.5,79),(2.5,76),(3,74),(4,72),(4.5,76),(5,79),(5.75,81),(6.5,79),(7,77),(8.5,76),(9.25,74),(10,74),(10.5,79),(11,83),(11.75,81),(12.5,79),(13,76),(14,79),(15,76),(16,74),(17,72),(18,76),(18.5,72)]
  track('Quarry music-box motif',[(t,.23,n,70 if t<14 else 61) for t,n in melody],.24,-.13,'Stock ReaSynth sine/triangle pluck: fast attack, short decay, near-zero sustain, short release; small native reverb/send if available.')
  ost=[(t,.1,[60,67,72,67][i%4],40) for i,t in enumerate([4+i*.25 for i in range(12)]+[10+i*.25 for i in range(16)])]
  track('Tiny timber ostinato',ost,.11,.22,'Very short sine pluck, low sustain; dry and toy-scale.')
 elif case_id=='brass-relay':
  title='Brass Relay — Clockwork Dialogue'
  chords=[(0,3,[50,57,62,65]),(3,4,[50,57,62,69]),(7,4,[46,53,58,65]),(11,4,[48,55,60,64]),(15,3,[50,57,62,65])]
  melody=[(0,74),(1,77),(2,81)]
  for start,seq in [(3,[74,77,81,77,74,69,72,77]),(7,[70,74,77,74,70,65,69,74])]:melody.extend((start+i*.5,n) for i,n in enumerate(seq))
  melody += [(11,76),(12,72),(13.5,67),(15,74),(15.75,77),(16.5,74)]
  track('Brass precision motif',[(t,.17,n,64) for t,n in melody],.2,-.18,'ReaSynth restrained bright triangle/sine mix; short percussive ADSR, slight detune only if supported; no harsh saw lead.')
  track('Oscillating answer',[(7+i*.5,.13,[58,65,62,65][i%4],43) for i in range(8)],.13,.3,'Lower short muted pluck; alternate musical response during output revolution.')
 else:
  title='Orbit Post Office — A Letter Arrives'
  chords=[(0,2,[60,64,67,74]),(2,3,[53,60,64,69]),(5,2,[60,64,67,72])]
  melody=[(.1,76),(.65,79),(1.35,84),(2.25,72),(2.75,76),(3.25,79),(3.75,81),(4.25,84),(4.65,86),(6,79),(6.35,76)]
  track('Letter-flight celesta',[(t,.2,n,64) for t,n in melody],.23,-.1,'ReaSynth sine/triangle, quick gentle attack, short decay, small warm native room effect if available.')
  track('Delivery received',[(5,.16,79,67),(5.13,.16,84,65),(5.3,.24,88,61)],.2,.16,'Higher bell-like ReaSynth sine pluck, soft short release; 5s received-state accent.')
 track('Warm harmonic bed',[(start+.015,d-.08,n,36) for start,d,notes in chords for n in notes],.1,0,'Soft ReaSynth sine pad; attack 150–250ms, modest sustain, release 200–350ms. Keep quieter than lead; avoid sub buildup.')
 track('Rounded bass',[(start,.75,notes[0]-12,52) for start,d,notes in chords],.18,0,'Pure/mostly sine ReaSynth bass, quick attack and 150ms release; no distortion.')
 # The two preprogrammed procedural SFX tracks are explicitly source synthesis,
 # independently editable audio items in REAPER, never described as native instruments.
 spec=importlib.util.spec_from_file_location('showcase_sources',Path(__file__).with_name('showcase_scores.py'));mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 source=mod.score(case_id,duration);sfx=[]
 for name in ['mechanical','accents']:
  # Received chime is authored in native MIDI for Orbit, so omit duplicate accent source.
  if case_id=='orbit-post-office' and name=='accents':continue
  x=source[name];path=root/(name+'-source.wav');mod.write(path,x)
  sfx.append(dict(name=name+' procedural SFX',type='audio',wav_path=str(path),start_seconds=0,duration_seconds=duration,gain_linear=1,pan=0,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),source_kind='Original deterministic mathematical synthesis, not recorded Foley or native instrument'))
 result=dict(case_id=case_id,title=title,bpm=120,duration_seconds=duration,sample_rate=48000,tracks=tracks,sfx=sfx,audio_license='CC0-1.0',code_license='MIT',visual_license='Unchanged rights reserved; excluded from site MIT',composition='Original authored MIDI notes for actual native REAPER ReaSynth tracks; bounded procedural SFX generation. No AI-audio service, samples or third-party recordings.',notes='Native instrument/effect settings must be verified from actual host parameter schemas. Render exact duration; preserve at least -1 dBFS peak headroom. Fine impact timing visually sampled ±0.25s.',listening_review=False)
 (root/'score-recipe.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));return result
if __name__=='__main__':
 import sys
 generate(sys.argv[1],sys.argv[2])
