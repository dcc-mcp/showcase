import json
from pathlib import Path
from dcc_mcp_core.skill import skill_entry,skill_success
from .native import R,audit
from .score_recipe import generate,CASES

@skill_entry
def main(output_dir: str, case_id: str):
 if case_id not in CASES:raise ValueError('Unsupported public film')
 root=Path(output_dir).resolve();p=R.EnumProjects(-1,'',4096)[0]
 if root.exists() and any(root.iterdir()):raise FileExistsError('Output must be new and empty')
 if R.CountTracks(p) or R.IsProjectDirty(p):raise RuntimeError('Requires empty clean project')
 recipe=generate(root,case_id);duration=recipe['duration_seconds'];R.SetCurrentBPM(p,recipe['bpm'],True)
 R.GetSetProjectInfo(p,'PROJECT_SRATE',48000,True);R.GetSetProjectInfo(p,'PROJECT_SRATE_USE',1,True)
 settings=[]
 for track in recipe['tracks']:
  for note in track['notes']:
   if not 0<=note['start_seconds']<duration or not 0<note['duration_seconds']<=duration-note['start_seconds'] or not 0<=note['pitch']<=127 or not 1<=note['velocity']<=127:raise ValueError('Recipe has invalid MIDI event')
 for index,track in enumerate(recipe['tracks']):
  R.InsertTrackAtIndex(index,True);tr=R.GetTrack(p,index)
  R.GetSetMediaTrackInfo_String(tr,'P_NAME',track['name'],True);R.SetMediaTrackInfo_Value(tr,'D_VOL',track['gain_linear']);R.SetMediaTrackInfo_Value(tr,'D_PAN',track['pan'])
  fx=R.TrackFX_AddByName(tr,'ReaSynth (Cockos)',False,1)
  if fx<0:raise RuntimeError('Stock ReaSynth is unavailable')
  schema={R.TrackFX_GetParamName(tr,fx,i,'',256)[4]:i for i in range(R.TrackFX_GetNumParams(tr,fx))}
  pad='harmonic' in track['name'].lower();bass='bass' in track['name'].lower()
  vals={'Attack':.4 if pad else .008,'Release':.055 if pad else .025,'Decay':.055 if pad else .011,'Sustain':.45 if pad else .06,'Volume':.65,'Square mix':.025 if case_id=='brass-relay' and not (pad or bass) else 0,'Saw mix':0,'Triangle mix':.2 if case_id=='brass-relay' and not (pad or bass) else .08 if not bass else 0,'Extra sine mix':0}
  applied={}
  for name,value in vals.items():
   if name not in schema:raise RuntimeError('Unexpected stock instrument schema: missing '+name)
   i=schema[name];R.TrackFX_SetParam(tr,fx,i,value);applied[name]=R.TrackFX_GetFormattedParamValue(tr,fx,i,'',256)[4]
  settings.append({'track':track['name'],'fx':R.TrackFX_GetFXName(tr,fx,'',256)[3],'parameters':applied})
  item=R.CreateNewMIDIItemInProj(tr,0,duration,False)[0];take=R.GetActiveTake(item)
  for note in track['notes']:
   start=R.MIDI_GetPPQPosFromProjTime(take,note['start_seconds']);end=R.MIDI_GetPPQPosFromProjTime(take,note['start_seconds']+note['duration_seconds'])
   result=R.MIDI_InsertNote(take,False,False,start,end,0,note['pitch'],note['velocity'],True)
   if not result[0]:raise RuntimeError('Native MIDI insertion failed')
  R.MIDI_Sort(take)
 for source in recipe['sfx']:
  index=R.CountTracks(p);R.InsertTrackAtIndex(index,True);tr=R.GetTrack(p,index);R.GetSetMediaTrackInfo_String(tr,'P_NAME',source['name'],True)
  R.SetMediaTrackInfo_Value(tr,'D_VOL',source['gain_linear']);R.SetMediaTrackInfo_Value(tr,'D_PAN',source['pan'])
  item=R.AddMediaItemToTrack(tr);take=R.AddTakeToMediaItem(item);pcm=R.PCM_Source_CreateFromFile(source['wav_path']);R.SetMediaItemTake_Source(take,pcm)
  for name,value in [('D_POSITION',source['start_seconds']),('D_LENGTH',source['duration_seconds']),('D_FADEINLEN',0),('D_FADEOUTLEN',0)]:R.SetMediaItemInfo_Value(item,name,value)
  source['wav_path']=Path(source['wav_path']).name
 R.GetSetProjectInfo_String(p,'PROJECT_TITLE',recipe['title'],True);R.GetSetProjectInfo_String(p,'PROJECT_AUTHOR','DCC-MCP original score',True);R.UpdateArrange()
 project=root/'Score.rpp';R.Main_SaveProjectEx(p,str(project),8)
 if not project.is_file() or R.IsProjectDirty(p):raise RuntimeError('Native score save failed')
 recipe['native_instruments']=settings;(root/'score-recipe.json').write_text(json.dumps(recipe,ensure_ascii=False,indent=2))
 return skill_success('Original MIDI composed with real native instruments',case_id=case_id,instruments=settings,**audit())
