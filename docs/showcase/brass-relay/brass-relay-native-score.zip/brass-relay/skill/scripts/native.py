from pathlib import Path
from reapy_boost import reascript_api as R

def audit():
 p,_,path,_=R.EnumProjects(-1,'',4096);tracks=[]
 for i in range(R.CountTracks(p)):
  tr=R.GetTrack(p,i);items=[]
  for j in range(R.CountTrackMediaItems(tr)):
   item=R.GetTrackMediaItem(tr,j);take=R.GetActiveTake(item);midi=bool(R.TakeIsMIDI(take))
   row={'is_midi':midi,'start':R.GetMediaItemInfo_Value(item,'D_POSITION'),'duration':R.GetMediaItemInfo_Value(item,'D_LENGTH')}
   if midi:row['notes']=R.MIDI_CountEvts(take,0,0,0)[2]
   else:
    file=R.GetMediaSourceFileName(R.GetMediaItemTake_Source(take),'',4096)[1];row.update(source=file,source_exists=Path(file).is_file())
   items.append(row)
  tracks.append(dict(name=R.GetSetMediaTrackInfo_String(tr,'P_NAME','',False)[3],guid=R.GetSetMediaTrackInfo_String(tr,'GUID','',False)[3],gain=R.GetMediaTrackInfo_Value(tr,'D_VOL'),pan=R.GetMediaTrackInfo_Value(tr,'D_PAN'),fx=[R.TrackFX_GetFXName(tr,f,'',256)[3] for f in range(R.TrackFX_GetCount(tr))],items=items))
 return dict(host=R.GetAppVersion(),project=path,dirty=bool(R.IsProjectDirty(p)),duration=R.GetProjectLength(p),tempo=R.Master_GetTempo(),tracks=tracks,total_midi_notes=sum(i.get('notes',0) for t in tracks for i in t['items']))
