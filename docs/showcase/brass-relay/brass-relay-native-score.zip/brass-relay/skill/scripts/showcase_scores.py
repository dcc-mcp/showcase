"""Original procedural source stems, not REAPER instrument or native render output.
No samples or generative AI. Fixed three-score catalogue; seed 20261009.
Invoke generate(root) through a bounded DCC-MCP skill for qualified production.
Generated audio CC0-1.0; code MIT. Visual asset rights remain unchanged.
"""
import json,hashlib,wave
from pathlib import Path
import numpy as np
SR=48000
TAU=2*np.pi

def hz(n):return 440*2**((n-69)/12)
def smooth(x):
 x=np.clip(x,0,1);return x*x*(3-2*x)
def tone(note,duration,kind='mallet'):
 t=np.arange(round(duration*SR))/SR;f=hz(note)
 if kind=='pad':
  x=(np.sin(TAU*f*t)+.24*np.sin(TAU*f*2.003*t)+.1*np.sin(TAU*f*3*t))*.32
  return x*smooth(t/.25)*smooth((duration-t)/.45)
 if kind=='bass':
  x=(np.sin(TAU*f*t)+.2*np.sin(TAU*2*f*t))*.65
  return x*smooth(t/.012)*np.exp(-t/1.1)*smooth((duration-t)/.1)
 if kind=='metal':
  x=np.sin(TAU*f*t)*np.exp(-t/.26)+.38*np.sin(TAU*f*2.76*t)*np.exp(-t/.08)+.16*np.sin(TAU*f*5.4*t)*np.exp(-t/.04)
 else:
  x=np.sin(TAU*f*t)*np.exp(-t/.42)+.22*np.sin(TAU*f*3.99*t)*np.exp(-t/.13)+.13*np.sin(TAU*f*7*t)*np.exp(-t/.055)
 return x*.6*smooth(t/.003)*smooth((duration-t)/.04)
def click(rng,d=.07,f=520):
 t=np.arange(round(SR*d))/SR
 n=rng.normal(0,1,len(t));n=np.convolve(n,np.ones(4)/4,mode='same')
 return (.35*n+.65*np.sin(TAU*f*t))*np.exp(-t/.018)*smooth(t/.0015)*smooth((d-t)/.006)
def glide(d,f0,f1):
 t=np.arange(round(SR*d))/SR
 return (np.sin(TAU*(f0*t+(f1-f0)*t*t/(2*d)))+.14*np.sin(TAU*71*t))*.35*smooth(t/.04)*smooth((d-t)/.09)
def add(dst,x,start,g=.1,p=0):
 i=round(start*SR);n=min(len(x),len(dst)-i)
 if i<0 or n<=0:return
 a=(p+1)*np.pi/4;dst[i:i+n,0]+=x[:n]*g*np.cos(a);dst[i:i+n,1]+=x[:n]*g*np.sin(a)
def write(path,x):
 q=np.clip(np.rint(x*8388607),-8388608,8388607).astype(np.int32)
 b=np.stack((q&255,(q>>8)&255,(q>>16)&255),axis=-1).astype(np.uint8).tobytes()
 with wave.open(str(path),'wb') as w:w.setnchannels(2);w.setsampwidth(3);w.setframerate(SR);w.writeframes(b)
def score(slug,duration):
 rng=np.random.default_rng(20261009);N=duration*SR
 tr={k:np.zeros((N,2),dtype=np.float64) for k in ['melody','harmony','bass','mechanical','accents']}
 if slug=='crystal-freight-native-film':
  chords=[(0,4,[60,64,67,74]),(4,3,[57,60,64,71]),(7,3,[53,57,60,67]),(10,4,[55,59,62,69]),(14,4,[60,64,67,74]),(18,2,[48,60,64,67])]
  melody=[(0,72),(.75,76),(1.5,79),(2.5,76),(3,74),(4,72),(4.5,76),(5,79),(5.75,81),(6.5,79),(7,77),(8.5,76),(9.25,74),(10,74),(10.5,79),(11,83),(11.75,81),(12.5,79),(13,76),(14,79),(15,76),(16,74),(17,72),(18,76),(18.5,72)]
  for t,n in melody:add(tr['melody'],tone(n,1.1),t,.16,p=(-.18 if n%2 else .18))
  for a,b in [(4,6.8),(10,13.75)]:
   for t in np.arange(a,b,.25):add(tr['mechanical'],click(rng,f=260 if round(t*4)%2 else 420),t,.105,p=-.4+.8*(t-a)/(b-a))
  add(tr['mechanical'],glide(.9,175,95),7.3,.18)
  add(tr['mechanical'],glide(1.1,100,210),8.45,.11)
  add(tr['accents'],click(rng,.18,100),8.2,.28)
  add(tr['accents'],tone(88,1.2,'metal'),8.22,.16)
  add(tr['accents'],tone(84,1.2),14,.09)
 elif slug=='brass-relay':
  chords=[(0,3,[50,57,62,65]),(3,4,[50,57,62,69]),(7,4,[46,53,58,65]),(11,4,[48,55,60,64]),(15,3,[50,57,62,65])]
  melody=[(0,74),(1,77),(2,81)]
  for start,seq in [(3,[74,77,81,77,74,69,72,77]),(7,[70,74,77,74,70,65,69,74])]:melody.extend((start+i*.5,n) for i,n in enumerate(seq))
  melody += [(11,76),(12,72),(13.5,67),(15,74),(15.75,77),(16.5,74)]
  for t,n in melody:add(tr['melody'],tone(n,.85,'metal'),t,.14,p=.22 if int(t*2)%2 else -.22)
  for i,t in enumerate(np.arange(3,11,.5)):add(tr['mechanical'],click(rng,.06,460 if i%2 else 700),t,.09,p=.35 if i%2 else -.35)
  for t in [3,7]:add(tr['accents'],tone(86,.9,'metal'),t,.1)
  add(tr['accents'],glide(.22,420,170),11,.055)
 else:
  chords=[(0,2,[60,64,67,74]),(2,3,[53,60,64,69]),(5,2,[60,64,67,72])]
  melody=[(.1,76),(.65,79),(1.35,84),(2.25,72),(2.75,76),(3.25,79),(3.75,81),(4.25,84),(4.65,86),(6,79),(6.35,76)]
  for t,n in melody:add(tr['melody'],tone(n,.7),t,.145,p=.15 if n%2 else -.15)
  add(tr['mechanical'],click(rng,.08,850),2.05,.1)
  add(tr['mechanical'],glide(.48,360,860),2.15,.075,p=.2)
  for t,n in [(5,79),(5.13,84),(5.3,88)]:add(tr['accents'],tone(n,.9,'metal'),t,.14)
 for start,d,notes in chords:
  for n in notes:add(tr['harmony'],tone(n,d,'pad'),start,.057,p=-.25 if n%2 else .25)
  for t in np.arange(start,start+d,2):add(tr['bass'],tone(notes[0]-12,min(1.7,d),'bass'),t,.09)
 # Ending fade belongs to procedural sources; actual REAPER also applies mix settings.
 env=smooth(np.arange(N)/SR/.008)*smooth((N-1-np.arange(N))/SR/.18)
 for k in tr:tr[k]*=env[:,None]
 return tr

def generate(output_dir):
 root=Path(output_dir).resolve()
 if root.exists() and any(root.iterdir()):raise FileExistsError('Output must be new/empty')
 root.mkdir(parents=True,exist_ok=True);allmeta=[]
 for slug,duration,title in [('crystal-freight-native-film',20,'Crystal Freight — Little Quarry Waltzless Journey'),('brass-relay',18,'Brass Relay — Clockwork Dialogue'),('orbit-post-office',7,'Orbit Post Office — A Letter Arrives')]:
  folder=root/slug;folder.mkdir();tr=score(slug,duration);tracks=[]
  for name,x in tr.items():
   path=folder/(name+'.wav');write(path,x)
   tracks.append(dict(name=name,wav_path=str(path),gain_linear=1.0,pan=0,frames=len(x),peak=float(np.max(np.abs(x))),rms=float(np.sqrt(np.mean(x*x))),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
  mix=sum(tr.values());meta=dict(title=title,slug=slug,bpm=120,duration_seconds=duration,sample_rate=SR,bit_depth=24,channels=2,tracks=tracks,source_mix_peak=float(np.max(np.abs(mix))),source_mix_rms=float(np.sqrt(np.mean(mix*mix))),source_kind='Deterministic original mathematical synthesis in external DCC-MCP skill process; not a REAPER instrument and not yet a native render.',audio_license='CC0-1.0',third_party_samples=False,seed=20261009,listening_review=False)
  if not np.isfinite(mix).all() or np.max(np.abs(mix))>=.95:raise RuntimeError('Numerical signal check failed')
  (folder/'metadata.json').write_text(json.dumps(meta,indent=2,ensure_ascii=False));allmeta.append(meta)
 (root/'manifest.json').write_text(json.dumps(allmeta,indent=2,ensure_ascii=False));return allmeta
if __name__=='__main__':
 import sys
 generate(sys.argv[1])
