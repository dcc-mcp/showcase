Crystal Freight — corrected native publication

OpenSCAD kit: openscad/crystal-freight-kit.scad
Blender action: blender/crystal-freight.blend
Blender stills: blender/hero-view.blend and blender/detail-view.blend
Earlier matched-pose reconstruction: development/before-matched-pose.blend
Corrected editor: kdenlive/project.kdenlive

CORE: SCAD and Blender sources are self-contained. Kdenlive requires all 122 PNGs from the FULL companion. Do not interpret the compact ZIP as a self-contained film-media bundle.
FULL: includes the corrected native project and all 122 files under kdenlive/media, plus all compact native assets. Extract into a fresh directory. No old package must be overwritten.

Recorded software: OpenSCAD 2021.01; Blender 4.3.2; Kdenlive 24.12.3 / MLT 7.30.0. DejaVu Sans is required for matching editable captions and is not included. Native render/output paths are relative; save new edits to a new copy.

Read LICENSES.md before reuse. The repository MIT license does not apply to these case assets. No additional artwork license or public-domain waiver is granted.

Read validation.json and METHODS.md for the tested scope and remaining parameter-Undo/cross-environment limits. This archive assembly performed no new host run. The SCAD attribution comment has one suffix removed; every other SCAD byte and all BLEND/editor/PNG bytes are unchanged. See source-header-change.json. Historical MCP evidence keeps its original authoring hashes. MEMBER-MANIFEST.json binds every other member; it does not hash itself.
