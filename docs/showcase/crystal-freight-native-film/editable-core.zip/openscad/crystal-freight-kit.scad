// Crystal Freight: original parametric narrow-gauge rail and trestle kit.
// All dimensions millimetres. Z up. Centerline a=5800, b=3700; gauge=600.
// Author: OpenAI assistant for the requesting user.
a=5800; b=3700; gauge=600; rail_width=48; rail_height=80;
track_z=700; sleeper_count=112; segment_count=192;
part="all";
function C(t)=[a*cos(t),b*sin(t)];
function N(t)=let(x=cos(t)/a,y=sin(t)/b,l=sqrt(x*x+y*y)) [x/l,y/l];
function offset(t,r)=C(t)+r*N(t);
module rail(r){
  outer=[for(i=[0:segment_count-1]) offset(i*360/segment_count,r+rail_width/2)];
  inner=[for(i=[0:segment_count-1]) offset((segment_count-1-i)*360/segment_count,r-rail_width/2)];
  translate([0,0,track_z]) linear_extrude(rail_height)
    polygon(concat(outer,inner), [ [for(i=[0:segment_count-1]) i], [for(i=[segment_count:2*segment_count-1]) i] ]);
}
module sleepers(){for(i=[0:sleeper_count-1])let(t=i*360/sleeper_count,c=C(t),n=N(t))
  translate([c[0],c[1],track_z-65]) rotate([0,0,atan2(n[1],n[0])]) cube([1020,125,130],center=true);
}
module beam(p,q,w){d=q-p;l=norm(d);translate((p+q)/2)
  rotate([0,acos(d[2]/l),atan2(d[1],d[0])]) cylinder(h=l,r=w,center=true,$fn=4);
}
module trestle(){
 for(t=[198:12:342])let(c=C(t),n=N(t),l=[c[0]+480*n[0],c[1]+480*n[1]],r=[c[0]-480*n[0],c[1]-480*n[1]]){
   for(p=[l,r])translate([p[0],p[1],-380])cube([160,160,1860],center=true);
   beam([l[0],l[1],-1250],[r[0],r[1],450],80);
   beam([r[0],r[1],-1250],[l[0],l[1],450],80);
   translate([c[0],c[1],510])rotate([0,0,atan2(n[1],n[0])])cube([1220,230,150],center=true);
 }
 for(r=[-400,400])for(i=[0:35])let(t=194+i*4.75,p=offset(t,r),q=offset(t+4.75,r))
  beam([p[0],p[1],480],[q[0],q[1],480],100);
}
if(part=="rails"||part=="all")for(r=[-gauge/2,gauge/2])rail(r);
if(part=="sleepers"||part=="all")sleepers();
if(part=="trestle"||part=="all")trestle();
