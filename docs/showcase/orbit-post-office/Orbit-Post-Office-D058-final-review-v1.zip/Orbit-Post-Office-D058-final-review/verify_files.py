"""Read-only delivery verification; no native launch or network access."""
from pathlib import Path
import hashlib, json
root = Path(__file__).resolve().parent
manifest = json.loads((root / "MANIFEST.json").read_text())
expected = manifest["files"]
actual = {str(p.relative_to(root)) for p in root.rglob("*") if p.is_file()}
assert actual == set(expected) | {"MANIFEST.json"}, "Unexpected or missing members (run before native open)"
for name, record in expected.items():
    p = root / name
    assert not p.is_symlink() and p.stat().st_size == record["bytes"], name
    assert hashlib.sha256(p.read_bytes()).hexdigest() == record["sha256"], name
print(f"PASS: {len(expected)} members match the manifest; this is file-only verification")
