# Authoring, editing and reuse brief

This is a reconstruction of the creative brief from the delivered artifact and recorded work, not a verbatim original user prompt. It conveys the design goal; it does not guarantee an identical redraw or runtime on another machine.

## Reusable creative prompt

Create Orbit Post Office, a small native orbital mail game with warm paper, navy ink and restrained coral/mint accents. Make eight transparent 512 × 512 layered GIMP assets: sealed envelope, open envelope, priority parcel, orbital stamp, dispatch arrow, accepted seal, return seal and arrival beacon. Preserve separable painted shapes and editable stamp text. The image family should read at 128 and 64 pixels and remain legible on light and dark backgrounds.

Build a 1280 × 720 Godot scene with three clearly numbered planet routes: 1 Lumen, 2 Moss, 3 Ember. Read a letter, choose its addressed planet and dispatch within its launch window. Keep the countdown near the address. Wrong routes must be rejected. Late letters return and can be reflown. A shift contains eight deliveries. Make pause, focused keyboard navigation, Space dispatch and R restart clear; the restart clears counters and the ledger. Keep the artwork editable and use relative asset paths. Preserve the implementation's actual timing and rules unless deliberately creating a new version.

## Edit the actual native project

1. Extract into a new directory, then run `python3 verify_files.py` before any native open. Native imports will create caches afterwards.
2. Import `game/project.godot` with the pinned Godot version described in `RUNTIME-PINS.json`. Open `game/scenes/orbit_post.tscn` to inspect the 29-node scene and six signal connections. Edit the existing script at `game/scripts/orbit_post.gd` for rule changes. The upstream editor plugin and runtime autoload are enabled in this exact source; read their startup behavior in `README.md`.
3. Open a corresponding `game/source-art/*.xcf` in GIMP 3.0.4. Select its existing layers instead of flattening the document. The orbital stamp includes two editable text layers using DejaVu Sans Book. Save a new XCF variant before editing. Export the matching transparent PNG at the asset's 512 × 512 size, preserving sRGB and straight alpha. Replace the corresponding relative asset in a copied game only when ready to make a new version; that changes its hashes and invalidates the old evidence's byte-identity claim.
4. Run Project. Use mouse controls or Space to begin/read/send/retry; 1/2/3 select routes, P pauses and R restarts. Tab and Enter use native focus. The automation replay selector is a separate fixture and the fixture input ledger is not a record of the externally operated mouse/keyboard events.
5. For actual GIMP MCP reproduction, follow `gimp-reproduction/REPRODUCE.md` and its exact source/build/runtime pins. The four native reproduction batches compared 40 XCFs byte for byte and 88 PNGs by decoded RGBA. These results are scoped to the recorded environment.
6. For Godot MCP authoring/review, use the pinned upstream base plus unpublished patch instructions in the reference ZIP. The complete normalized authoring-run07 trace records the original create-scene/add-node/property/script/signal/texture calls. It is evidence for reconstruction, not an executable script or a turnkey copy of the original private supervisor.

`ASSET-INDEX.json` gives all roles, current relative paths, byte sizes, dimensions, alpha/color encoding, native layer counts, hashes and scoped rights. Original artwork, game content and recipe remain rights reserved. This brief does not grant redistribution or new licensing rights; upstream MIT and font notices retain their stated scopes.
