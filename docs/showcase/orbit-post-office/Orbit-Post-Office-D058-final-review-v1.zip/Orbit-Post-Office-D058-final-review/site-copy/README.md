# Page copy and asset handoff

`case-review.json` updates the earlier private case draft with the sealed native evidence. It is copy for review, not a live site, checkout, published URL or published-case increment. Paths are relative to the package root. The parent owns final site code and any publication decision. Bind the actual final archive name, size and SHA-256 from the external package receipt when constructing its download metadata.

Lead image: `evidence/restored-normal-delivery.png`. Its pixels are the exact accepted normal-delivery native capture. Other captions distinguish a late-return PNG, a focused-shortcut PNG and replay in-flight frames. A populated reset is verified by complete snapshots; no reset image exists. Use `game/assets/orbit-post/` for the eight actual transparent art assets and `ASSET-INDEX.json` for role labels.

Keep retained failed logs/performance gates and the unpublished adapter qualification visible in scope text. Agent visual review is complete for the viewed native frame; do not infer user endorsement or make unrequested human approval a new production gate.
