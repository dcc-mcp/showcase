@tool
extends EditorPlugin

const Commands = preload("res://addons/dcc_mcp_godot/commands.gd")
const RUNTIME_AUTOLOAD_NAME := "DccMcpRuntimePeer"
const RUNTIME_AUTOLOAD_PATH := "res://addons/dcc_mcp_godot/runtime_peer.gd"
const BOOTSTRAP_STATUS_PATH := "res://.godot/dcc_mcp_godot_bootstrap.json"
const HIDE_WINDOW_ENV := "DCC_MCP_GODOT_HIDE_WINDOW"
const HIDE_WINDOW_ARG := "--dcc-mcp-hide-window"
const PREVIEW_REQUEST_TIMEOUT_MS := 20000


class RuntimeDebugger extends EditorDebuggerPlugin:
	# The bridge supplies its configured timeout plus transport allowance.
	# Legacy packets and authorized commits use bounded lifecycle retention.
	const MAX_REPLY_TIMEOUT_MSEC := 9007199254740991
	const MAX_PENDING_REQUESTS := 128
	const MAX_PROCESS_ID := 4294967295
	const MAX_DEBUGGER_SESSION_ID := 2147483647
	var owner
	var _ready_sessions: Dictionary = {}
	var _pending_requests: Dictionary = {}
	var _request_serial := 0

	func _init(plugin_owner) -> void:
		owner = plugin_owner

	func _session_for_id(session_id: int):
		return get_session(session_id)

	func _now_msec() -> int:
		return Time.get_ticks_msec()

	func _setup_session(session_id: int) -> void:
		if session_id < 0 or session_id > MAX_DEBUGGER_SESSION_ID:
			return
		var session = _session_for_id(session_id)
		_ready_sessions.erase(session_id)
		_discard_session_requests(session_id)
		if session == null:
			return
		# Transport attachment is not proof this process registered our capture.
		session.started.connect(_invalidate_session.bind(session_id, session.get_instance_id()))
		session.stopped.connect(_invalidate_session.bind(session_id, session.get_instance_id()))

	func _invalidate_session(session_id: int, instance_id: int) -> void:
		var session = _ready_sessions.get(session_id)
		if session != null and session.get_instance_id() == instance_id:
			_ready_sessions.erase(session_id)
		_discard_session_requests(session_id, instance_id)

	func _discard_session_requests(session_id: int, instance_id := -1) -> void:
		for request_id in _pending_requests.keys():
			var pending: Dictionary = _pending_requests[request_id]
			if pending.session_id == session_id and (instance_id == -1 or pending.session.get_instance_id() == instance_id):
				_pending_requests.erase(request_id)

	func _is_ready_session(session_id: int) -> bool:
		if session_id < 0 or session_id > MAX_DEBUGGER_SESSION_ID:
			return false
		var session = _session_for_id(session_id)
		return session != null and session.is_active() and _ready_sessions.get(session_id) == session

	func _ready_session_id() -> int:
		for session_id in _ready_sessions:
			if _is_ready_session(session_id):
				return session_id
		return -1

	func has_ready_session() -> bool:
		return _ready_session_id() >= 0

	func _prune_pending_requests() -> void:
		var now := _now_msec()
		for request_id in _pending_requests.keys():
			var pending: Dictionary = _pending_requests[request_id]
			if (pending.deadline_msec > 0 and now >= pending.deadline_msec) or not _is_ready_session(pending.session_id) or _ready_sessions.get(pending.session_id) != pending.session:
				_pending_requests.erase(request_id)

	func discard_bridge_requests() -> void:
		# The replacement WebSocket cannot inherit an earlier caller ID.
		_pending_requests.clear()

	func _has_capture(capture: String) -> bool:
		return capture == "dcc_mcp_godot"

	func _capture(message: String, data: Array, session_id: int) -> bool:
		if message == "dcc_mcp_godot:ready":
			if session_id < 0 or session_id > MAX_DEBUGGER_SESSION_ID:
				return true
			var session = _session_for_id(session_id)
			if session != null and session.is_active():
				_ready_sessions[session_id] = session
			return true
		if message == "dcc_mcp_godot:response" and not data.is_empty():
			_prune_pending_requests()
			if not data[0] is Dictionary or not data[0].has("id"):
				return true
			var wire_id := str(data[0].id)
			var pending = _pending_requests.get(wire_id)
			if pending == null or pending.session_id != session_id or not _is_ready_session(session_id) or _ready_sessions.get(session_id) != pending.session:
				return true
			_pending_requests.erase(wire_id)
			var response: Dictionary = data[0].duplicate(true)
			response.id = pending.request_id
			if pending.action == "get_runtime_status" and response.get("result") is Dictionary and response.result.get("connected") == true:
				var process_id = response.result.get("process_id")
				if not _valid_process_id(process_id):
					response.erase("result")
					response["error"] = "runtime_process_identity_invalid"
				else:
					# JSON may normalize an integer Variant to an integral float.
					# Emit explicit integers after bounds checks; only the editor
					# knows which debugger session supplied this exact reply.
					response.result["process_id"] = int(process_id)
					response.result["debugger_session_id"] = int(session_id)
			owner._handle_runtime_response(response)
			return true
		return false

	func _valid_process_id(value) -> bool:
		if value is int:
			return value >= 1 and value <= MAX_PROCESS_ID
		if value is float:
			return is_finite(value) and value >= 1 and value <= MAX_PROCESS_ID and floor(value) == value
		return false

	func _valid_reply_timeout(value) -> bool:
		if value is int:
			return value >= 0 and value <= MAX_REPLY_TIMEOUT_MSEC
		if value is float:
			return is_finite(value) and value >= 0 and value <= MAX_REPLY_TIMEOUT_MSEC and floor(value) == value
		return false

	func send_request(request_id, action: String, params: Dictionary, reply_timeout_msec = 0) -> Dictionary:
		_prune_pending_requests()
		if not _valid_reply_timeout(reply_timeout_msec):
			return {"sent": false, "reason": "runtime_reply_lifetime_invalid"}
		var session_id := _ready_session_id()
		if session_id < 0:
			return {"sent": false, "reason": "no_ready_session"}
		if _pending_requests.size() >= MAX_PENDING_REQUESTS:
			return {"sent": false, "reason": "runtime_request_capacity_exhausted"}
		var session = _ready_sessions[session_id]
		# Caller IDs and debugger slots may be reused. This instance's serial
		# never resets on a game restart; instance identity separates reloads.
		_request_serial += 1
		var wire_id := "dcc_mcp:%d:%d" % [get_instance_id(), _request_serial]
		# Authorized typed commits already wait for a definitive result or
		# connection loss in bridge.py. Expiring that reply would strand the
		# committed mutation. Keep its bounded slot until reply/lifecycle end.
		var deadline := 0 if action == "commit_typed_action" or reply_timeout_msec == 0 else _now_msec() + int(reply_timeout_msec)
		_pending_requests[wire_id] = {
			"request_id": request_id, "session_id": session_id, "session": session,
			"action": action, "deadline_msec": deadline,
		}
		session.send_message("dcc_mcp_godot:request", [{"id": wire_id, "action": action, "params": params}])
		return {"sent": true}

var _socket := WebSocketPeer.new()
var _commands
var _hello_sent := false
var _next_reconnect_ms := 0
var _debugger
var _pending_guarded_commits: Dictionary = {}
var _pending_preview_request: Dictionary = {}


func _enter_tree() -> void:
	_write_bootstrap_status("starting")
	_apply_unattended_window_mode()
	_commands = Commands.new(self)
	_debugger = RuntimeDebugger.new(self)
	add_debugger_plugin(_debugger)
	if not ProjectSettings.has_setting("autoload/%s" % RUNTIME_AUTOLOAD_NAME):
		add_autoload_singleton(RUNTIME_AUTOLOAD_NAME, RUNTIME_AUTOLOAD_PATH)
		ProjectSettings.save()
	set_process(true)
	_connect_bridge()
	_write_bootstrap_status("ready")


func _exit_tree() -> void:
	set_process(false)
	if _commands != null:
		_commands.capabilities().cancel_pending_preview()
	_pending_preview_request = {}
	if _socket != null:
		_socket.close()
	if _debugger != null:
		remove_debugger_plugin(_debugger)
	_write_bootstrap_status("stopped")


func _apply_unattended_window_mode() -> void:
	# Unattended hosts render from a windowed editor instead of --headless,
	# which degrades Godot to rendering/dummy and cannot read back pixels.
	#
	# This is best-effort only. Measured on 4.7.2: the editor main window
	# reasserts its own visibility, so `root.visible = false` set here does not
	# stick, and Windows clamps an off-screen move back onto the monitor. The
	# mechanism that measurably removes the window from the interactive desktop
	# is launching the whole process on a private Windows desktop; see
	# `dcc-mcp-godot unattended`. Never minimize instead: under
	# gl_compatibility a minimized window reports success while rendering an
	# entirely black frame.
	if not _unattended_hide_requested(): return
	var tree := get_tree()
	if tree == null: return
	var root := tree.root
	if root == null: return
	# Never minimize instead of hiding: under gl_compatibility a minimized
	# window reports success while rendering an entirely black frame.
	root.visible = false


func _unattended_hide_requested() -> bool:
	if _truthy_env(HIDE_WINDOW_ENV): return true
	return OS.get_cmdline_user_args().has(HIDE_WINDOW_ARG)


func _truthy_env(name: String) -> bool:
	var raw := OS.get_environment(name).strip_edges().to_lower()
	return raw != "" and raw != "0" and raw != "false" and raw != "no"


func _write_bootstrap_status(status: String, message := "") -> void:
	var directory_error := DirAccess.make_dir_recursive_absolute(
		ProjectSettings.globalize_path("res://.godot")
	)
	if directory_error != OK:
		push_error("DCC-MCP bootstrap diagnostics directory failed: %s" % error_string(directory_error))
		return
	var file := FileAccess.open(BOOTSTRAP_STATUS_PATH, FileAccess.WRITE)
	if file == null:
		push_error("DCC-MCP bootstrap diagnostics file failed: %s" % error_string(FileAccess.get_open_error()))
		return
	file.store_string(JSON.stringify({
		"status": status,
		"message": message,
		"engine_version": Engine.get_version_info().get("string", "unknown"),
	}))


func _disable_plugin() -> void:
	if ProjectSettings.has_setting("autoload/%s" % RUNTIME_AUTOLOAD_NAME):
		remove_autoload_singleton(RUNTIME_AUTOLOAD_NAME)
		ProjectSettings.save()


func _process(_delta: float) -> void:
	# Tool-script reloads can briefly clear initialized members before the new
	# plugin instance enters the tree. Recreate the peer instead of polling a
	# stale/null object left by the previous instance.
	if _socket == null:
		_connect_bridge()
		return
	_socket.poll()
	var state := _socket.get_ready_state()
	if state == WebSocketPeer.STATE_OPEN:
		if not _hello_sent:
			_send_json({
				"type": "hello",
				"client": "godot",
				"version": Engine.get_version_info().get("string", "unknown"),
			})
			_hello_sent = true
		while _socket.get_available_packet_count() > 0:
			_handle_packet(_socket.get_packet().get_string_from_utf8())
	elif state == WebSocketPeer.STATE_CLOSED and Time.get_ticks_msec() >= _next_reconnect_ms:
		_connect_bridge()
	_advance_pending_preview()


func _advance_pending_preview() -> void:
	if _pending_preview_request.is_empty(): return
	var request_id = _pending_preview_request.get("id")
	var pending: Variant = _commands.capabilities().poll_pending_preview()
	if pending == null:
		if Time.get_ticks_msec() > int(_pending_preview_request.get("deadline_ms")):
			_commands.capabilities().cancel_pending_preview()
			_pending_preview_request = {}
			_send_json({
				"type": "response",
				"id": request_id,
				"error": {
					"code": -32003,
					"message": "Scene preview did not finish: the editor stopped rendering frames",
				},
			})
		return
	_pending_preview_request = {}
	_send_bridge_result(request_id, pending)


func _send_bridge_result(request_id, result: Dictionary) -> void:
	if result.has("__error__"):
		_send_json({
			"type": "response",
			"id": request_id,
			"error": {"code": -32000, "message": result["__error__"]},
		})
	else:
		_send_json({"type": "response", "id": request_id, "result": result})


func _connect_bridge() -> void:
	# Authorization belongs to one exact WebSocket connection. A replacement
	# connection can never inherit a queued mutation from its predecessor, and a
	# parked scene preview belongs to the connection that requested it, so its
	# host-side viewport is released too.
	_pending_guarded_commits.clear()
	if _debugger != null:
		_debugger.discard_bridge_requests()
	if _commands != null:
		_commands.capabilities().cancel_pending_preview()
	_pending_preview_request = {}
	_socket = WebSocketPeer.new()
	_hello_sent = false
	var url := OS.get_environment("DCC_MCP_GODOT_BRIDGE_URL")
	if url.is_empty():
		url = "ws://127.0.0.1:3847"
	var error := _socket.connect_to_url(url)
	if error != OK:
		_next_reconnect_ms = Time.get_ticks_msec() + 1000


func _handle_packet(text: String) -> void:
	var message = JSON.parse_string(text)
	if not message is Dictionary:
		return
	if message.get("type") == "commit_authorization":
		_handle_commit_authorization(message)
		return
	if message.get("type") != "request":
		return
	if str(message.get("method", "")) == "capability.commit_typed_action":
		_stage_guarded_commit(message)
		return
	_execute_bridge_request(message)


func _stage_guarded_commit(message: Dictionary) -> void:
	var request_id = message.get("id")
	var params = message.get("params", {})
	var fence = params.get("__dcc_mcp_commit_fence") if params is Dictionary else null
	if not fence is Dictionary \
		or fence.keys().size() != 3 \
		or not fence.has_all(["guard_id", "request_id", "request_digest"]) \
		or not fence.guard_id is String \
		or str(fence.guard_id).length() != 32 \
		or fence.request_id != request_id \
		or not fence.request_digest is String \
		or str(fence.request_digest).length() != 64 \
		or _pending_guarded_commits.has(str(fence.guard_id)):
		_send_json({
			"type": "response",
			"id": request_id,
			"error": {"code": -32003, "message": "typed_action_commit_fence_invalid"},
		})
		return
	var guarded_params: Dictionary = params.duplicate(true)
	guarded_params.erase("__dcc_mcp_commit_fence")
	var guard_id := str(fence.guard_id)
	_pending_guarded_commits[guard_id] = {
		"id": request_id,
		"method": message.get("method"),
		"params": guarded_params,
		"request_digest": str(fence.request_digest),
	}
	_send_json({
		"type": "commit_intent",
		"guard_id": guard_id,
		"request_id": request_id,
		"request_digest": str(fence.request_digest),
	})


func _handle_commit_authorization(message: Dictionary) -> void:
	if message.keys().size() != 6 \
		or not message.has_all([
			"type", "guard_id", "request_id", "request_digest", "authorized", "reason",
		]) \
		or not message.guard_id is String:
		return
	var guard_id := str(message.guard_id)
	var pending = _pending_guarded_commits.get(guard_id)
	if not pending is Dictionary \
		or pending.id != message.request_id \
		or str(pending.request_digest) != str(message.request_digest):
		return
	_pending_guarded_commits.erase(guard_id)
	if not bool(message.authorized) or str(message.reason) != "authorized":
		var terminal_reason := str(message.reason)
		if terminal_reason not in [
			"request_terminal", "request_identity_mismatch", "request_already_authorized",
			"commit_guard_rejected", "host_identity_mismatch",
		]:
			terminal_reason = "request_terminal"
		_send_json({
			"type": "response",
			"id": pending.id,
			"error": {"code": -32004, "message": "typed_action_commit_terminal:%s" % terminal_reason},
		})
		return
	_execute_bridge_request(pending)


func _execute_bridge_request(message: Dictionary) -> void:
	var request_id = message.get("id")
	var result: Dictionary = _commands.execute(
		str(message.get("method", "")),
		message.get("params", {}) as Dictionary,
	)
	if result.has("__deferred_preview__"):
		# A scene render needs real editor frames, so the response is parked and
		# sent from _process once the render has drawn them.
		_pending_preview_request = {
			"id": request_id,
			"deadline_ms": Time.get_ticks_msec() + PREVIEW_REQUEST_TIMEOUT_MS,
		}
		return
	if result.has("__error__"):
		_send_json({
			"type": "response",
			"id": request_id,
			"error": {"code": -32000, "message": result["__error__"]},
		})
	elif result.has("__runtime_action__"):
		var dispatched: Dictionary = _debugger.send_request(request_id, result["__runtime_action__"], result.get("params", {}), message.get("_dcc_mcp_reply_timeout_msec", 0))
		if not dispatched.sent:
			if dispatched.reason == "no_ready_session" and result["__runtime_action__"] == "get_runtime_status":
				_send_json({"type": "response", "id": request_id, "result": {"connected": false, "playing": EditorInterface.is_playing_scene(), "runtime_ready": false}})
			else:
				_send_json({"type": "response", "id": request_id, "error": {
					"code": -32001, "message": str(dispatched.reason),
					"data": {"reason": dispatched.reason, "dispatched": false},
				}})

	else:
		_send_json({"type": "response", "id": request_id, "result": result})


func _handle_runtime_response(payload) -> void:
	if not payload is Dictionary or not payload.has("id"):
		return
	if payload.has("error"):
		_send_json({"type": "response", "id": payload.id, "error": {"code": -32002, "message": str(payload.error)}})
	else:
		_send_json({"type": "response", "id": payload.id, "result": payload.get("result", {})})


func _send_json(value: Dictionary) -> void:
	if _socket != null and _socket.get_ready_state() == WebSocketPeer.STATE_OPEN:
		_socket.send_text(JSON.stringify(value))
