extends Control
## D058 authored gameplay. Written and attached through real MCP, never editor eval.
## Native scene nodes and all eight PNG references must already exist.
const PERIODS := [360, 540, 720]
const OFFSETS := [0, 90, 240]
const RADII := [96.0, 160.0, 224.0]
const DESTINATIONS := [0, 1, 2, 0, 2, 1, 0, 2]
const PLANETS := ["Lumen", "Moss", "Ember"]
const PERIOD_LABELS := ["6 s", "9 s", "12 s"]
const FLIGHT_TICKS := 72
const WINDOW_TICKS := 48
const CENTER := Vector2(424, 382)
const INK := Color("23343b")
const PAPER := Color("f2ead3")
const LIGHT := Color("fff9e8")
const TEAL := Color("307778")
const CORAL := Color("e06c41")
const GOLD := Color("e4b457")
const PLANET_COLORS := [Color("f2ead3"), Color("64aaa1"), Color("e69b7d")]

# Deliberately passive typed-property selector. No code/path/method input.
@export_enum("idle", "success", "late") var replay_request: String = "idle"
var consumed_request: String = "idle"
var replay_mode: String = "idle"
var tick: int = 0
var mission: int = 0
var state: String = "intro"
var selected: int = -1
var deadline: int = -1
var arrival: int = -1
var launch: int = -1
var delivered: int = 0
var late_count: int = 0
var attempts: int = 0
var paused: bool = false
var ledger: Array = []
var inputs: Array = []
var late_skip_until: int = -1
var last_draw_tick: int = -1
var feedback: String = "Eight letters. Three little worlds. One good shift."
var toast_until: int = 0

func _ready() -> void:
	_apply_readable_styles()
	_sync_ui()
	queue_redraw()

func _phase(at_tick: int, planet: int) -> int:
	return (at_tick + OFFSETS[planet]) % PERIODS[planet]

func _planet_position(at_tick: int, planet: int) -> Vector2:
	var angle: float = TAU * float(_phase(at_tick, planet)) / float(PERIODS[planet])
	return CENTER + Vector2(cos(angle), sin(angle)) * RADII[planet]

func _can_launch(at_tick: int, planet: int) -> bool:
	return _phase(at_tick + FLIGHT_TICKS, planet) < WINDOW_TICKS

func _next_launch(at_tick: int, planet: int) -> int:
	var remainder: int = _phase(at_tick + FLIGHT_TICKS, planet)
	return at_tick if remainder < WINDOW_TICKS else at_tick + PERIODS[planet] - remainder

func _reset_shift(mode: String = "idle") -> void:
	tick = 0
	mission = 0
	state = "unread"
	selected = -1
	deadline = -1
	arrival = -1
	launch = -1
	delivered = 0
	late_count = 0
	attempts = 0
	paused = false
	ledger.clear()
	inputs.clear()
	late_skip_until = -1
	replay_mode = mode
	feedback = "Open the letter to see its address."
	toast_until = 0

func _physics_process(_delta: float) -> void:
	if replay_request != consumed_request:
		consumed_request = replay_request
		if replay_request in ["success", "late"]:
			_reset_shift(replay_request)
	if state not in ["intro", "complete"] and not paused:
		tick += 1
		_resolve_arrival()
		if replay_mode != "idle":
			_replay_inputs()
	_sync_ui()
	queue_redraw()

func _open_letter() -> bool:
	if paused or state != "unread":
		return false
	deadline = _next_launch(tick, DESTINATIONS[mission]) + FLIGHT_TICKS + 60
	state = "ready"
	feedback = "Choose %s, then send during its launch window." % PLANETS[DESTINATIONS[mission]]
	return true

func _select(planet: int) -> bool:
	if paused or state != "ready" or planet < 0 or planet > 2:
		return false
	selected = planet
	feedback = "Route set to %s." % PLANETS[planet]
	return true

func _dispatch() -> bool:
	if paused or state != "ready":
		return false
	if selected != DESTINATIONS[mission]:
		feedback = "Check the address: this letter belongs to %s." % PLANETS[DESTINATIONS[mission]]
		return false
	if not _can_launch(tick, selected):
		feedback = "Almost. Watch the countdown beside the address."
		return false
	launch = tick
	arrival = tick + FLIGHT_TICKS
	state = "in_flight"
	attempts += 1
	feedback = "Letter on its way to %s." % PLANETS[selected]
	return true

func _retry() -> bool:
	if paused or state != "return_request":
		return false
	deadline = _next_launch(tick, DESTINATIONS[mission]) + FLIGHT_TICKS + 60
	state = "ready"
	feedback = "Reflight approved. Catch the next window."
	return true

func _resolve_arrival() -> void:
	if state != "in_flight" or tick < arrival:
		return
	var is_late: bool = arrival > deadline
	ledger.append({"mission": mission + 1, "destination": DESTINATIONS[mission], "launch": launch,
		"arrival": arrival, "deadline": deadline, "late": is_late})
	toast_until = tick + 90
	if is_late:
		late_count += 1
		state = "return_request"
		feedback = "Arrived late. Request a reflight to finish this delivery."
	else:
		delivered += 1
		mission += 1
		selected = -1
		state = "complete" if delivered == 8 else "unread"
		feedback = "Shift complete. Every letter found its little world." if state == "complete" else "Delivery accepted. A new letter is waiting."

func _replay_inputs() -> void:
	# Visible, bounded fixture bot uses exactly the gameplay transition methods.
	# This does not replace separate mouse/keyboard acceptance.
	if state == "unread":
		_open_letter()
		_select(DESTINATIONS[mission])
		inputs.append({"tick": tick, "action": "open_and_select", "planet": selected})
		if replay_mode == "late" and mission == 3 and late_count == 0:
			late_skip_until = _next_launch(tick, selected) + PERIODS[selected]
	if state == "return_request" and tick >= arrival + 120:
		_retry()
		inputs.append({"tick": tick, "action": "retry"})
	if state == "ready" and _can_launch(tick, selected):
		if late_skip_until < 0 or mission != 3 or late_count > 0 or tick >= late_skip_until:
			_dispatch()
			inputs.append({"tick": tick, "action": "dispatch", "planet": selected})

func _on_open_pressed() -> void:
	if paused:
		return
	if state in ["intro", "complete"]:
		_reset_shift()
	elif state == "return_request":
		_retry()
	else:
		_open_letter()

func _on_send_pressed() -> void:
	_dispatch()

func _on_lumen_pressed() -> void:
	_select(0)

func _on_moss_pressed() -> void:
	_select(1)

func _on_ember_pressed() -> void:
	_select(2)

func _on_pause_pressed() -> void:
	if state not in ["intro", "complete"]:
		paused = not paused

func _input(event: InputEvent) -> void:
	if not event is InputEventKey:
		return
	if event.keycode not in [KEY_1, KEY_2, KEY_3, KEY_SPACE, KEY_P, KEY_R]:
		return
	# Consume shortcut press, echo and release before focused Button ui_accept.
	# Tab, Enter and mouse still use normal Control focus/navigation behavior.
	get_viewport().set_input_as_handled()
	if not event.pressed or event.echo:
		return
	match event.keycode:
		KEY_1: _select(0)
		KEY_2: _select(1)
		KEY_3: _select(2)
		KEY_SPACE:
			if state == "ready": _dispatch()
			else: _on_open_pressed()
		KEY_P: _on_pause_pressed()
		KEY_R: _reset_shift()

func _apply_readable_styles() -> void:
	var font_sizes := {"Title":38, "Subtitle":18, "ShiftLabel":20, "CardEyebrow":17,
		"Destination":28, "Deadline":18, "AddressHint":18, "StateLabel":19,
		"FieldHeading":17, "Schedule":17, "Instructions":19,
		"Planet0":20, "Planet1":20, "Planet2":20}
	for node_name in font_sizes:
		var label: Label = get_node(node_name)
		label.add_theme_font_size_override("font_size", font_sizes[node_name])
		label.add_theme_color_override("font_color", LIGHT if node_name == "FieldHeading" else INK)
	for node_name in ["OpenButton", "SendButton", "LumenButton", "MossButton", "EmberButton", "PauseButton"]:
		var button: Button = get_node(node_name)
		button.add_theme_font_size_override("font_size", 17)
		button.add_theme_color_override("font_color", LIGHT)
		button.add_theme_color_override("font_hover_color", LIGHT)
		button.add_theme_color_override("font_focus_color", LIGHT)
		button.add_theme_color_override("font_disabled_color", Color("a69e88"))
		for style_name in ["normal", "hover", "pressed", "disabled", "focus"]:
			var style := StyleBoxFlat.new()
			style.bg_color = INK if style_name == "normal" else TEAL
			if style_name == "disabled": style.bg_color = Color("e6dcc4")
			if style_name == "focus":
				style.bg_color = Color.TRANSPARENT
				style.border_color = CORAL
				style.set_border_width_all(3)
			style.set_corner_radius_all(8)
			button.add_theme_stylebox_override(style_name, style)

func _sync_ui() -> void:
	var target: int = DESTINATIONS[mini(mission,7)]
	$ShiftLabel.text = "%02d / 08 delivered" % delivered
	$CardEyebrow.text = "SHIFT COMPLETE" if state == "complete" else "LETTER %02d / 08" % mini(mission + 1,8)
	$Destination.text = "Your first shift" if state == "intro" else ("All delivered" if state == "complete" else ("Sealed letter" if state == "unread" else PLANETS[target]))
	$Deadline.text = "Take your time to learn" if state == "intro" else "Late returns: %d" % late_count
	if state == "ready":
		var wait_ticks: int = _next_launch(tick,target)-tick
		$Deadline.text = "WINDOW OPEN" if wait_ticks == 0 else "Window in %.1f s" % (float(wait_ticks)/60.0)
	$AddressHint.text = "Read. Choose a world. Catch its window."
	if state in ["ready", "in_flight", "return_request"]:
		$AddressHint.text = "Arrive by %05.1f s  |  clock %05.1f s" % [float(deadline)/60.0, float(tick)/60.0]
	$StateLabel.text = "Paused. Press P to continue." if paused else feedback
	$OpenButton.text = "Start shift" if state == "intro" else ("New shift" if state == "complete" else ("Request reflight" if state == "return_request" else "Read letter"))
	$OpenButton.disabled = state in ["ready", "in_flight"] or paused
	$SendButton.text = "   Send letter"
	$SendButton.disabled = state != "ready" or selected != target or not _can_launch(tick,target) or paused
	$DispatchIcon.modulate = Color(1,1,1,0.4) if $SendButton.disabled else Color.WHITE
	$PauseButton.text = "Resume" if paused else "Pause"
	for planet in range(3):
		var button: Button = get_node(["LumenButton", "MossButton", "EmberButton"][planet])
		button.disabled = state != "ready" or paused
		button.text = ("• " if selected == planet else "") + "%d %s" % [planet + 1, PLANETS[planet]]
		var label: Label = get_node("Planet%d" % planet)
		label.position = _planet_position(tick,planet) - Vector2(22,22)
		label.text = str(planet + 1)
	$UnreadIcon.visible = state in ["intro", "unread"]
	$ReadIcon.visible = state in ["ready", "in_flight", "return_request", "complete"]
	$PriorityIcon.visible = mission == 4 and state != "intro"
	$ArrivalIcon.visible = state == "in_flight"
	$AcceptedIcon.visible = delivered > 0 and (tick < toast_until or state == "complete")
	$ReturnIcon.visible = state == "return_request"

func _draw() -> void:
	draw_rect(Rect2(0,0,1280,720), PAPER)
	_round_box(Rect2(32,130,776,506), INK, 18)
	_round_box(Rect2(832,130,416,506), LIGHT, 18)
	draw_line(Vector2(32,112),Vector2(1248,112),Color("c4b898"),1.0)
	for star in range(36):
		var pos := Vector2(56 + (star*173)%724, 182 + (star*97)%408)
		draw_circle(pos, 1.25, Color(0.94,0.92,0.85,0.24))
	for planet in range(3):
		var radius: float = RADII[planet]
		draw_arc(CENTER,radius,0,TAU,128,Color(0.63,0.75,0.72,0.23),1.0,true)
		var window_angle: float = TAU*float(WINDOW_TICKS)/float(PERIODS[planet])
		draw_arc(CENTER,radius,0,window_angle,18,TEAL.lightened(0.3),5.0,true)
		var p := _planet_position(tick,planet)
		draw_circle(p+Vector2(2,4),22,Color(0,0,0,0.23))
		draw_circle(p,22,PLANET_COLORS[planet])
		draw_arc(p,15,0.25,2.65,20,Color(0.13,0.21,0.23,0.22),2.0,true)
		if selected == planet:
			draw_arc(p,26,0,TAU,40,CORAL,2.5,true)
	# A simple original engine-drawn post office and its forecast route.
	_round_box(Rect2(CENTER-Vector2(29,22),Vector2(58,44)),LIGHT,7)
	draw_polyline(PackedVector2Array([CENTER+Vector2(-25,-16),CENTER+Vector2(0,3),CENTER+Vector2(25,-16)]),CORAL,3.0,true)
	if selected >= 0 and state in ["ready", "in_flight"]:
		var endpoint := _planet_position(arrival if state == "in_flight" else tick+FLIGHT_TICKS, selected)
		draw_line(CENTER,endpoint,Color(0.88,0.42,0.25,0.45),2.0,true)
		if state == "in_flight":
			var progress: float = clampf(float(tick-launch)/float(FLIGHT_TICKS),0.0,1.0)
			for tail in range(5):
				var t: float = maxf(0.0,progress-float(tail)*0.065)
				draw_circle(CENTER.lerp(endpoint,t),5.0-float(tail)*0.65,Color(0.88,0.42,0.25,1.0-float(tail)*0.16))
	for index in range(8):
		var color: Color = TEAL if index < delivered else Color("d6ccb2")
		_round_box(Rect2(856+index*46,592,34,6),color,3)
	last_draw_tick = tick

func _round_box(rect: Rect2, color: Color, radius: int) -> void:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.set_corner_radius_all(radius)
	draw_style_box(style,rect)
