# Orbit Post Office: GIMP reproduction component

This is the final GIMP recipe/documentation component for the eight original postal UI assets. It contains no artwork copies or Godot project. The existing editable-artwork review package remains separate and unchanged. Opening its XCFs does not require this MCP recipe or its adapter wheel.

The original standalone recipe completed four fresh native GIMP runs, producing all eight roles with native save/reopen, editable-layer/text checks and decoded-pixel checks. This revision supplies an explicit binding for the actual merged adapter source and closes the previously missing exact-wheel build and runtime preparation instructions. All Python helpers, design bytes, batch plan and creative arguments are unchanged. A fresh build from the actual merge reproduces every byte of the qualified wheel; no new native GIMP execution is claimed for this documentation/source-identity revision.

Start with REPRODUCE.md. qualification-continuity.json connects the new binding to the recorded four-run milestone. Historical recipe metadata and native evidence retain their original identities under history/. The inherited NOT_EXECUTED wording in history/ describes the earlier preparation stage, followed by the completed milestone; it is not the current completion status. recipe/seal_recipe.py is historical maintenance tooling and is not a reproduction step.

The exact source and adapter wheel are obtained separately using the documented public-source build. The included software notice applies only to upstream adapter software. Original artwork and recipe rights remain reserved under recipe/RIGHTS.md; no additional artwork/data license is granted. Font binaries, native applications, Python environments, private raw traces and private evidence crosswalks are not included.

The GIMP milestone is separate from whole-showcase completion, Godot gameplay/visual acceptance and publication. Selected evidence is normalized SDK requests/results, not a raw network capture. The privacy-clean historical summaries are reference evidence; reproducing the workflow creates a new operator-owned run and traces.
