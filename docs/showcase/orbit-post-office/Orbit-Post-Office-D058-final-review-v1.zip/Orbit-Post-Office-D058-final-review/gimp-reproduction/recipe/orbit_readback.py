"""Read-only PNG and saved-XCF evidence for transparent asset publication.

Uses the copied bounded readers. No image creation, rendering, color conversion,
or native application is performed. A pixel digest excludes container metadata;
it cannot establish equality of color profiles or a native document's pixels.
"""
import hashlib
import struct
from pathlib import Path

from png_readback import decode_png
from xcf_metadata_readback import read_xcf_text_parasites, require


_COLOR_CHUNKS = {b"sRGB", b"gAMA", b"cHRM", b"iCCP", b"cICP", b"mDCv", b"cLLi"}
_COLOR_TYPES = {0: "grayscale", 2: "RGB", 3: "indexed", 4: "grayscale-alpha", 6: "RGBA"}


def _color_description(tag, payload):
    """Describe encoded metadata only; deliberately do not assign a color space."""
    result = {"chunk": tag.decode("ascii"), "payload_bytes": len(payload),
              "payload_sha256": hashlib.sha256(payload).hexdigest()}
    if tag == b"sRGB":
        if len(payload) != 1 or payload[0] > 3:
            raise ValueError("Invalid sRGB chunk")
        result.update(rendering_intent=payload[0], rendering_intent_name=(
            "perceptual", "relative-colorimetric", "saturation", "absolute-colorimetric"
        )[payload[0]])
    elif tag == b"gAMA":
        if len(payload) != 4:
            raise ValueError("Invalid gAMA chunk")
        value = struct.unpack(">I", payload)[0]
        if not value:
            raise ValueError("Invalid zero gAMA value")
        result.update(encoded_gamma_integer=value, encoded_gamma=value / 100000)
    elif tag == b"cHRM":
        if len(payload) != 32:
            raise ValueError("Invalid cHRM chunk")
        values = struct.unpack(">8I", payload)
        result["encoded_chromaticities"] = dict(zip(
            ("white_x", "white_y", "red_x", "red_y", "green_x", "green_y", "blue_x", "blue_y"),
            (value / 100000 for value in values)))
    elif tag == b"iCCP":
        name, separator, rest = payload.partition(b"\0")
        if not separator or not 1 <= len(name) <= 79 or len(rest) < 2 or rest[0] != 0:
            raise ValueError("Invalid iCCP chunk envelope")
        result.update(profile_name=name.decode("latin-1"), compression_method=rest[0],
                      compressed_profile_bytes=len(rest) - 1,
                      compressed_profile_sha256=hashlib.sha256(rest[1:]).hexdigest(),
                      profile_decompressed=False)
    elif tag == b"cICP":
        if len(payload) != 4:
            raise ValueError("Invalid cICP chunk")
        result.update(zip(("color_primaries", "transfer_function", "matrix_coefficients",
                           "video_full_range_flag"), payload))
    else:
        expected = 24 if tag == b"mDCv" else 8
        if len(payload) != expected:
            raise ValueError("Invalid " + tag.decode("ascii") + " chunk")
        result["encoded_payload_hex"] = payload.hex()
    return result


def _fractional_edge(alpha, width, height, index):
    """An intermediate-alpha pixel touching a zero-alpha 8-neighbor."""
    if not 0 < alpha[index] < 255:
        return False
    x, y = index % width, index // width
    return any(alpha[ny * width + nx] == 0
               for ny in range(max(0, y - 1), min(height, y + 2))
               for nx in range(max(0, x - 1), min(width, x + 2)))


def _edge_facts(values):
    return {"alpha_min": min(values), "alpha_max": max(values),
            "nonzero_count": len(values) - values.count(0), "pixel_count": len(values)}


def png_facts(path):
    """Return bounded decoded RGBA evidence and separate encoded PNG metadata.

    Bounds use inclusive pixel coordinates and alpha > 0. Margins count complete
    zero-alpha rows/columns between those bounds and the canvas. Fractional edge
    samples span row-major positions, up to 16 samples, and include exact RGBA.
    """
    path = Path(path)
    if path.stat().st_size > 32 * 1024**2:
        raise ValueError("Oversized PNG")
    data = path.read_bytes()
    width, height, rgba = decode_png(path)
    if path.read_bytes() != data:
        raise ValueError("PNG changed during readback")
    # decode_png has checked every chunk CRC, size, ending, and decoded length.
    # Comparing the reads around decoding rejects ordinary concurrent changes.
    # Header/chunk descriptions and container hash refer to this byte snapshot.
    if len(data) > 32 * 1024**2 or data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("PNG changed during readback")
    chunks, colors, position = [], [], 8
    bit_depth = color_type = None
    while position < len(data):
        if position + 12 > len(data):
            raise ValueError("Truncated PNG metadata")
        size = struct.unpack(">I", data[position:position + 4])[0]
        tag = data[position + 4:position + 8]
        end = position + 12 + size
        if end > len(data):
            raise ValueError("Truncated PNG metadata payload")
        payload = data[position + 8:position + 8 + size]
        chunks.append(tag.decode("ascii"))
        if tag == b"IHDR":
            if len(payload) != 13:
                raise ValueError("Invalid PNG metadata IHDR")
            encoded_width, encoded_height, bit_depth, color_type, _, _, _ = struct.unpack(">IIBBBBB", payload)
            if (encoded_width, encoded_height) != (width, height):
                raise ValueError("PNG dimensions changed during readback")
        if tag in _COLOR_CHUNKS:
            colors.append(_color_description(tag, payload))
        position = end
    if path.read_bytes() != data:
        raise ValueError("PNG changed during readback")

    alpha = rgba[3::4]
    transparent = alpha.count(0)
    opaque = alpha.count(255)
    fractional = len(alpha) - transparent - opaque
    left, top, right, bottom = width, height, -1, -1
    fractional_edge_count = 0
    for index, value in enumerate(alpha):
        if value:
            x, y = index % width, index // width
            left, top, right, bottom = min(left, x), min(top, y), max(right, x), max(bottom, y)
        if 0 < value < 255 and _fractional_edge(alpha, width, height, index):
            fractional_edge_count += 1
    bounds = None if right < 0 else {"left": left, "top": top, "right": right, "bottom": bottom}
    margins = None if bounds is None else {
        "left": left, "top": top, "right": width - 1 - right, "bottom": height - 1 - bottom}
    sample_count = min(16, fractional_edge_count)
    sample_ranks = ({0} if sample_count == 1 else
                    {i * (fractional_edge_count - 1) // (sample_count - 1) for i in range(sample_count)}
                    if sample_count else set())
    samples, rank = [], 0
    if sample_count:
        for index, value in enumerate(alpha):
            if 0 < value < 255 and _fractional_edge(alpha, width, height, index):
                if rank in sample_ranks:
                    samples.append({"x": index % width, "y": index // width,
                                    "rgba": list(rgba[index * 4:index * 4 + 4])})
                rank += 1
    return {
        "width": width, "height": height, "dimensions": [width, height],
        "color_type": color_type, "color_type_name": _COLOR_TYPES[color_type], "bit_depth": bit_depth,
        "chunk_types": chunks, "encoded_color_space_chunks": colors,
        "container_sha256": hashlib.sha256(data).hexdigest(),
        "rgba_sha256": hashlib.sha256(rgba).hexdigest(),
        "rgba_digest_scope": "Decoded row-major RGBA/U8 samples, including RGB under alpha=0; no color conversion",
        "container_digest_scope": "Exact PNG file bytes, including metadata and compression",
        "color_space_equality_claimed": False,
        "alpha_min_max": [min(alpha), max(alpha)],
        "transparent_count": transparent, "opaque_count": opaque, "semitransparent_count": fractional,
        "nonzero_alpha_count": len(alpha) - transparent,
        "alpha_bounds": bounds, "alpha_bounds_convention": "Inclusive coordinates of alpha > 0",
        "transparent_margins": margins,
        "edges": {"top": _edge_facts(alpha[:width]), "bottom": _edge_facts(alpha[-width:]),
                  "left": _edge_facts(alpha[::width]), "right": _edge_facts(alpha[width - 1::width])},
        "fractional_edge_count": fractional_edge_count, "fractional_edge_samples": samples,
        "fractional_edge_definition": "0 < alpha < 255 with an 8-neighbor whose alpha is 0",
        "native_antialias_provenance_claimed": False,
    }


def assert_asset_png(path, width=512, height=512, *, require_fractional=True):
    """Require RGBA/U8 transparency/content/margins; measure shape-appropriate alpha."""
    require(type(require_fractional) is bool, "Fractional alpha requirement must be explicit boolean")
    facts = png_facts(path)
    require(facts["dimensions"] == [width, height], "PNG dimensions differ from requested asset size")
    require(facts["color_type"] == 6 and facts["bit_depth"] == 8,
            "Asset must be encoded as actual RGBA PNG color type 6 at 8-bit depth")
    require(facts["nonzero_alpha_count"] > 0, "PNG asset content is empty")
    require(facts["alpha_min_max"] == [0, 255], "PNG must contain both alpha 0 and alpha 255")
    require(all(value >= 8 for value in facts["transparent_margins"].values()),
            "PNG requires at least 8px fully transparent margins on every side")
    if require_fractional:
        require(facts["semitransparent_count"] > 0, "PNG requires fractional alpha for this artwork")
    facts["fractional_alpha_required"]=require_fractional
    return facts


def verify_text_saved(path, native_info):
    """Verify saved text payloads against native inspection; zero text is valid.

    The saved container hash is not a projection/pixel comparison. Text payload
    equality establishes metadata persistence only, without a color-space claim.
    """
    saved = read_xcf_text_parasites(path)
    require(saved["canvas"] == [native_info["width"], native_info["height"]], "XCF canvas differs")
    metadata = native_info.get("metadata")
    require(isinstance(metadata, dict), "Native metadata inspection is required")
    entries = metadata.get("layer_parasites")
    require(isinstance(entries, list), "Native layer parasite inspection missing")
    layers = native_info.get("layers")
    require(isinstance(layers, list), "Native layer inspection is required")
    require(all(isinstance(row, dict) and isinstance(row.get("name"), str)
                and isinstance(row.get("is_text"), bool) for row in layers),
            "Native layers need names and explicit boolean is_text fields")
    require(len({row["name"] for row in layers}) == len(layers), "Native layer names are ambiguous")
    native = {}
    for row in entries:
        require(isinstance(row, dict) and isinstance(row.get("name"), str)
                and isinstance(row.get("parasites"), list), "Invalid native layer parasite entry")
        require(row["name"] not in native, "Native parasite layer names are ambiguous")
        native[row["name"]] = row["parasites"]
    expected_names = {row["name"] for row in layers if row["is_text"]}
    saved_names = {name for name, parasites in saved["layers"].items() if "gimp-text-layer" in parasites}
    native_names = {name for name, parasites in native.items()
                    if any(row.get("name") == "gimp-text-layer" for row in parasites)}
    require(saved_names == expected_names == native_names,
            "Saved/native editable text parasite names or count differ")
    matches = []
    for name in sorted(saved_names):
        expected = saved["layers"][name]["gimp-text-layer"]
        found = [row for row in native[name] if row.get("name") == "gimp-text-layer"]
        require(len(found) == 1, "Native saved text parasite is ambiguous: " + name)
        actual, raw = found[0], expected["data"]
        digest = hashlib.sha256(raw).hexdigest()
        require(actual.get("flags") == expected["flags"] and actual.get("bytes") == len(raw)
                and actual.get("sha256") == digest, "Native parasite bytes differ: " + name)
        require(actual.get("text") == raw[:16384].decode("utf-8", errors="replace")
                and actual.get("truncated") is (len(raw) > 16384), "Native parasite preview differs: " + name)
        matches.append({"layer_name": name, "parasite_name": "gimp-text-layer", "flags": expected["flags"],
                        "bytes": len(raw), "sha256": digest,
                        "high_bit_byte_count": sum(value >= 128 for value in raw)})
    return {"status": "PASS_NATIVE_METADATA_EQUALS_SAVED_XCF_BYTES", "xcf_sha256": saved["sha256"],
            "xcf_digest_scope": "Exact saved XCF container bytes; not decoded projection pixels",
            "canvas": saved["canvas"], "xcf_version": saved["version"],
            "expected_native_text_layers": len(expected_names), "matched_text_parasites": len(matches),
            "payloads": matches, "raw_payloads_in_public_receipt": False,
            "pixel_equality_claimed": False, "color_space_equality_claimed": False,
            "arbitrary_non_utf8_native_coverage_claimed": False}
