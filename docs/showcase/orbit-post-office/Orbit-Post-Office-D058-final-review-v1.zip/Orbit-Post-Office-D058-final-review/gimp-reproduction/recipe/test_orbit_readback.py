"""Host-free readback contract tests using temporary synthetic byte fixtures.

These fixtures only exercise file parsers; they are not production artwork,
native application saves, or evidence of native anti-aliasing provenance.
Run with: PYTHONDONTWRITEBYTECODE=1 python -m unittest -v test_orbit_readback
"""
import binascii
import copy
import hashlib
import json
import struct
import tempfile
import unittest
import zlib
from pathlib import Path

from orbit_readback import assert_asset_png, png_facts, verify_text_saved


def _chunk(tag, payload):
    return (struct.pack(">I", len(payload)) + tag + payload
            + struct.pack(">I", binascii.crc32(tag + payload) & 0xffffffff))


def _png_bytes(width=20, height=20, kind=6, points=None, color_chunks=(), compression=6):
    """Produce parser fixtures in memory, with filter 0; no rendering APIs."""
    if points is None:
        points = {(8, 8): (11, 23, 37, 128), (11, 11): (47, 59, 71, 255)}
    rows = []
    for y in range(height):
        row = bytearray([0])
        for x in range(width):
            pixel = points.get((x, y), (0, 0, 0, 0))
            row.extend(pixel if kind == 6 else pixel[:3] if kind == 2 else (pixel[0], pixel[3]))
        rows.append(row)
    return (b"\x89PNG\r\n\x1a\n"
            + _chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, kind, 0, 0, 0))
            + b"".join(_chunk(tag, payload) for tag, payload in color_chunks)
            + _chunk(b"IDAT", zlib.compress(b"".join(rows), compression)) + _chunk(b"IEND", b""))


def _string(value):
    raw = value.encode("utf-8") + b"\0"
    return struct.pack(">I", len(raw)) + raw


def _xcf_bytes(texts=(), width=20, height=20):
    """A metadata-only XCF envelope for the bounded saved-parasite reader."""
    terminator = b"\0" * 8
    layers = []
    for name, raw, flags in texts:
        parasite = _string("gimp-text-layer") + struct.pack(">II", flags, len(raw)) + raw
        properties = struct.pack(">II", 21, len(parasite)) + parasite + terminator
        layers.append(struct.pack(">III", width, height, 1) + _string(name) + properties)
    header = b"gimp xcf v013\0" + struct.pack(">IIII", width, height, 0, 150) + terminator
    position = len(header) + 8 * (len(layers) + 1)
    offsets = []
    for layer in layers:
        offsets.append(struct.pack(">Q", position))
        position += len(layer)
    return header + b"".join(offsets) + b"\0" * 8 + b"".join(layers)


def _native_info(texts=(), width=20, height=20):
    return {"width": width, "height": height,
            "layers": [{"name": name, "is_text": True} for name, _, _ in texts],
            "metadata": {"layer_parasites": [
                {"name": name, "parasites": [{"name": "gimp-text-layer", "flags": flags,
                 "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
                 "text": raw[:16384].decode("utf-8", errors="replace"), "truncated": len(raw) > 16384}]}
                for name, raw, flags in texts]}}


class ReadbackTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="orbit-readback-test-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def fixture(self, name, data):
        path = self.root / name
        path.write_bytes(data)
        return path

    def test_rgba_facts_and_exact_eight_pixel_margins(self):
        data = _png_bytes()
        path = self.fixture("valid.png", data)
        facts = assert_asset_png(path, 20, 20)
        self.assertEqual(facts["color_type"], 6)
        self.assertEqual(facts["bit_depth"], 8)
        self.assertEqual(facts["alpha_min_max"], [0, 255])
        self.assertEqual(facts["transparent_count"], 398)
        self.assertEqual(facts["opaque_count"], 1)
        self.assertEqual(facts["semitransparent_count"], 1)
        self.assertEqual(facts["alpha_bounds"], {"left": 8, "top": 8, "right": 11, "bottom": 11})
        self.assertEqual(facts["transparent_margins"], dict.fromkeys(("left", "top", "right", "bottom"), 8))
        self.assertEqual(facts["fractional_edge_samples"], [{"x": 8, "y": 8, "rgba": [11, 23, 37, 128]}])
        for edge in facts["edges"].values():
            self.assertEqual(edge, {"alpha_min": 0, "alpha_max": 0, "nonzero_count": 0, "pixel_count": 20})
        rgba = bytearray(20 * 20 * 4)
        rgba[(8 * 20 + 8) * 4:(8 * 20 + 8) * 4 + 4] = bytes([11, 23, 37, 128])
        rgba[(11 * 20 + 11) * 4:(11 * 20 + 11) * 4 + 4] = bytes([47, 59, 71, 255])
        self.assertEqual(facts["rgba_sha256"], hashlib.sha256(rgba).hexdigest())
        self.assertEqual(facts["container_sha256"], hashlib.sha256(data).hexdigest())
        json.dumps(facts)

    def test_default_dimensions_are_512(self):
        path = self.fixture("size.png", _png_bytes())
        with self.assertRaisesRegex(RuntimeError, "dimensions"):
            assert_asset_png(path)

    def test_binary_alpha_only_allowed_when_explicit_and_other_gates_remain(self):
        path=self.fixture('aligned.png',_png_bytes(points={(9,9):(1,2,3,255)}))
        with self.assertRaisesRegex(RuntimeError,'fractional'):
            assert_asset_png(path,20,20)
        facts=assert_asset_png(path,20,20,require_fractional=False)
        self.assertEqual(facts['semitransparent_count'],0)
        self.assertFalse(facts['fractional_alpha_required'])
        for points in ({},{(7,9):(1,2,3,255)}):
            invalid=self.fixture('invalid.png',_png_bytes(points=points))
            with self.assertRaises(RuntimeError):
                assert_asset_png(invalid,20,20,require_fractional=False)
        wrong_format=self.fixture('rgb.png',_png_bytes(kind=2,points={(9,9):(1,2,3,255)}))
        with self.assertRaisesRegex(RuntimeError,'actual RGBA'):
            assert_asset_png(wrong_format,20,20,require_fractional=False)
        with self.assertRaisesRegex(RuntimeError,'explicit boolean'):
            assert_asset_png(path,20,20,require_fractional=None)

    def test_non_square_edges_have_correct_pixel_counts(self):
        facts = png_facts(self.fixture("rectangle.png", _png_bytes(23, 21)))
        self.assertEqual(facts["edges"]["top"]["pixel_count"], 23)
        self.assertEqual(facts["edges"]["left"]["pixel_count"], 21)
        self.assertEqual(facts["transparent_margins"]["right"], 11)
        self.assertEqual(facts["transparent_margins"]["bottom"], 9)

    def test_color_metadata_does_not_change_pixel_hash_or_prove_color_equality(self):
        plain = png_facts(self.fixture("plain.png", _png_bytes()))
        chunks = [(b"sRGB", b"\0"), (b"gAMA", struct.pack(">I", 45455)),
                  (b"cHRM", struct.pack(">8I", 31270, 32900, 64000, 33000, 30000, 60000, 15000, 6000)),
                  (b"cICP", bytes([1, 13, 0, 1]))]
        tagged = png_facts(self.fixture("tagged.png", _png_bytes(color_chunks=chunks)))
        self.assertEqual(plain["rgba_sha256"], tagged["rgba_sha256"])
        self.assertNotEqual(plain["container_sha256"], tagged["container_sha256"])
        self.assertFalse(tagged["color_space_equality_claimed"])
        self.assertEqual([item["chunk"] for item in tagged["encoded_color_space_chunks"]],
                         ["sRGB", "gAMA", "cHRM", "cICP"])
        self.assertEqual(tagged["encoded_color_space_chunks"][1]["encoded_gamma"], 0.45455)

    def test_iccp_reports_encoded_envelope_without_decoding_or_color_claim(self):
        compressed = zlib.compress(b"synthetic ICC parser fixture")
        facts = png_facts(self.fixture("icc.png", _png_bytes(color_chunks=[(b"iCCP", b"Fixture\0\0" + compressed)])))
        profile = facts["encoded_color_space_chunks"][0]
        self.assertEqual(profile["profile_name"], "Fixture")
        self.assertEqual(profile["compressed_profile_sha256"], hashlib.sha256(compressed).hexdigest())
        self.assertFalse(profile["profile_decompressed"])

    def test_compression_changes_container_not_pixels(self):
        a = png_facts(self.fixture("a.png", _png_bytes(compression=0)))
        b = png_facts(self.fixture("b.png", _png_bytes(compression=9)))
        self.assertEqual(a["rgba_sha256"], b["rgba_sha256"])
        self.assertNotEqual(a["container_sha256"], b["container_sha256"])

    def test_decoder_rgba_conversion_does_not_mask_wrong_encoded_type(self):
        for kind in (2, 4):
            with self.subTest(kind=kind):
                path = self.fixture("type.png", _png_bytes(kind=kind))
                self.assertEqual(png_facts(path)["color_type"], kind)
                with self.assertRaisesRegex(RuntimeError, "actual RGBA"):
                    assert_asset_png(path, 20, 20)

    def test_empty_and_binary_alpha_and_missing_opaque_rejected(self):
        cases = [({}, "empty"), ({(9, 9): (1, 2, 3, 255)}, "fractional"),
                 ({(9, 9): (1, 2, 3, 128)}, "alpha 0 and alpha 255")]
        for points, message in cases:
            with self.subTest(message=message):
                path = self.fixture("invalid.png", _png_bytes(points=points))
                with self.assertRaisesRegex(RuntimeError, message):
                    assert_asset_png(path, 20, 20)
        facts = png_facts(self.fixture("empty.png", _png_bytes(points={})))
        self.assertIsNone(facts["alpha_bounds"])
        self.assertIsNone(facts["transparent_margins"])
        self.assertEqual(facts["fractional_edge_samples"], [])

    def test_seven_pixel_margin_fails_on_each_side(self):
        for x, y in ((7, 9), (12, 9), (9, 7), (9, 12)):
            with self.subTest(x=x, y=y):
                path = self.fixture("margin.png", _png_bytes(points={
                    (x, y): (10, 20, 30, 128), (9, 9): (1, 2, 3, 255)}))
                with self.assertRaisesRegex(RuntimeError, "8px"):
                    assert_asset_png(path, 20, 20)

    def test_perimeter_stats_detect_nontransparent_border(self):
        facts = png_facts(self.fixture("border.png", _png_bytes(points={
            (0, 0): (1, 2, 3, 128), (19, 19): (1, 2, 3, 255)})))
        self.assertEqual(facts["edges"]["top"]["alpha_max"], 128)
        self.assertEqual(facts["edges"]["bottom"]["alpha_max"], 255)
        self.assertEqual(facts["edges"]["left"]["nonzero_count"], 1)
        self.assertEqual(facts["edges"]["right"]["nonzero_count"], 1)

    def test_fractional_contour_sampling_is_bounded_and_spans_contour(self):
        points = {(x, 8): (x, 3, 5, 128) for x in range(8, 40)}
        points[(9, 10)] = (1, 2, 3, 255)
        facts = assert_asset_png(self.fixture("samples.png", _png_bytes(48, 24, points=points)), 48, 24)
        self.assertEqual(facts["fractional_edge_count"], 32)
        self.assertEqual(len(facts["fractional_edge_samples"]), 16)
        self.assertEqual(facts["fractional_edge_samples"][0]["x"], 8)
        self.assertEqual(facts["fractional_edge_samples"][-1]["x"], 39)
        self.assertFalse(facts["native_antialias_provenance_claimed"])

    def test_bad_crc_truncated_data_and_bad_color_chunk_fail(self):
        bad_crc = bytearray(_png_bytes())
        bad_crc[-1] ^= 1
        for raw in (bytes(bad_crc), _png_bytes()[:-3], _png_bytes(color_chunks=[(b"sRGB", b"\x04")])):
            with self.subTest(length=len(raw)):
                with self.assertRaises(ValueError):
                    png_facts(self.fixture("bad.png", raw))

    def test_generic_ascii_and_unicode_saved_text_payloads(self):
        texts = [("Orbit destination", b'(text "Post Office")', 3),
                 ("Postal seal", '(text "Orbital café ☾")'.encode(), 1)]
        data = _xcf_bytes(texts)
        result = verify_text_saved(self.fixture("text.xcf", data), _native_info(texts))
        self.assertEqual(result["matched_text_parasites"], 2)
        self.assertEqual(result["expected_native_text_layers"], 2)
        self.assertEqual(result["xcf_sha256"], hashlib.sha256(data).hexdigest())
        self.assertFalse(result["pixel_equality_claimed"])
        self.assertFalse(result["color_space_equality_claimed"])
        self.assertFalse(result["raw_payloads_in_public_receipt"])
        self.assertNotIn("required_high_bit_formula_layers", result)
        self.assertNotIn("Orbital café", json.dumps(result))

    def test_zero_text_is_valid_with_explicit_native_inspection(self):
        result = verify_text_saved(self.fixture("zero.xcf", _xcf_bytes()), _native_info())
        self.assertEqual(result["matched_text_parasites"], 0)
        self.assertEqual(result["payloads"], [])

    def test_saved_text_byte_flags_digest_preview_and_truncation_must_match(self):
        texts = [("Stamp title", b'(text "Orbit")', 3)]
        path = self.fixture("text.xcf", _xcf_bytes(texts))
        for field, wrong in (("bytes", 999), ("flags", 7), ("sha256", "0" * 64),
                             ("text", "incorrect"), ("truncated", True)):
            with self.subTest(field=field):
                info = _native_info(texts)
                info["metadata"]["layer_parasites"][0]["parasites"][0][field] = wrong
                with self.assertRaisesRegex(RuntimeError, "differs|differ"):
                    verify_text_saved(path, info)

    def test_long_text_preview_uses_byte_boundary_and_truncation_flag(self):
        raw = b"a" * 16383 + "é".encode() + b"tail"
        texts = [("Long title", raw, 1)]
        result = verify_text_saved(self.fixture("long.xcf", _xcf_bytes(texts)), _native_info(texts))
        self.assertEqual(result["payloads"][0]["bytes"], len(raw))

    def test_equal_text_count_with_different_layer_names_is_rejected(self):
        texts = [("Original title", b"Orbit", 1)]
        path = self.fixture("text.xcf", _xcf_bytes(texts))
        info = _native_info(texts)
        info["layers"][0]["name"] = "Different title"
        with self.assertRaisesRegex(RuntimeError, "names or count"):
            verify_text_saved(path, info)

    def test_extra_native_text_parasite_cannot_pass_zero_text_check(self):
        info = _native_info([("Unexpected", b"text", 1)])
        info["layers"] = []
        with self.assertRaisesRegex(RuntimeError, "names or count"):
            verify_text_saved(self.fixture("zero.xcf", _xcf_bytes()), info)

    def test_ambiguous_native_layer_and_parasite_names_are_rejected(self):
        texts = [("Title", b"Orbit", 1)]
        path = self.fixture("text.xcf", _xcf_bytes(texts))
        for target in ("layers", "metadata_layers", "parasites"):
            with self.subTest(target=target):
                info = _native_info(texts)
                rows = (info["layers"] if target == "layers" else
                        info["metadata"]["layer_parasites"] if target == "metadata_layers" else
                        info["metadata"]["layer_parasites"][0]["parasites"])
                rows.append(copy.deepcopy(rows[0]))
                with self.assertRaisesRegex(RuntimeError, "ambiguous"):
                    verify_text_saved(path, info)

    def test_canvas_metadata_and_text_flags_must_be_explicit(self):
        path = self.fixture("zero.xcf", _xcf_bytes())
        cases = [{"width": 21, "height": 20, "layers": [], "metadata": {"layer_parasites": []}},
                 {"width": 20, "height": 20, "layers": []},
                 {"width": 20, "height": 20, "layers": [], "metadata": {}},
                 {"width": 20, "height": 20, "layers": [{"name": "Unknown"}],
                  "metadata": {"layer_parasites": []}}]
        for info in cases:
            with self.subTest(info=info):
                with self.assertRaises(RuntimeError):
                    verify_text_saved(path, info)

    def test_truncated_xcf_rejected_by_saved_byte_reader(self):
        with self.assertRaises(RuntimeError):
            verify_text_saved(self.fixture("bad.xcf", _xcf_bytes()[:-2]), _native_info())


if __name__ == "__main__":
    unittest.main()
