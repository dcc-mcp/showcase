"""File-only technical closure for four explicit completed standalone native runs.

This does not perform native work, visual approval, engine acceptance or publication.
"""
import sys
sys.dont_write_bytecode=True
import os as _bootstrap_os
sys.pycache_prefix=_bootstrap_os.path.join(
    _bootstrap_os.path.abspath(_bootstrap_os.environ.get('TMPDIR','/tmp')),
    'd058-unused-bytecode-'+_bootstrap_os.urandom(16).hex())
if _bootstrap_os.path.lexists(sys.pycache_prefix):
    raise RuntimeError('Project-helper bytecode lookup prefix must be fresh')
import argparse
import hashlib
import json
from pathlib import Path

from binding import no_symlinks
from lifecycle import canonical_image, require, sha
from png_readback import decode_png
from orbit_readback import assert_asset_png, png_facts, verify_text_saved
from orbit_workflow import selected_names

PREP=Path(__file__).resolve().parent


def reviewed_adapter_identity(run_binding):
    catalog=json.loads((PREP/'reviewed-adapter-bindings.json').read_text())['bindings']
    digest=run_binding['package_integrity']['binding_sha256']
    matches=[row for row in catalog if row['sha256']==digest]
    require(len(matches)==1,'Run adapter binding is not in the current reviewed allowlist')
    entry=matches[0];path=no_symlinks(PREP/entry['filename'])
    require(path.is_relative_to(PREP) and sha(path)==digest,'Current reviewed adapter binding differs')
    binding=json.loads(path.read_text())
    identity=(run_binding['source_commit'],run_binding['source_tree'],digest,
              run_binding['package_integrity']['wheel_sha256'])
    require(identity==(entry['commit'],entry['tree'],digest,binding['wheel']['sha256']),
            'Run source/tree/wheel identity differs from reviewed binding')
    require(run_binding['versions']==binding['runtime_versions']
            and run_binding['matched_package_files']==42
            and run_binding['package_integrity']['source_files']==69,
            'Run package/runtime inventory differs from reviewed binding')
    return identity


def component_artifact_names(asset_id):
    names={asset_id+suffix for suffix in (
        '.xcf','.png','-128.png','-64.png','-after-previews.png',
        '-after-export-checkpoint.xcf','-reopened.png','-reopened-checkpoint.xcf')}
    for background in ('dark','light'):
        names.update(asset_id+'-'+background+suffix for suffix in (
            '.png','-128.png','-64.png','-composite.xcf'))
    return names


def require_component_inventory(asset_id, manifest):
    expected=component_artifact_names(asset_id)
    actual={name for name in manifest if name==asset_id+'.xcf' or name==asset_id+'.png'
            or name.startswith(asset_id+'-')}
    require(actual==expected,'Required per-role source/reopen/preview/composite inventory differs')


def verify_structure(saved, loaded, reference):
    require(canonical_image(saved)==canonical_image(loaded)==reference['canonical_native_structure'],
            'Recomputed native saved/reopen/approved structure differs')
    require(selected_names(saved)==selected_names(loaded)==reference['selected_layer_names'],
            'Recomputed saved/reopen selected layer names differ')


def verify_preview(proof, facts, size):
    require(facts['dimensions']==[size,size] and proof['png_facts']==facts,
            'Preview facts/dimensions differ from actual file')
    require(proof['source_before_after_equal'] is True and proof['selected_layers_equal'] is True
            and proof['native_text_and_metadata_equal'] is True,
            'Preview source/selection/text preservation receipt is missing')
    require(type(proof['active_image_id_before_after']) is int and proof['active_image_id_before_after']>0,
            'Preview active-image identity is missing')
    fingerprint=proof['source_state_sha256']
    require(isinstance(fingerprint,str) and len(fingerprint)==64
            and all(c in '0123456789abcdef' for c in fingerprint),
            'Preview native source-state fingerprint is missing')


def verify_composite(pixels, color):
    require(pixels[:2]==(512,512) and set(pixels[2][3::4])=={255}
            and list(pixels[2][:4])==color,'Native composite opacity/dimensions/background corner differ')


def verify_runs(run_roots):
    plan=json.loads((PREP/'batch-plan.json').read_text())
    expected={row['id']:row for row in plan['batches']}
    require(len(run_roots)==len(expected), 'Provide exactly one explicit completed run for each of four batches')
    require(len(set(map(str,run_roots)))==len(run_roots), 'Duplicate run roots')
    recipe_sha=sha(PREP/'recipe-binding.json')
    references={r['asset_id']:r for r in json.loads((PREP/'accepted-component-reference.json').read_text())['components']}
    designs={r['id']:r for r in json.loads((PREP/'design.json').read_text())['assets']}
    results={};components=[];adapter_identity=None
    evidence_runs=[];roots_by_component={}
    for given in run_roots:
        root=no_symlinks(given)
        require(root.is_dir(), 'Explicit completed run directory is missing')
        qual=json.loads((root/'qualification.json').read_text())
        require(qual['status']=='PASS_STANDALONE_NATIVE_BATCH_VISUAL_REVIEW_REQUIRED',
                'A historical/partial/unqualified run cannot close standalone reproduction')
        batch=qual['batch_id']
        require(batch in expected and batch not in results, 'Wrong or repeated batch identity')
        require(qual['native_asset_ids']==expected[batch]['asset_ids'], 'Native asset list differs from bound batch')
        run_binding=json.loads((root/'package-binding.json').read_text())
        require(run_binding['recipe_binding_sha256']==recipe_sha, 'Run used different standalone recipe bytes')
        identity=reviewed_adapter_identity(run_binding)
        if adapter_identity is None:adapter_identity=identity
        require(identity==adapter_identity, 'Batches used different reviewed adapter identities')
        cleanup=json.loads((root/'cleanup.json').read_text())
        require(cleanup==qual['cleanup'] and cleanup['normal_owned_shutdown_pass'] is True
                and cleanup['force_kill_used'] is False and not cleanup['cleanup_errors'],
                'Native shutdown gate is incomplete')
        manifest={row['path']:row for row in qual['artifacts']}
        require(len(manifest)==len(qual['artifacts']), 'Duplicate artifact paths')
        require(set(manifest)==set(qual['artifact_names']), 'Artifact inventory differs')
        actual_files={path.name for path in root.iterdir() if path.suffix in ('.png','.xcf')}
        require(actual_files==set(manifest),'Actual native output inventory differs from recorded manifest')
        for name,row in manifest.items():
            path=no_symlinks(root/name)
            require(path.parent==root and path.is_file() and path.stat().st_size==row['bytes']
                    and sha(path)==row['sha256'], 'Original native artifact differs: '+name)
        evidence_assets=[]
        for asset_id in expected[batch]['asset_ids']:
            require_component_inventory(asset_id,manifest)
            reference=references[asset_id]
            metadata=json.loads((root/(asset_id+'-metadata.json')).read_text())
            png=root/(asset_id+'.png');xcf=root/(asset_id+'.xcf')
            require(metadata['asset_id']==asset_id and metadata['purpose']==designs[asset_id]['meaning']
                    and metadata['source_xcf_sha256']==sha(xcf) and metadata['png_sha256']==sha(png)
                    and metadata['rgba_sha256']==reference['rgba_sha256']
                    and metadata['native_shape_layer_count']==reference['shape_layers']
                    and metadata['native_editable_text_count']==reference['editable_text_layers'],
                    'Per-component metadata identity/count/digests differ')
            facts=assert_asset_png(png,require_fractional=asset_id!='orbital-stamp')
            require(facts==metadata['png_readback'], 'Saved PNG facts differ from current bytes')
            pixels=decode_png(png)
            require(pixels==decode_png(root/(asset_id+'-after-previews.png'))
                    ==decode_png(root/(asset_id+'-reopened.png')), 'Source full RGBA/reopen equality failed')
            require(hashlib.sha256(pixels[2]).hexdigest()==reference['rgba_sha256'],
                    'Fresh source RGBA differs from the approved original component')
            source_proof=json.loads((root/(asset_id+'.xcf.proof.json')).read_text())
            reopen=json.loads((root/(asset_id+'-reopen-state.json')).read_text())
            verify_text_saved(xcf,source_proof['native_saved_structure'])
            verify_text_saved(xcf,reopen['loaded'])
            require(source_proof['native_saved_structure']==reopen['saved'],
                    'Saved-state copies disagree between source and reopen receipts')
            verify_structure(source_proof['native_saved_structure'],reopen['loaded'],reference)
            require(metadata['native_layer_names']==[r['name'] for r in source_proof['native_saved_structure']['layers']],
                    'Per-component metadata layer names differ')
            require(reopen['canonical_native_structure_equal'] is True
                    and reopen['selected_layer_names_equal'] is True, 'Native reopen structure gate missing')
            for size in (128,64):
                name=asset_id+'-'+str(size)+'.png'
                verify_preview(json.loads((root/(name+'.proof.json')).read_text()),png_facts(root/name),size)
            for background,color in (('dark',[24,35,43,255]),('light',[247,244,234,255])):
                name=asset_id+'-'+background
                verify_composite(decode_png(root/(name+'.png')),color)
                checkpoint=json.loads((root/(name+'-composite.xcf.proof.json')).read_text())
                verify_structure(source_proof['native_saved_structure'],checkpoint['native_saved_structure'],reference)
                verify_text_saved(root/(name+'-composite.xcf'),checkpoint['native_saved_structure'])
                for size in (128,64):
                    small=name+'-'+str(size)+'.png'
                    verify_preview(json.loads((root/(small+'.proof.json')).read_text()),png_facts(root/small),size)
            core_names=[asset_id+suffix for suffix in ('.xcf','.png','-128.png','-64.png')]
            evidence_assets.append({'asset_id':asset_id,
                'shape_layers':len(designs[asset_id]['layers_bottom_to_top']),
                'editable_text_layers':len(designs[asset_id]['editable_text']),
                'rgba_sha256':reference['rgba_sha256'],
                'artifacts':[{'filename':name,'bytes':manifest[name]['bytes'],'sha256':manifest[name]['sha256']}
                             for name in core_names]})
            components.append({'asset_id':asset_id,'batch_id':batch,'source_xcf_sha256':sha(xcf),
                'png_sha256':sha(png),'rgba_sha256':hashlib.sha256(pixels[2]).hexdigest(),
                'shape_layers':metadata['native_shape_layer_count'],
                'editable_text_layers':metadata['native_editable_text_count'],
                'native_reopen_and_full_rgba_equal':True,'visual_review':'SEPARATE_REQUIRED'})
            roots_by_component[asset_id]=root
        results[batch]={'qualification_sha256':sha(root/'qualification.json'),
                        'raw_trace_sha256':sha(root/'mcp-trace.jsonl'),
                        'cleanup_host_returncode':cleanup['host_returncode'],
                        'record_count':qual['native_MCP_events']}
        evidence_runs.append({'run_id':'standalone-'+batch,'directory':str(root),
                              'assets':evidence_assets,'batch_state':'completed'})
    require(set(results)==set(expected) and len(components)==8, 'Standalone kit is incomplete')
    require(len({row['asset_id'] for row in components})==8, 'Repeated component role')
    require(sum(row['shape_layers'] for row in components)==76
            and sum(row['editable_text_layers'] for row in components)==2, 'Final native layer counts differ')
    # Reconstruct from actual paired requests, queued calls and completed jobs.
    # Preservation receipt booleans alone cannot close this gate.
    from normalize_selected_evidence import build
    records,derived,crosswalk=build({'schema':'D058-evidence-inputs-v1','runs':evidence_runs,
                                    'design_file':str(PREP/'design.json')})
    require(derived['creative_operation_count']==162 and len(derived['components'])==8,
            'Original request/completed-job reconstruction is incomplete')
    for record in records:
        if record['tool']!='export_preview':continue
        proof=json.loads((roots_by_component[record['component']] /
                          (record['result']['path']+'.proof.json')).read_text())
        aliases=crosswalk['aliases'][record['run']]['roles']['image']
        require(proof['source_state_sha256']==record['result']['source_state_sha256']
                and aliases.get(str(proof['active_image_id_before_after']))==record['arguments']['image_id'],
                'Preview receipt fingerprint/active identity differs from actual native records')
    return {'status':'PASS_ALL_EIGHT_STANDALONE_TECHNICAL_GATES_VISUAL_REVIEW_REQUIRED',
            'recipe_binding_sha256':recipe_sha,'adapter_identity':list(adapter_identity),
            'batches':results,'components':components,'native_launch_performed_by_verifier':False,
            'actual_request_completed_job_reconstruction':'PASS_IN_PROCESS_FROM_ORIGINAL_RAW_TRACES',
            'selected_records_reconstructed':len(records),
            'independent_inverse_alias_checker':'REQUIRED_FOR_PUBLIC_SELECTED_PACKET',
            'engine_native_acceptance':'NOT_INFERRED','full_D058_complete':False}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-root',type=Path,action='append',required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    output=no_symlinks(args.output)
    require(output.parent.is_dir() and not output.exists(),'Verifier output must be new')
    result=verify_runs(args.run_root)
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'output':str(output)}))


if __name__=='__main__':main()
