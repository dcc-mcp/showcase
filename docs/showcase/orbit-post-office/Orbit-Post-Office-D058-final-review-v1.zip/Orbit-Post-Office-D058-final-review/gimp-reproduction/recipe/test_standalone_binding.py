"""Host-free binding tests using explicit operator-supplied adapter inputs."""
import json
import importlib.util
import marshal
import os
import shutil
import subprocess
import struct
import sys
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

from binding import check_delivery

ROOT=Path(__file__).resolve().parent


class StandaloneBindingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        values=[os.environ.get('D058_TEST_ADAPTER_'+key) for key in ('SOURCE','WHEEL','BINDING')]
        if not all(values):
            raise unittest.SkipTest('Supply explicit D058_TEST_ADAPTER_SOURCE/WHEEL/BINDING inputs')
        cls.source,cls.wheel,cls.binding=map(Path,values)

    def setUp(self):
        temp=tempfile.TemporaryDirectory(prefix='d058-standalone-binding-')
        self.addCleanup(temp.cleanup);self.temp=Path(temp.name)

    def test_exact_public_source_and_whole_wheel_match_installed_package(self):
        result=check_delivery(self.source,self.wheel,self.binding)
        self.assertEqual(result['source_commit'],'aa519354a568dfe1f6ec4ce96385e6cf3bd29638')
        self.assertEqual(result['matched_package_files'],42)
        self.assertEqual(result['package_integrity']['source_files'],69)
        self.assertFalse(result['native_launched'])
        self.assertNotEqual(result['source_commit'],result['historical_native_provenance']['source_commit'])

    def test_explicit_inputs_can_be_relocated_without_prior_recipe_or_artwork(self):
        source=self.temp/'operator-source';source.mkdir()
        receipt=json.loads(self.binding.read_text())
        for row in receipt['source_files']:
            path=source/row['path'];path.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(self.source/row['path'],path)
        wheel=self.temp/'operator.whl';shutil.copyfile(self.wheel,wheel)
        binding=self.temp/'reviewed.json';shutil.copyfile(self.binding,binding)
        result=check_delivery(source,wheel,binding)
        self.assertEqual(result['matched_package_files'],42)
        self.assertNotIn('input_files',receipt);self.assertNotIn('recipe_files',receipt)

    def test_test_only_source_mutation_is_rejected_even_when_runtime_is_identical(self):
        source=self.temp/'source';source.mkdir()
        receipt=json.loads(self.binding.read_text())
        for row in receipt['source_files']:
            path=source/row['path'];path.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(self.source/row['path'],path)
        path=source/'tests/test_preview_export.py'
        path.write_bytes(path.read_bytes()+b'\n# invalid source identity\n')
        with self.assertRaisesRegex(RuntimeError,'source bytes differ'):
            check_delivery(source,self.wheel,self.binding)

    def test_whole_wheel_byte_mutation_is_rejected(self):
        wheel=self.temp/'changed.whl';wheel.write_bytes(self.wheel.read_bytes()+b'changed')
        with self.assertRaisesRegex(RuntimeError,'wheel bytes differ'):
            check_delivery(self.source,wheel,self.binding)

    def test_unknown_binding_and_path_escape_are_rejected(self):
        binding=self.temp/'changed.json';data=json.loads(self.binding.read_text())
        data['source_files'][0]['path']='../outside.py'
        binding.write_text(json.dumps(data))
        with self.assertRaisesRegex(RuntimeError,'reviewed digest allowlist'):
            check_delivery(self.source,self.wheel,binding)

    def test_check_mode_never_launches_or_reads_unrelated_artwork(self):
        script='''
import sys
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,sys.argv[1])
def audit(event,args):
    if event in ('subprocess.Popen','socket.connect','socket.bind'):
        raise RuntimeError('File-only check attempted a native/network action')
    if event=='open' and isinstance(args[0],(str,bytes)):
        path=str(args[0])
        if 'seismic-lens' in path or 'gimp-preview-export/inputs' in path or 'gimp-preview-export/reproduce' in path:
            raise RuntimeError('Unrelated D015 input dependency')
sys.addaudithook(audit)
from static_check import check_all
result=check_all(Path(sys.argv[2]),Path(sys.argv[3]),Path(sys.argv[4]))
assert result['native_launched'] is False
print('PASS_EXPLICIT_INPUTS_FILE_ONLY_NO_D015_READS')
'''
        result=subprocess.run([sys.executable,'-B','-c',script,str(ROOT),str(self.source),str(self.wheel),str(self.binding)],
                              capture_output=True,text=True,timeout=30)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertIn('PASS_EXPLICIT_INPUTS_FILE_ONLY_NO_D015_READS',result.stdout)

    def test_cli_ignores_a_stale_project_helper_bytecode_cache(self):
        copied=self.temp/'packet';copied.mkdir()
        manifest=json.loads((ROOT/'recipe-binding.json').read_text())
        for row in manifest['files']:
            target=copied/row['path'];target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(ROOT/row['path'],target)
        shutil.copyfile(ROOT/'recipe-binding.json',copied/'recipe-binding.json')
        source=copied/'binding.py'
        with patch('sys.pycache_prefix',None):
            cache=Path(importlib.util.cache_from_source(str(source)))
        cache.parent.mkdir()
        code=compile("raise SystemExit('UNEXPECTED_HELPER_CACHE')",str(source),'exec')
        cache.write_bytes(importlib.util.MAGIC_NUMBER+struct.pack('<III',0,int(source.stat().st_mtime),source.stat().st_size)
                          +marshal.dumps(code))
        result=subprocess.run([sys.executable,'-B',str(copied/'reproduce_orbit.py'),'--check',
            '--adapter-source',str(self.source),'--adapter-wheel',str(self.wheel),
            '--adapter-binding',str(self.binding)],capture_output=True,text=True,timeout=30)
        self.assertEqual(result.returncode,0,result.stderr or result.stdout)
        self.assertNotIn('UNEXPECTED_HELPER_CACHE',result.stdout+result.stderr)


if __name__=='__main__':unittest.main()
