#!/usr/bin/env python3
"""Bounded, file-only D058 selected evidence normalization and reconstruction.

No runtime adapter imports, network, native execution, or default historical paths.
Original records are read only. The explicit private input inventory and crosswalk
are review inputs, never prerequisites of the standalone native artwork runner.
"""
from __future__ import annotations
import argparse
import collections
import hashlib
import json
import math
from pathlib import Path
import re
import struct
import zlib

MAX_BYTES = 32 * 1024 * 1024
MAX_RECORDS = 20000
MAX_ARTIFACT_BYTES = 32 * 1024 * 1024
CREATIVE = frozenset(('create_image', 'create_layer', 'paint_shape', 'create_text'))
ARGUMENTS = {
    'create_image': 'width height name background_color',
    'create_layer': 'image_id name',
    'paint_shape': 'image_id layer_id shape bounds color points',
    'create_text': 'image_id font name text x y size color',
    'save_image': 'image_id path overwrite',
    'export_image': 'image_id path overwrite',
    'export_preview': 'image_id path max_width max_height overwrite',
    'open_image': 'path',
    'close_image': 'image_id discard_changes',
    'inspect_image': 'image_id include_metadata',
    'get_active_image': '',
    'fill_layer': 'image_id layer_id color',
    'list_images': '',
    'list_fonts': 'query limit',
}
IMAGE_FIELDS = set('image_id name width height base_type precision dirty color_profile typed_color_encoding file_name file_path_allowed selected_layer_ids bridge_owned_display'.split())
LAYER_FIELDS = set('layer_id parent_id depth name visible locked opacity is_group is_text text text_font text_color_linear_rgba child_count mode width height offsets'.split())
FILE_FIELDS = set('path bytes sha256'.split())
PREVIEW_FIELDS = FILE_FIELDS | set('source_image_id source_dimensions output_dimensions interpolation upscaled source_state_sha256 source_image_mutated temporary_image_deleted context_restored published'.split())
JOB_FIELDS = set('job_id core_job_id job_id_owner core_poll parent_job_id tool status created_at started_at completed_at updated_at progress error result'.split())
QUEUE_FIELDS = set('job_id core_job_id job_id_owner status parent_job_id core_poll _meta'.split())
TRANSPORT_FIELDS = set('meta content structuredContent isError'.split())
META_FIELDS = set('image_parasites layer_parasites metadata_xml metadata_xml_truncated'.split())
PARASITE_FIELDS = set('name flags bytes sha256 text truncated'.split())
CLEANUP_PUBLIC = set('owned_sigterm_requested force_kill_used server_stopped host_exited host_returncode plugin_status owned_plugin_exited listeners_closed native_log_collector_stopped normal_owned_shutdown_pass shutdown_method cleanup_errors peak_observed_run_bytes budget_is_stopping_threshold_not_quota run_bytes_at_cleanup free_bytes_at_cleanup ephemeral_environment_token_removed'.split())
SAFE_ID = re.compile(r'^[a-z][a-z0-9-]{0,63}$')
HEX = re.compile(r'^[0-9a-f]{64}$')
UUID = re.compile(r'\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b')
PRIVATE = re.compile(r'(?:^|[\s"\x27=])(?:/(?:[^/\s]+/)|[A-Za-z]:[\\/]|~[/\\])|(?:https?|file)://|\b(?:localhost|127\.0\.0\.1)\b')
POLICY = {
    'schema': 'D058-selected-normalization-policy-v1',
    'scope': 'Selected accepted component operations and local readback/cleanup facts; not full public raw-trace coverage',
    'canonical_json': 'UTF-8, sorted keys, compact separators, ensure_ascii=false, no NaN, no duplicate keys',
    'ordering': 'Input run order, then original request line order; arrays preserve source order',
    'aliases': 'Run-scoped image/layer/job aliases in first selected encounter order; layer owners checked; paths become exact component-relative basenames',
    'selected_arguments': ARGUMENTS,
    'selected_result_fields': {'image': sorted(IMAGE_FIELDS), 'layer': sorted(LAYER_FIELDS), 'file': sorted(FILE_FIELDS), 'preview': sorted(PREVIEW_FIELDS)},
    'inspection': 'Full structural image/layer fields validated; layers and private metadata represented by separate canonical SHA-256 summaries in operation results; saved/reopened structural readbacks are also supplied',
    'metadata': 'Validate known container/parasite fields; never publish raw XML, parasite text, error trees, transport text, timestamps, paths, process identity, or job UUIDs',
    'source_record_commitments': 'Each selected operation carries canonical original request and completed poll-response SHA-256 hashes; private crosswalk also retains queue and poll-request hashes and exact byte-line hashes',
    'fidelity': 'Reconstruct from actual original request, call response, and completed jobs_get_status response; compare every record and source artifact bytes; trace commitments alone are insufficient',
    'limits': {'input_file_bytes': MAX_BYTES, 'trace_records': MAX_RECORDS, 'artifact_bytes': MAX_ARTIFACT_BYTES, 'runs': 8, 'assets': 8},
    'claims_excluded': ['actual visual approval', 'full raw trace publication', 'native rerun', 'all-eight standalone portability', 'Godot acceptance', 'publication approval', 'independent selection-mask readback', 'cross-app color equality'],
}

class EvidenceError(ValueError):
    pass


def need(condition, message):
    if not condition:
        raise EvidenceError(message)


def canon(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode('utf-8')


def digest(value):
    return hashlib.sha256(canon(value)).hexdigest()


def sha_bytes(value):
    return hashlib.sha256(value).hexdigest()


def exact_keys(obj, allowed, required=None, where='object'):
    need(isinstance(obj, dict), where + ': expected object')
    allowed = set(allowed.split()) if isinstance(allowed, str) else set(allowed)
    required = allowed if required is None else set(required.split()) if isinstance(required, str) else set(required)
    need(set(obj) <= allowed, where + ': unknown/unallowlisted fields ' + repr(sorted(set(obj) - allowed)))
    need(required <= set(obj), where + ': missing fields ' + repr(sorted(required - set(obj))))


def no_duplicates(pairs):
    obj = {}
    for key, value in pairs:
        need(key not in obj, 'duplicate JSON key')
        obj[key] = value
    return obj


def parse(data):
    try:
        return json.loads(data, object_pairs_hook=no_duplicates, parse_constant=lambda x: (_ for _ in ()).throw(EvidenceError('nonfinite JSON')))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise EvidenceError('invalid UTF-8 JSON') from exc


def read_bytes(path, limit=MAX_BYTES):
    path = Path(path)
    need(path.is_file() and not path.is_symlink(), 'input is missing, nonregular, or symlink')
    need(path.stat().st_size <= limit, 'input exceeds bounded size')
    with path.open('rb') as stream:
        data = stream.read(limit + 1)
    need(len(data) <= limit, 'input grew beyond bound')
    return data


def read_json(path):
    return parse(read_bytes(path))


def public_safe(value):
    if isinstance(value, dict):
        for key, val in value.items():
            need(key not in {'pid', 'port', 'bridge_port', 'gimp_pid', 'plugin_pid', 'raw_job_id', 'original_path'}, 'private public field')
            public_safe(key)
            public_safe(val)
    elif isinstance(value, list):
        for val in value:
            public_safe(val)
    elif isinstance(value, str):
        need(not PRIVATE.search(value) and not UUID.search(value), 'private path, host, URL, or raw UUID in public value')
        need('\x00' not in value, 'NUL in public value')
    elif isinstance(value, float):
        need(math.isfinite(value), 'nonfinite number')
    else:
        need(value is None or isinstance(value, (bool, int)), 'invalid JSON value')


def component_filename(path, root, asset):
    need(isinstance(path, str) and '\\' not in path and '\x00' not in path, 'unsafe component path')
    p = Path(path)
    need(p.is_absolute() and p.parent == root and str(p) == path, 'path outside declared exact run root')
    name = p.name
    need(re.fullmatch(re.escape(asset) + r'(?:-[a-z0-9-]+)?\.(?:xcf|png)', name) is not None, 'wrong component file identity')
    need(not p.is_symlink() and p.resolve().parent == root, 'unsafe output symlink/path')
    return name


def payload(response):
    exact_keys(response, TRANSPORT_FIELDS, where='MCP response')
    need(response['isError'] is False and response['meta'] is None, 'MCP response error/meta')
    need(isinstance(response['content'], list), 'invalid content')
    for item in response['content']:
        exact_keys(item, 'type text annotations meta', where='transport text')
        need(item['type'] == 'text' and item['annotations'] is None and item['meta'] is None, 'unexpected transport content')
    need(isinstance(response['structuredContent'], dict), 'missing structured response')
    return response['structuredContent']


def native_context(result):
    """Unwrap the retained SDK ToolResult, not the whole job or active-image object."""
    exact_keys(result, 'success message context', where='native ToolResult')
    need(result['success'] is True and isinstance(result['message'], str), 'unsuccessful native result')
    need(isinstance(result['context'], dict), 'missing native context')
    return result['context']


def parse_trace(path):
    raw = read_bytes(path)
    lines = raw.splitlines(keepends=True)
    need(len(lines) <= MAX_RECORDS, 'too many trace records')
    records = [parse(line) for line in lines]
    pending = None
    pairs, jobs, native = [], {}, []
    for i, row in enumerate(records, 1):
        need(isinstance(row, dict) and 'kind' in row, 'invalid trace row')
        if row['kind'] == 'tools/call-request':
            exact_keys(row, 'kind tool arguments', where='request record')
            need(pending is None, 'unpaired overlapping request')
            pending = (i, row)
        elif row['kind'] == 'tools/call':
            exact_keys(row, 'kind tool arguments response', where='call record')
            need(pending is not None, 'unpaired response')
            n, req = pending
            need(req['tool'] == row['tool'] and canon(req['arguments']) == canon(row['arguments']), 'request/response identity mismatch')
            call = {'request_line': n, 'response_line': i, 'request': req, 'response': row}
            pairs.append(call)
            if row['tool'] == 'jobs_get_status':
                sc = payload(row['response'])
                need(sc.get('job_id') == row['arguments'].get('job_id'), 'poll job identity mismatch')
                jobs.setdefault(sc.get('job_id'), []).append((i, sc))
            elif row['tool'] not in ('search_skills', 'get_skill_info', 'load_skill'):
                native.append(call)
            pending = None
        else:
            need(row['kind'] in ('initialize', 'tools/list') and pending is None, 'unknown/interleaved trace record')
    need(pending is None, 'trailing unpaired call')
    return {'raw': raw, 'lines': lines, 'records': records, 'calls': native, 'jobs': jobs, 'pairs': pairs}


def resolve(call, trace):
    queue = payload(call['response']['response'])
    exact_keys(queue, QUEUE_FIELDS, where='queued native job')
    jid = queue['job_id']
    need(isinstance(jid, str) and UUID.fullmatch(jid), 'invalid native job ID')
    need(queue['core_job_id'] == jid and queue['job_id_owner'] == 'core' and queue['parent_job_id'] is None and queue['status'] == 'pending', 'wrong queued native job identity')
    poll_contract(queue['core_poll'], jid)
    exact_keys(queue['_meta'], 'status dcc', where='queue meta')
    dcc = queue['_meta']['dcc']
    exact_keys(dcc, 'jobId coreJobId jobOwner pollTool parentJobId', where='queue DCC meta')
    need(queue['_meta']['status'] == 'pending' and dcc == {'jobId': jid, 'coreJobId': jid, 'jobOwner': 'core', 'pollTool': 'jobs_get_status', 'parentJobId': None}, 'queue metadata identity mismatch')
    polls = trace['jobs'].get(jid, [])
    need(polls, 'missing selected job completion')
    for line, job in polls:
        exact_keys(job, JOB_FIELDS, required=JOB_FIELDS - {'result'}, where='completed job envelope')
        need(job['job_id'] == job['core_job_id'] == jid and job['job_id_owner'] == 'core' and job['parent_job_id'] is None, 'wrong selected job identity')
        need(job['tool'] == 'gimp_session__' + call['request']['tool'], 'wrong selected job tool')
        need(job['status'] not in ('failed', 'cancelled', 'interrupted') and job['error'] is None, 'failed selected job')
        need(line > call['response_line'], 'job completion precedes request')
        poll_contract(job['core_poll'], jid)
    done = [(line, job) for line, job in polls if job['status'] == 'completed']
    need(len(done) == 1 and polls[-1] == done[0], 'missing/duplicate/incomplete selected job completion')
    line, job = done[0]
    return {'job_id': jid, 'completed_line': line, 'context': native_context(job['result'])}


def poll_contract(obj, jid):
    exact_keys(obj, 'owner tool arguments', where='core poll')
    need(obj == {'owner': 'core', 'tool': 'jobs_get_status', 'arguments': {'job_id': jid, 'include_result': True}}, 'wrong core poll contract')


def validate_metadata(obj):
    exact_keys(obj, META_FIELDS, where='native metadata')
    need(isinstance(obj['metadata_xml'], (str, type(None))) and isinstance(obj['metadata_xml_truncated'], bool), 'invalid metadata XML container')
    def parasites(items):
        need(isinstance(items, list), 'invalid parasite list')
        for item in items:
            exact_keys(item, PARASITE_FIELDS, where='native parasite')
            need(isinstance(item['text'], str) and isinstance(item['name'], str) and isinstance(item['truncated'], bool), 'invalid parasite')
            need(HEX.fullmatch(item['sha256']) and isinstance(item['bytes'], int), 'invalid parasite digest')
    parasites(obj['image_parasites'])
    need(isinstance(obj['layer_parasites'], list), 'invalid layer parasites')
    for layer in obj['layer_parasites']:
        exact_keys(layer, 'name parasites', where='layer parasites')
        need(isinstance(layer['name'], str), 'invalid parasite layer name')
        parasites(layer['parasites'])


class Aliases:
    def __init__(self, run_id):
        self.run_id = run_id
        self.maps = {'image': {}, 'layer': {}, 'job': {}}
        self.layer_owners = {}

    def use(self, role, raw, new=False, owner=None):
        if raw is None:
            return None
        need((role == 'job' and isinstance(raw, str)) or (role != 'job' and type(raw) is int and raw > 0), 'invalid role identity')
        table = self.maps[role]
        key = str(raw)
        if key not in table:
            need(new, 'unknown mapped ' + role + ' identity')
            table[key] = f'{self.run_id}.{role}-{len(table)+1:03d}'
        if role == 'layer' and owner is not None:
            need(key not in self.layer_owners or self.layer_owners[key] == owner, 'wrong mapped layer owner')
            self.layer_owners[key] = owner
        return table[key]


def normalize_layer(raw, aliases, owner, allow_new):
    exact_keys(raw, LAYER_FIELDS, where='native layer')
    obj = dict(raw)
    obj['layer_id'] = aliases.use('layer', raw['layer_id'], allow_new, owner)
    obj['parent_id'] = aliases.use('layer', raw['parent_id'], allow_new, owner)
    public_safe(obj)
    return obj


def normalize_image(raw, aliases, root, asset, allow_new=False, inspect=False, full=False):
    allowed = IMAGE_FIELDS | ({'layer_count', 'layers', 'metadata'} if inspect else set())
    exact_keys(raw, allowed, where='native image')
    iid = raw['image_id']
    out = {k: v for k, v in raw.items() if k not in ('layers', 'metadata')}
    out['image_id'] = aliases.use('image', iid, allow_new)
    if out['file_name'] is not None:
        out['file_name'] = component_filename(out['file_name'], root, asset)
    out['selected_layer_ids'] = [aliases.use('layer', v, True, iid) for v in raw['selected_layer_ids']]
    if inspect:
        need(raw['layer_count'] == len(raw['layers']), 'layer count differs')
        layers = [normalize_layer(x, aliases, iid, True) for x in raw['layers']]
        validate_metadata(raw['metadata'])
        if full:
            out['layers'] = layers
        else:
            out['layers_sha256'] = digest(layers)
        out['metadata_sha256'] = digest(raw['metadata'])
    public_safe(out)
    return out


def normalized_call(call, completed, aliases, root, asset, main_id):
    tool = call['request']['tool']
    need(tool in ARGUMENTS, 'unallowlisted selected tool')
    args = dict(call['request']['arguments'])
    exact_keys(args, ARGUMENTS[tool], required=set(ARGUMENTS[tool].split()) - {'bounds', 'points'} if tool == 'paint_shape' else None, where=tool + ' arguments')
    ctx = completed['context']
    if tool == 'paint_shape':
        need(set(args) in ({'image_id', 'layer_id', 'shape', 'color', 'bounds'}, {'image_id', 'layer_id', 'shape', 'color', 'points'}), 'wrong shape argument shape')
    jid = aliases.use('job', completed['job_id'], True)
    owner = args.get('image_id')
    if owner is not None:
        args['image_id'] = aliases.use('image', owner)
    if 'layer_id' in args:
        args['layer_id'] = aliases.use('layer', args['layer_id'], owner=owner)
    if 'path' in args:
        args['path'] = component_filename(args['path'], root, asset)
    if tool == 'create_image':
        exact_keys(ctx, IMAGE_FIELDS | {'created_layer_id'}, where='created image')
        need(ctx['image_id'] == main_id and ctx['width'] == args['width'] and ctx['height'] == args['height'], 'created image identity/dimensions mismatch')
        result = normalize_image({k: v for k, v in ctx.items() if k != 'created_layer_id'}, aliases, root, asset, True)
        result['created_layer_id'] = aliases.use('layer', ctx['created_layer_id'], True, main_id)
    elif tool in ('create_layer', 'create_text'):
        allowed = LAYER_FIELDS | ({'font', 'font_size'} if tool == 'create_text' else set())
        exact_keys(ctx, allowed, where=tool + ' result')
        need(ctx['name'] == args['name'], 'created layer name mismatch')
        result = normalize_layer({k: v for k, v in ctx.items() if k in LAYER_FIELDS}, aliases, owner, True)
        if tool == 'create_text':
            need(ctx['text'] == args['text'] and ctx['font'] == ctx['text_font'] == args['font'] and ctx['font_size'] == args['size'] and ctx['offsets'] == [args['x'], args['y']], 'native text result differs')
            result.update(font=ctx['font'], font_size=ctx['font_size'])
    elif tool in ('paint_shape', 'fill_layer'):
        fields = {'layer_id', 'painted', 'shape'} if tool == 'paint_shape' else {'layer_id', 'filled'}
        exact_keys(ctx, fields, where=tool + ' result')
        need(ctx['layer_id'] == call['request']['arguments']['layer_id'], 'wrong native layer result identity')
        need(ctx['painted' if tool == 'paint_shape' else 'filled'] is True, 'native paint/fill not successful')
        if tool == 'paint_shape':
            need(ctx['shape'] == args['shape'], 'native shape mismatch')
        result = dict(ctx)
        result['layer_id'] = aliases.use('layer', ctx['layer_id'], owner=owner)
    elif tool in ('save_image', 'export_image', 'export_preview'):
        exact_keys(ctx, PREVIEW_FIELDS if tool == 'export_preview' else FILE_FIELDS, where=tool + ' result')
        need(ctx['path'] == call['request']['arguments']['path'] and args['overwrite'] is False, 'unsafe/wrong output target')
        data = read_bytes(root / args['path'], MAX_ARTIFACT_BYTES)
        need(ctx['bytes'] == len(data) and ctx['sha256'] == sha_bytes(data), 'native artifact result digest/size mismatch')
        result = dict(ctx, path=args['path'])
        if tool == 'export_preview':
            need(ctx['source_image_id'] == owner, 'wrong preview source identity')
            need(ctx['output_dimensions'] == [args['max_width'], args['max_height']], 'wrong preview dimensions')
            need(all(ctx[k] is True for k in ('temporary_image_deleted', 'context_restored', 'published')) and ctx['source_image_mutated'] is False and ctx['upscaled'] is False, 'preview state/cleanup failed')
            need(HEX.fullmatch(ctx['source_state_sha256']), 'invalid source-state hash')
            result['source_image_id'] = aliases.use('image', owner)
    elif tool == 'open_image':
        result = normalize_image(ctx, aliases, root, asset, True)
        need(result['file_name'] == args['path'], 'wrong reopened image path')
    elif tool == 'inspect_image':
        need(ctx.get('image_id') == owner, 'wrong inspected image identity')
        result = normalize_image(ctx, aliases, root, asset, inspect=True)
    elif tool == 'get_active_image':
        exact_keys(ctx, 'image', where='active image wrapper')
        result = {'image': normalize_image(ctx['image'], aliases, root, asset)}
    elif tool == 'close_image':
        exact_keys(ctx, 'image_id closed discarded_changes', where='closed image')
        need(ctx['image_id'] == owner and ctx['closed'] is True and ctx['discarded_changes'] is False and args['discard_changes'] is False, 'wrong close outcome')
        result = dict(ctx, image_id=aliases.use('image', owner))
    elif tool == 'list_images':
        exact_keys(ctx, 'images', where='final image inventory')
        need(ctx['images'] == [], 'final native image inventory not empty')
        result = {'images': []}
    elif tool == 'list_fonts':
        exact_keys(ctx, 'fonts match_count truncated', where='native fonts')
        need(ctx['truncated'] is False and ctx['match_count'] == len(ctx['fonts']) and 'DejaVu Sans Book' in ctx['fonts'], 'required native Book font absent')
        result = ctx
    else:
        raise EvidenceError('unallowlisted selected tool')
    public_safe(args)
    public_safe(result)
    return {'tool': tool, 'arguments': args, 'job': jid, 'status': 'completed', 'success': True, 'result': result}


def png_rgba(path):
    """Small independent RGBA/U8 PNG readback, bounded before decompression."""
    data = read_bytes(path, MAX_ARTIFACT_BYTES)
    need(data[:8] == b'\x89PNG\r\n\x1a\n', 'invalid PNG signature')
    pos, compressed, dimensions = 8, [], None
    while pos < len(data):
        need(pos + 12 <= len(data), 'truncated PNG chunk')
        n = struct.unpack('>I', data[pos:pos+4])[0]
        kind = data[pos+4:pos+8]
        body = data[pos+8:pos+8+n]
        need(pos + n + 12 <= len(data), 'truncated PNG payload')
        need(zlib.crc32(kind + body) & 0xffffffff == struct.unpack('>I', data[pos+8+n:pos+12+n])[0], 'PNG CRC mismatch')
        if kind == b'IHDR':
            need(dimensions is None and n == 13, 'invalid duplicate PNG IHDR')
            w, h, depth, ctype, comp, filt, interlace = struct.unpack('>IIBBBBB', body)
            need(1 <= w <= 512 and 1 <= h <= 512 and (depth, ctype, comp, filt, interlace) == (8, 6, 0, 0, 0), 'unsupported PNG format')
            dimensions = (w, h)
        elif kind == b'IDAT':
            compressed.append(body)
        pos += n + 12
        if kind == b'IEND':
            need(pos == len(data) and n == 0, 'unexpected PNG trailing data')
            break
    need(dimensions is not None and kind == b'IEND', 'missing PNG header/end')
    w, h = dimensions
    dec = zlib.decompressobj()
    raw = dec.decompress(b''.join(compressed), h*(w*4+1)+1)
    need(len(raw) == h*(w*4+1) and dec.eof and not dec.unconsumed_tail and not dec.unused_data, 'wrong/bomb PNG decompression length')
    rows, prior = [], bytearray(w*4)
    for y in range(h):
        start = y*(w*4+1)
        mode, row = raw[start], bytearray(raw[start+1:start+1+w*4])
        need(0 <= mode <= 4, 'unknown PNG filter')
        for x in range(w*4):
            a = row[x-4] if x >= 4 else 0
            b = prior[x]
            c = prior[x-4] if x >= 4 else 0
            if mode == 1: predictor = a
            elif mode == 2: predictor = b
            elif mode == 3: predictor = (a+b)//2
            elif mode == 4:
                p = a+b-c
                ds = (abs(p-a), abs(p-b), abs(p-c))
                predictor = a if ds[0] <= ds[1] and ds[0] <= ds[2] else b if ds[1] <= ds[2] else c
            else: predictor = 0
            row[x] = (row[x] + predictor) & 255
        rows.append(row)
        prior = row
    rgba = b''.join(rows)
    return {'dimensions': [w, h], 'rgba_sha256': sha_bytes(rgba), 'alpha_min_max': [min(rgba[3::4]), max(rgba[3::4])], 'transparent_count': rgba[3::4].count(0), 'opaque_count': rgba[3::4].count(255), 'semitransparent_count': sum(0 < a < 255 for a in rgba[3::4])}


def authoring_contract(asset):
    ops = [('create_image', {'width': 512, 'height': 512, 'name': 'transparent substrate', 'background_color': [0, 0, 0, 0]})]
    for layer in asset['layers_bottom_to_top']:
        ops.append(('create_layer', {'name': layer['name']}))
        ops.append(('paint_shape', {k: v for k, v in layer.items() if k != 'name'}))
    for text in asset['editable_text']:
        ops.append(('create_text', {'font': 'DejaVu Sans Book', **text}))
    return ops


def strip_ids(arguments):
    return {k: v for k, v in arguments.items() if k not in ('image_id', 'layer_id')}


def structural_state(raw):
    """Structural equality across reopen intentionally ignores native identities/dirty."""
    return {k: v for k, v in raw.items() if k in ('width', 'height', 'base_type', 'precision', 'color_profile', 'typed_color_encoding')} | {
        'layers': [{k: v for k, v in layer.items() if k not in ('layer_id', 'parent_id')} for layer in raw['layers']]}


def build(config):
    exact_keys(config, 'schema runs design_file component_status', required='schema runs design_file', where='private input inventory')
    component_status = config.get('component_status', 'technical-gates-passed-visual-review-separate')
    need(component_status in ('accepted-source-component', 'technical-gates-passed-visual-review-separate'), 'unknown component provenance status')
    need(config['schema'] == 'D058-evidence-inputs-v1', 'unsupported input inventory')
    need(1 <= len(config['runs']) <= 8, 'invalid run count')
    design_path = Path(config['design_file']).resolve()
    design_bytes = read_bytes(design_path)
    design = parse(design_bytes)
    designs = {x['id']: x for x in design['assets']}
    need(len(designs) == 8, 'expected final-eight design')
    records, sources, components, walks, alias_maps, supplementary = [], [], [], [], {}, []
    seen_assets, seen_runs = set(), set()
    per_asset_counts = {}
    for run in config['runs']:
        exact_keys(run, 'run_id directory assets batch_state', where='run inventory')
        run_id = run['run_id']
        need(isinstance(run_id, str) and SAFE_ID.fullmatch(run_id) and run_id not in seen_runs, 'invalid/duplicate run ID')
        seen_runs.add(run_id)
        need(run['batch_state'] in ('completed', 'failed-font-gate'), 'unknown batch state')
        root = Path(run['directory'])
        need(root.is_absolute() and root.resolve() == root and root.is_dir(), 'invalid declared run root')
        trace_path = root / 'mcp-trace.jsonl'
        trace = parse_trace(trace_path)
        aliases = Aliases(run_id)
        need(isinstance(run['assets'], list) and 1 <= len(run['assets']) <= 8, 'invalid selected component count')
        assets = {}
        resolved = {}
        def complete(c):
            key = c['request_line']
            if key not in resolved:
                resolved[key] = resolve(c, trace)
            return resolved[key]
        for asset in run['assets']:
            exact_keys(asset, 'asset_id shape_layers editable_text_layers rgba_sha256 artifacts', where='component inventory')
            aid = asset['asset_id']
            need(isinstance(aid, str) and SAFE_ID.fullmatch(aid) and aid in designs and aid not in seen_assets, 'wrong/duplicate mapped component identity')
            seen_assets.add(aid)
            d = designs[aid]
            need(asset['shape_layers'] == len(d['layers_bottom_to_top']) and asset['editable_text_layers'] == len(d['editable_text']), 'component design layer mismatch')
            master = [c for c in trace['calls'] if c['request']['tool'] == 'save_image' and c['request']['arguments'].get('path') == str(root / (aid + '.xcf'))]
            need(len(master) == 1, 'missing/duplicate master save for component')
            main_id = master[0]['request']['arguments']['image_id']
            identities = {main_id}
            for c in trace['calls']:
                if c['request']['tool'] == 'open_image' and c['request']['arguments'].get('path') == str(root / (aid + '.xcf')):
                    identities.add(complete(c)['context']['image_id'])
            need(len(identities) == 4, 'expected master plus three native source reopens')
            assets[aid] = {'contract': asset, 'main_id': main_id, 'ids': identities, 'creative': [], 'selected': [], 'inspections': []}
        all_ids = [i for a in assets.values() for i in a['ids']]
        need(len(all_ids) == len(set(all_ids)), 'wrong mapped component image identity overlap')
        final_list = [c for c in trace['calls'] if c['request']['tool'] == 'list_images'][-1]
        selected_jobs = set()
        for call in trace['calls']:
            tool, args = call['request']['tool'], call['request']['arguments']
            chosen = None
            for aid, a in assets.items():
                if args.get('image_id') in a['ids']:
                    chosen = aid
                elif tool == 'create_image' and complete(call)['context'].get('image_id') == a['main_id']:
                    chosen = aid
                elif tool == 'open_image' and args.get('path') == str(root / (aid + '.xcf')):
                    chosen = aid
                elif tool == 'get_active_image':
                    ctx = complete(call)['context']
                    exact_keys(ctx, 'image', where='active image wrapper')
                    if ctx['image'] is not None and ctx['image'].get('image_id') in a['ids']:
                        chosen = aid
            if tool == 'list_fonts' and 'orbital-stamp' in assets:
                chosen = 'orbital-stamp'
            if call is final_list:
                chosen = 'run-cleanup'
            if chosen is None:
                continue
            comp = complete(call)
            need(comp['job_id'] not in selected_jobs, 'reused selected job ID')
            selected_jobs.add(comp['job_id'])
            a = assets.get(chosen)
            normalized = normalized_call(call, comp, aliases, root, chosen, a['main_id'] if a else None)
            record = {'sequence': len(records)+1, 'run': run_id, 'component': chosen, 'category': 'creative' if tool in CREATIVE else 'native-evidence', **normalized, 'source_records_sha256': [digest(call['request']), digest(trace['records'][comp['completed_line']-1])]}
            if tool in CREATIVE:
                need(a and (tool == 'create_image' or args['image_id'] == a['main_id']), 'creative call on nonmaster')
                a['creative'].append((tool, strip_ids(args)))
            if a:
                a['selected'].append((call, comp, record))
                if tool == 'inspect_image':
                    a['inspections'].append((call['request_line'], comp['context']))
            records.append(record)
            lines = [call['request_line'], call['response_line'], comp['completed_line']-1, comp['completed_line']]
            walks.append({'sequence': record['sequence'], 'original_path': str(trace_path), 'source_lines': lines, 'raw_record_sha256': [sha_bytes(trace['lines'][i-1]) for i in lines], 'canonical_source_record_sha256': [digest(trace['records'][i-1]) for i in lines], 'published_record_sha256': digest(record), 'raw_job_id': comp['job_id']})
        for aid, a in assets.items():
            asset = a['contract']
            need(canon(a['creative']) == canon(authoring_contract(designs[aid])), 'creative operation/design mismatch for ' + aid)
            per_asset_counts[aid] = len(a['creative'])
            outputs = [record for _, _, record in a['selected'] if record['tool'] in ('save_image', 'export_image', 'export_preview')]
            names = [r['result']['path'] for r in outputs]
            need(len(names) == len(set(names)) and len(names) == 16, 'wrong/repeated component native output inventory')
            indexed = {r['result']['path']: r['result'] for r in outputs}
            for f in asset['artifacts']:
                exact_keys(f, 'filename bytes sha256', where='accepted artifact')
                need(f['filename'] in indexed and all(indexed[f['filename']][k] == f[k] for k in ('bytes', 'sha256')), 'wrong accepted component artifact identity')
            need({f['filename'] for f in asset['artifacts']} == {aid+'.xcf', aid+'.png', aid+'-128.png', aid+'-64.png'}, 'missing final component core files')
            main_saves = [(c, ctx) for c, ctx, rec in a['selected'] if rec['tool'] == 'save_image' and rec['result']['path'] == aid+'.xcf']
            master_line = main_saves[0][0]['request_line']
            saved = next(ctx for line, ctx in a['inspections'] if line > master_line and ctx['image_id'] == a['main_id'])
            loaded = [next(ctx for line, ctx in a['inspections'] if line > c['request_line'] and ctx['image_id'] == out['context']['image_id']) for c, out, rec in a['selected'] if rec['tool'] == 'open_image']
            need(len(loaded) == 3 and all(structural_state(x) == structural_state(saved) for x in loaded), 'native reopen structural mismatch')
            def selected_names(ctx):
                names = {layer['layer_id']: layer['name'] for layer in ctx['layers']}
                need(all(i in names for i in ctx['selected_layer_ids']), 'selected layer absent from native structure')
                return [names[i] for i in ctx['selected_layer_ids']]
            need(all(selected_names(x) == selected_names(saved) for x in loaded), 'reopened selected layers changed')
            previews = []
            for c, out, rec in a['selected']:
                if rec['tool'] == 'close_image':
                    prior = next(ctx for line, ctx in reversed(a['inspections']) if line < c['request_line'] and ctx['image_id'] == c['request']['arguments']['image_id'])
                    need(prior['dirty'] is False and prior['bridge_owned_display'] is True, 'unsafe close of dirty/unowned source')
                if rec['tool'] not in ('save_image', 'export_image', 'export_preview'):
                    continue
                image_id = c['request']['arguments']['image_id']
                before = next(ctx for line, ctx in reversed(a['inspections']) if line < c['request_line'] and ctx['image_id'] == image_id)
                after = next(ctx for line, ctx in a['inspections'] if line > c['request_line'] and ctx['image_id'] == image_id)
                need(structural_state(before) == structural_state(after) and before['selected_layer_ids'] == after['selected_layer_ids'], 'native output changed source structure/selection')
                if rec['tool'] == 'save_image':
                    need(after['dirty'] is False, 'native save left source dirty')
                if rec['tool'] != 'export_preview':
                    continue
                need(before == after, 'preview changed full native source state')
                for direction in (-1, 1):
                    ordered = reversed(trace['calls']) if direction == -1 else trace['calls']
                    active_call = next(x for x in ordered if x['request']['tool'] == 'get_active_image' and (x['request_line'] < c['request_line'] if direction == -1 else x['request_line'] > c['request_line']))
                    active_context = complete(active_call)['context']
                    exact_keys(active_context, 'image', where='active image wrapper')
                    need(active_context['image']['image_id'] == image_id, 'preview active-image preservation failed')
                previews.append({'filename': rec['result']['path'], 'source_state_sha256': rec['result']['source_state_sha256'], 'independent_full_native_before_after_equal': True, 'active_image_preserved': True})
            need(len(previews) == 6, 'expected six component previews')
            native_text_payloads = []
            xcf_data = read_bytes(root / (aid+'.xcf'))
            for layer_meta in saved['metadata']['layer_parasites']:
                for parasite in layer_meta['parasites']:
                    if parasite['name'] != 'gimp-text-layer':
                        continue
                    encoded = parasite['text'].encode('utf-8')
                    need(parasite['truncated'] is False and len(encoded) == parasite['bytes'] and sha_bytes(encoded) == parasite['sha256'] and xcf_data.count(encoded) == 1, 'native text payload does not match saved XCF')
                    native_text_payloads.append({'layer_name': layer_meta['name'], 'bytes': len(encoded), 'sha256': parasite['sha256']})
            need(len(native_text_payloads) == asset['editable_text_layers'], 'native saved text count mismatch')
            main_pixels = png_rgba(root / (aid+'.png'))
            need(main_pixels['rgba_sha256'] == asset['rgba_sha256'], 'wrong component decoded RGBA identity')
            need(png_rgba(root / (aid+'-reopened.png')) == main_pixels and png_rgba(root / (aid+'-after-previews.png')) == main_pixels, 'reopen/preview decoded RGBA changed')
            source_state = normalize_image(saved, aliases, root, aid, inspect=True, full=True)
            component = {'asset_id': aid, 'run': run_id, 'component_state': component_status, 'batch_state': run['batch_state'], 'creative_operations': len(a['creative']), 'shape_layers': asset['shape_layers'], 'editable_text_layers': asset['editable_text_layers'], 'artifacts': [{'filename': r['result']['path'], 'bytes': r['result']['bytes'], 'sha256': r['result']['sha256']} for r in outputs], 'png_readback': main_pixels, 'native_saved_state': source_state, 'preview_state_checks': previews, 'native_text_payloads_matched_saved_xcf': native_text_payloads, 'native_reopen_count': len(loaded), 'native_reopen_structural_equal': True, 'master_after_previews_and_reopened_rgba_equal': True, 'authoring_xcf_bytes_preserved': True, 'independent_selection_mask_readback_available': False}
            public_safe(component)
            components.append(component)
        cleanup = read_json(root/'cleanup.json')
        exact_keys(cleanup, CLEANUP_PUBLIC | {'owned_host_start_provenance', 'owned_plugin_start_provenance'}, where='cleanup receipt')
        need(cleanup['normal_owned_shutdown_pass'] is True and cleanup['force_kill_used'] is False and cleanup['cleanup_errors'] == [], 'native cleanup failed')
        clean = {k: v for k, v in cleanup.items() if k in CLEANUP_PUBLIC}
        public_safe(clean)
        batch = {'state': run['batch_state']}
        if run['batch_state'] == 'failed-font-gate':
            failure = read_json(root/'failure.json')
            def nodes(obj):
                if isinstance(obj, dict):
                    yield obj
                    for v in obj.values():
                        yield from nodes(v)
                elif isinstance(obj, list):
                    for v in obj:
                        yield from nodes(v)
            need(not (root/'qualification.json').exists() and any(n.get('message') == 'Exact required native font DejaVu Sans is unavailable' for n in nodes(failure)), 'font-gate batch failure not established')
            batch.update(component_pass_does_not_imply_batch_pass=True, stopped_at='font gate after accepted sealed component', later_stamp_mutation=False, failure_receipt_sha256=sha_bytes(read_bytes(root/'failure.json')))
            need(not any(c['request']['tool']=='create_text' for c in trace['calls']) and sum(c['request']['tool']=='create_image' for c in trace['calls']) == 2, 'unexpected V2 stamp mutation')
        else:
            qual = read_json(root/'qualification.json')
            need(qual['status'].startswith('PASS_'), 'batch qualification failed')
            batch['original_qualification_status'] = qual['status']
        sources.append({'run': run_id, 'raw_trace_sha256': sha_bytes(trace['raw']), 'raw_trace_records': len(trace['records']), 'selected_records': len(selected_jobs), 'selected_components': list(assets), 'batch': batch, 'cleanup': clean})
        supplementary.append({'path': str(root/'cleanup.json'), 'sha256': sha_bytes(read_bytes(root/'cleanup.json'))})
        alias_maps[run_id] = {'roles': aliases.maps, 'layer_owners': aliases.layer_owners, 'declared_root': str(root)}
    need(len(seen_assets) == 8 and sum(per_asset_counts.values()) == 162, 'must select all final eight and exactly 162 creative calls')
    counts = dict(collections.Counter(r['tool'] for r in records))
    results = {'schema': 'D058-selected-results-v1', 'scope': POLICY['scope'], 'selected_record_count': len(records), 'creative_operation_count': 162, 'creative_counts_by_component': per_asset_counts, 'selected_tool_counts': counts, 'sources': sources, 'components': components, 'design_sha256': sha_bytes(design_bytes), 'normalization_policy_sha256': digest(POLICY), 'normalizer_sha256': sha_bytes(read_bytes(Path(__file__).resolve())), 'limits': POLICY['claims_excluded']}
    crosswalk = {'schema': 'D058-private-selected-crosswalk-v1', 'private_not_for_public_packet': True, 'input_inventory': config, 'aliases': alias_maps, 'records': walks, 'supplementary_sources': supplementary}
    public_safe(results)
    return records, results, crosswalk


def output_bytes(records, results):
    return {'selected-operations.jsonl': b''.join(canon(r)+b'\n' for r in records), 'selected-results.json': canon(results)+b'\n', 'normalization-policy.json': canon(POLICY)+b'\n'}


def write_outputs(config_path, public_dir, private_dir):
    config = read_json(config_path)
    records, results, crosswalk = build(config)
    public_dir, private_dir = Path(public_dir), Path(private_dir)
    need(not public_dir.resolve().is_relative_to(private_dir.resolve()) and not private_dir.resolve().is_relative_to(public_dir.resolve()), 'public/private destinations must be separate and nonnested')
    for dest in (public_dir, private_dir):
        need(not dest.is_symlink(), 'unsafe output directory')
        for run in config['runs']:
            root = Path(run['directory'])
            need(not dest.resolve().is_relative_to(root) and not root.is_relative_to(dest.resolve()), 'output overlaps retained run')
    for dest in (public_dir, private_dir):
        dest.mkdir(parents=True, exist_ok=True)
    outputs = output_bytes(records, results)
    targets = [(public_dir/name, data) for name, data in outputs.items()] + [(private_dir/'source-crosswalk.json', canon(crosswalk)+b'\n')]
    need(all(not path.exists() and not path.is_symlink() for path, _ in targets), 'refusing overwrite of existing evidence output')
    for path, data in targets:
        with path.open('xb') as stream:
            stream.write(data)
    return {'status': 'PASS_SELECTED_NORMALIZATION', 'records': len(records), 'creative_calls': 162, 'per_component': results['creative_counts_by_component']}


def verify_reconstruction(config_path, public_dir, crosswalk_path):
    """Fresh reconstruction from originals; compare bytes, identities, and crosswalk.

    This deliberately does not trust a published digest as evidence. The separate
    checker in evidence-normalization also reverses every published request alias
    independently and checks the cited raw completion lines.
    """
    records, results, crosswalk = build(read_json(config_path))
    for name, expected in output_bytes(records, results).items():
        need(read_bytes(Path(public_dir)/name) == expected, 'reconstruction mismatch: ' + name)
    need(read_json(crosswalk_path) == crosswalk, 'private source crosswalk mismatch')
    return {'status': 'PASS_RECONSTRUCTED_FROM_ORIGINAL_REQUESTS_AND_COMPLETED_JOBS', 'selected_records': len(records), 'creative_calls': 162, 'component_count': 8, 'normalization_policy_sha256': digest(POLICY)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    create = sub.add_parser('normalize')
    create.add_argument('--inputs', required=True)
    create.add_argument('--public-dir', required=True)
    create.add_argument('--private-dir', required=True)
    check = sub.add_parser('verify')
    check.add_argument('--inputs', required=True)
    check.add_argument('--public-dir', required=True)
    check.add_argument('--crosswalk', required=True)
    args = parser.parse_args()
    if args.command == 'normalize':
        result = write_outputs(args.inputs, args.public_dir, args.private_dir)
    else:
        result = verify_reconstruction(args.inputs, args.public_dir, args.crosswalk)
    print(json.dumps(result, sort_keys=True))

if __name__ == '__main__':
    main()
