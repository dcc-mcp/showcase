"""Seal the standalone D058 recipe only; external adapter inputs stay explicit."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def main():
    files=[path for path in ROOT.glob('*.py') if path.is_file()]
    files += [ROOT/name for name in ('README.md','RIGHTS.md','design.json','batch-plan.json',
              'font-policy.json','DejaVu-font-notice.txt','observed-native-schemas.json',
              'reviewed-adapter-bindings.json','recipe-origins.json','accepted-component-reference.json')]
    files += list((ROOT/'adapter-bindings').glob('*.json'))
    files += list((ROOT/'test-fixtures').glob('*.json'))
    checker=ROOT/'evidence-normalization/reconstruct_selected_evidence.py'
    if checker.is_file():files.append(checker)
    rows=[]
    for path in sorted(files):
        if path.is_symlink() or not path.is_file():
            raise RuntimeError('Expected regular standalone source file')
        data=path.read_bytes()
        rows.append({'path':str(path.relative_to(ROOT)),'bytes':len(data),
                     'sha256':hashlib.sha256(data).hexdigest()})
    result={'schema':'D058-standalone-recipe-binding-v1','files':rows,
            'native_qualification':'NOT_EXECUTED_FOR_THIS_STANDALONE_RECIPE',
            'adapter_source_and_wheel':'Explicit operator inputs; exact reviewed digest allowlist required',
            'historical_native_source':'a3b45aaa237aef954247c8571fb0762afe5cface',
            'artwork_inputs_unchanged':True,'private_evidence_not_in_this_source_binding':True}
    (ROOT/'recipe-binding.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'SEALED_FILE_ONLY_STANDALONE_RECIPE','files':len(rows),
                      'sha256':hashlib.sha256((ROOT/'recipe-binding.json').read_bytes()).hexdigest()}))


if __name__=='__main__':main()
