#!/usr/bin/env python3
"""Independent inverse-alias checks on selected records and original trace lines.

This checker does not call the generator's parse_trace, resolve, normalized_call,
build, or verifier. The original crosswalk is private. This checks request values,
completed-job identities, full selected result projections, artifact bytes, and
published record commitments directly. It is a file-only verifier, not a claim
that an independent human reviewer approved the packet.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re


def must(ok, message):
    if not ok:
        raise ValueError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    p = Path(path)
    must(p.is_file() and not p.is_symlink() and p.stat().st_size <= 32*1024*1024, 'unsafe/oversize input')
    return json.loads(p.read_bytes())


def check(public_dir, crosswalk_path):
    public_dir = Path(public_dir)
    crosswalk = load(crosswalk_path)
    operations = [json.loads(line) for line in (public_dir/'selected-operations.jsonl').read_bytes().splitlines()]
    results = load(public_dir/'selected-results.json')
    policy = load(public_dir/'normalization-policy.json')
    must(sha(canonical(policy)) == results['normalization_policy_sha256'], 'policy commitment mismatch')
    must(len(operations) == len(crosswalk['records']) == results['selected_record_count'], 'selected count mismatch')
    roots, traces = {}, {}
    run_inputs = {r['run_id']: r for r in crosswalk['input_inventory']['runs']}
    for source in results['sources']:
        rid = source['run']
        roots[rid] = Path(run_inputs[rid]['directory'])
        data = (roots[rid]/'mcp-trace.jsonl').read_bytes()
        must(len(data) <= 32*1024*1024 and sha(data) == source['raw_trace_sha256'], 'trace commitment mismatch')
        lines = data.splitlines(keepends=True)
        traces[rid] = (lines, [json.loads(x) for x in lines])
    def maps(rid):
        return crosswalk['aliases'][rid]['roles']
    def forward(rid, role, raw):
        if raw is None: return None
        table = maps(rid)[role]
        must(str(raw) in table, 'unmapped source identity')
        return table[str(raw)]
    def inverse(rid, role, alias):
        matches = [key for key, value in maps(rid)[role].items() if value == alias]
        must(len(matches) == 1, 'alias is missing or ambiguous')
        return matches[0] if role == 'job' else int(matches[0])
    def path(rid, aid, value):
        p = Path(value)
        must(p.parent == roots[rid] and str(p) == value and re.fullmatch(re.escape(aid)+r'(?:-[a-z0-9-]+)?\.(?:png|xcf)', p.name), 'wrong component path')
        return p.name
    def layer(rid, value):
        out = dict(value)
        out['layer_id'] = forward(rid, 'layer', value['layer_id'])
        out['parent_id'] = forward(rid, 'layer', value['parent_id'])
        return out
    def image(rid, aid, value):
        out = dict(value)
        out['image_id'] = forward(rid, 'image', value['image_id'])
        out['selected_layer_ids'] = [forward(rid, 'layer', n) for n in value['selected_layer_ids']]
        if out['file_name'] is not None: out['file_name'] = path(rid, aid, out['file_name'])
        if 'created_layer_id' in out: out['created_layer_id'] = forward(rid, 'layer', out['created_layer_id'])
        if 'layers' in out: out['layers_sha256'] = sha(canonical([layer(rid, x) for x in out.pop('layers')]))
        if 'metadata' in out: out['metadata_sha256'] = sha(canonical(out.pop('metadata')))
        return out
    totals = {}
    artifact_count = 0
    for ordinal, (pub, walk) in enumerate(zip(operations, crosswalk['records']), 1):
        rid, aid, tool = pub['run'], pub['component'], pub['tool']
        must(pub['sequence'] == walk['sequence'] == ordinal, 'record order mismatch')
        must(walk['original_path'] == str(roots[rid]/'mcp-trace.jsonl'), 'crosswalk source mismatch')
        raw_lines, raw_records = traces[rid]
        nums = walk['source_lines']
        must(len(nums) == 4 and nums[0] < nums[1] < nums[2] < nums[3], 'wrong source line order')
        must(walk['raw_record_sha256'] == [sha(raw_lines[n-1]) for n in nums], 'raw selected line commitment mismatch')
        must(walk['canonical_source_record_sha256'] == [sha(canonical(raw_records[n-1])) for n in nums], 'canonical source commitment mismatch')
        request, response, poll_request, poll_response = [raw_records[n-1] for n in nums]
        must(pub['source_records_sha256'] == [sha(canonical(request)), sha(canonical(poll_response))], 'public source record commitments differ')
        must(request['kind'] == 'tools/call-request' and response['kind'] == 'tools/call' and request['tool'] == response['tool'] == tool, 'wrong original call')
        must(request['arguments'] == response['arguments'], 'original call arguments differ')
        raw_args = dict(pub['arguments'])
        for key in ('image_id', 'layer_id'):
            if key in raw_args: raw_args[key] = inverse(rid, key[:-3], raw_args[key])
        if 'path' in raw_args:
            must(Path(raw_args['path']).name == raw_args['path'], 'unsafe published path')
            raw_args['path'] = str(roots[rid]/raw_args['path'])
        must(raw_args == request['arguments'], 'published arguments do not reconstruct original request')
        job_id = inverse(rid, 'job', pub['job'])
        queue = response['response']['structuredContent']
        must(queue['job_id'] == queue['core_job_id'] == walk['raw_job_id'] == job_id, 'queued job identity mismatch')
        must(poll_request['kind'] == 'tools/call-request' and poll_response['kind'] == 'tools/call' and poll_request['tool'] == poll_response['tool'] == 'jobs_get_status', 'wrong completion call')
        must(poll_request['arguments'] == poll_response['arguments'] == {'job_id': job_id, 'include_result': True}, 'wrong completed job poll')
        job = poll_response['response']['structuredContent']
        must(job['job_id'] == job['core_job_id'] == job_id and job['tool'] == 'gimp_session__'+tool and job['status'] == pub['status'] == 'completed' and job['error'] is None and job['result']['success'] is pub['success'] is True, 'selected job did not complete successfully')
        ctx = job['result']['context']
        if tool in ('create_image', 'open_image', 'inspect_image'):
            expected = image(rid, aid, ctx)
        elif tool == 'get_active_image':
            must(set(ctx) == {'image'}, 'wrong active-image wrapper')
            expected = {'image': image(rid, aid, ctx['image'])}
        elif tool in ('create_layer', 'create_text'):
            expected = layer(rid, ctx)
        elif tool in ('paint_shape', 'fill_layer'):
            expected = dict(ctx, layer_id=forward(rid, 'layer', ctx['layer_id']))
        elif tool in ('save_image', 'export_image', 'export_preview'):
            expected = dict(ctx, path=path(rid, aid, ctx['path']))
            if tool == 'export_preview': expected['source_image_id'] = forward(rid, 'image', ctx['source_image_id'])
            data = (roots[rid]/expected['path']).read_bytes()
            must(len(data) == ctx['bytes'] and sha(data) == ctx['sha256'], 'native output bytes differ')
            artifact_count += 1
        elif tool == 'close_image':
            expected = dict(ctx, image_id=forward(rid, 'image', ctx['image_id']))
        elif tool in ('list_images', 'list_fonts'):
            expected = ctx
        else:
            raise ValueError('unknown selected tool')
        must(pub['result'] == expected, 'published result is not exact allowed original projection')
        must(sha(canonical(pub)) == walk['published_record_sha256'], 'published record commitment mismatch')
        if pub['category'] == 'creative': totals[aid] = totals.get(aid, 0) + 1
    must(totals == results['creative_counts_by_component'] and sum(totals.values()) == 162, 'creative count mismatch')
    return {'status': 'PASS_INDEPENDENT_INVERSE_ALIAS_RECONSTRUCTION', 'selected_records': len(operations), 'creative_calls': 162, 'native_artifact_hashes_checked': artifact_count, 'source_runs': len(traces), 'full_raw_trace_publication_claimed': False}

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--public-dir', required=True)
    parser.add_argument('--crosswalk', required=True)
    args = parser.parse_args()
    print(json.dumps(check(args.public_dir, args.crosswalk), sort_keys=True))
