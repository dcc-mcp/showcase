"""File-only immutable input, adapter, recipe, and typed-argument checks."""
import ast
import collections
import json
from pathlib import Path

from binding import check_delivery, no_symlinks
from lifecycle import require, sha
from orbit_workflow import FONT_FACE, PILOT_IDS, authoring_operations

PREP=Path(__file__).resolve().parent
INPUTS={'design.json':'60c3654f4bb60abe2e013fbdb23bb7c66545aed476317b648148bb17f9377302'}


def check_recipe_binding():
    receipt=json.loads((PREP/'recipe-binding.json').read_text())
    require(receipt['schema']=='D058-standalone-recipe-binding-v1', 'Wrong recipe binding schema')
    paths=set()
    for row in receipt['files']:
        path=no_symlinks(PREP/row['path'])
        require(path.is_relative_to(PREP) and path.is_file() and path.stat().st_size==row['bytes']
                and sha(path)==row['sha256'], 'Recipe/input/helper differs: '+row['path'])
        paths.add(row['path'])
    require({p.name for p in PREP.glob('*.py')} == {p for p in paths if '/' not in p and p.endswith('.py')},
            'Unbound top-level Python module could shadow imports')
    for name,digest in INPUTS.items():
        require(sha(PREP/name)==digest, 'Original D058 input bytes differ: '+name)
    font_policy=json.loads((PREP/'font-policy.json').read_text())
    require(font_policy['native_face']==FONT_FACE and font_policy['silent_fallback_allowed'] is False,
            'Explicit standalone native font policy differs')
    return {'recipe_binding_sha256':sha(PREP/'recipe-binding.json'),'bound_files':len(paths)}


def supporting_samples():
    """Concrete representative dynamic arguments, separate from creative geometry."""
    return [
        ('get_status',{}),('list_images',{}),('get_active_image',{}),
        ('list_fonts',{'query':'DejaVu Sans','limit':256}),
        ('inspect_image',{'image_id':1,'include_metadata':True}),
        ('create_image',{'width':96,'height':96,'name':'fixture substrate','background_color':[0,0,0,0]}),
        ('create_layer',{'image_id':1,'name':'fixture rectangle'}),
        ('fill_layer',{'image_id':1,'layer_id':1,'color':[80,120,200,128]}),
        ('fill_layer',{'image_id':1,'layer_id':1,'color':[0,0,0,0]}),
        ('fill_layer',{'image_id':1,'layer_id':1,'color':[24,35,43,255]}),
        ('fill_layer',{'image_id':1,'layer_id':1,'color':[247,244,234,255]}),
        ('paint_shape',{'image_id':1,'layer_id':1,'shape':'rectangle','bounds':[8,8,64,64],'color':[200,160,120,255]}),
        ('paint_shape',{'image_id':1,'layer_id':1,'shape':'ellipse','bounds':[44,40,36,36],'color':[48,119,120,128]}),
        ('paint_shape',{'image_id':1,'layer_id':1,'shape':'polygon','points':[[12,12],[64,12],[38,64]],'color':[224,108,65,255]}),
        ('set_layer_mode',{'image_id':1,'layer_id':1,'mode':'multiply'}),
        ('set_layer_mode',{'image_id':1,'layer_id':1,'mode':'normal'}),
        ('set_layer_properties',{'image_id':1,'layer_id':1,'name':'fixture renamed polygon',
                                'visible':False,'locked':True,'opacity':50}),
        ('set_layer_properties',{'image_id':1,'layer_id':1,'name':'fixture polygon',
                                'visible':True,'locked':False,'opacity':50}),
        ('set_layer_properties',{'image_id':1,'layer_id':1,'opacity':100}),
        ('save_image',{'image_id':1,'path':'fixture.xcf','overwrite':False}),
        ('open_image',{'path':'fixture.xcf'}),
        ('export_image',{'image_id':1,'path':'fixture.png','overwrite':False}),
        ('export_preview',{'image_id':1,'path':'fixture-128.png','max_width':128,'max_height':128,'overwrite':False}),
        ('export_preview',{'image_id':1,'path':'fixture-64.png','max_width':64,'max_height':64,'overwrite':False}),
        ('close_image',{'image_id':1,'discard_changes':False}),
    ]


def validate_inventory(package):
    import jsonschema
    import yaml
    schemas={r['name']:r['input_schema'] for r in
             yaml.safe_load((Path(package)/'skills/gimp-session/tools.yaml').read_text())['tools']}
    observed=json.loads((PREP/'observed-native-schemas.json').read_text())
    require(set(schemas)==set(observed) and len(schemas)==25, 'Observed typed schema inventory differs')
    gaps=[]
    for name in schemas:
        expected=dict(schemas[name])
        if name=='paint_shape':
            condition=expected.pop('allOf')
            require(condition and expected==observed[name], 'Unexpected paint_shape projection')
            gaps.append({'tool':name,'omitted_source_keyword':'allOf',
                         'mitigation':'Every call validated against both pinned source and discovered schemas',
                         'source_validation_weakened':False})
        else:
            require(schemas[name]==observed[name], 'Unexpected schema difference: '+name)
    design=json.loads((PREP/'design.json').read_text())
    require(design['canvas']==[512,512] and len(design['assets'])==8, 'Original kit scope differs')
    require(sum(len(a['layers_bottom_to_top']) for a in design['assets'])==76, 'Shape layer count differs')
    require(sum(len(a['editable_text']) for a in design['assets'])==2, 'Editable text count differs')
    all_operations=[]; pilot_operations=[]
    for asset in design['assets']:
        require(asset['canvas']==[512,512], 'Asset canvas differs')
        if asset['id']=='orbital-stamp':
            edge=asset['layers_bottom_to_top'][0]
            points=edge['points']
            require(edge['color'][3]==255 and all(type(v) is int for point in points for v in point)
                    and all(a[0]==b[0] or a[1]==b[1] for a,b in zip(points,points[1:]+points[:1])),
                    'Stamp binary-alpha allowance requires opaque integer-aligned outer geometry')
        names=[r['name'] for r in asset['layers_bottom_to_top']+asset['editable_text']]
        require(len(set(names+['transparent substrate']))==len(names)+1, 'Layer names must be unique')
        for layer in asset['layers_bottom_to_top']:
            if layer['shape']=='polygon':
                require(all(0<=x<=512 and 0<=y<=512 for x,y in layer['points']), 'Shape outside canvas')
            else:
                x,y,w,h=layer['bounds']
                require(w>0 and h>0 and 0<=x<x+w<=512 and 0<=y<y+h<=512, 'Shape bounds outside canvas')
        ops=authoring_operations(asset)
        all_operations.extend(ops)
        if asset['id'] in PILOT_IDS:
            pilot_operations.extend(ops)
    examples=supporting_samples()
    for tool,args in all_operations+examples:
        jsonschema.validate(args,schemas[tool])
        jsonschema.validate(args,observed[tool])
    # Preserve bounded expected rejections for the exact runtime projection gap.
    invalid_cases=[
        {'image_id':1,'layer_id':1,'shape':'polygon','color':[0,0,0,255],'bounds':[0,0,8,8]},
        {'image_id':1,'layer_id':1,'shape':'ellipse','color':[0,0,0,255],'points':[[0,0],[1,1],[2,0]]}]
    rejected=[]
    for args in invalid_cases:
        jsonschema.validate(args,observed['paint_shape'])
        try:
            jsonschema.validate(args,schemas['paint_shape'])
        except jsonschema.ValidationError as exc:
            rejected.append({'arguments':args,'source_rejected':True,'runtime_schema_accepted':True,
                             'reason':exc.message,'validator':exc.validator})
        else:
            raise RuntimeError('Source conditional unexpectedly accepted invalid shape arguments')
    native_used=sorted({t for t,_ in pilot_operations+examples})
    planned_only=sorted({t for t,_ in all_operations}-set(native_used))
    plan=json.loads((PREP/'batch-plan.json').read_text())
    batches=[]
    for batch in plan['batches']:
        batch_assets=[a for a in design['assets'] if a['id'] in batch['asset_ids']]
        ops=[operation for a in batch_assets for operation in authoring_operations(a)]
        require(len(batch_assets)==len(batch['asset_ids']) and len(batch_assets)<=2,
                'Bounded batch asset scope differs')
        require(sum(len(a['layers_bottom_to_top']) for a in batch_assets)==batch['shape_layers']
                and sum(len(a['editable_text']) for a in batch_assets)==batch['editable_text_layers'],
                'Batch declared layers differ')
        batches.append({'batch_id':batch['id'],'asset_ids':batch['asset_ids'],
                        'authoring_operations':len(ops),'shape_layers':batch['shape_layers'],
                        'editable_text_layers':batch['editable_text_layers']})
    require([a for b in plan['batches'] for a in b['asset_ids']]==
            ['sealed-envelope','open-envelope','orbital-stamp','dispatch-arrow','arrival-beacon','priority-parcel','accepted-seal','return-seal'],
            'Standalone batch order/scope differs from the exact eight-asset kit')
    return {'status':'PASS_FILE_ONLY_SCHEMA_CHECKS_NATIVE_NOT_EXECUTED',
            'planned_asset_count':8,'pilot_asset_ids':list(PILOT_IDS),
            'pilot_authoring_operations':len(pilot_operations),
            'all_asset_authoring_operations':len(all_operations),
            'supporting_argument_examples':len(examples),
            'batches':batches,'approved_design_bytes_verified':True,
            'explicit_native_font_face':FONT_FACE,
            'font_availability_source':'Explicit canonical Book face, requiring fresh complete native discovery before text authoring',
            'pilot_authoring_by_tool':dict(collections.Counter(t for t,_ in pilot_operations)),
            'pilot_native_tools_to_invoke':native_used,'planned_only_tools_not_invoked':planned_only,
            'schema_projection_gaps':gaps,'invalid_shape_expected_rejections':rejected,
            'selected_layer_readback_available':True,'paint_selection_mask_bytes_gate':'UNQUALIFIED',
            'native_preview_selection_mask_check':'Internal native full-source fingerprint only',
            'artifact_visual_quality':'NOT_INSPECTED','cross_app_godot_native_gate':'NOT_EXECUTED'}


def check_all(source_root, wheel_path, binding_path):
    recipe=check_recipe_binding()
    check=check_delivery(source_root,wheel_path,binding_path)
    inventory=validate_inventory(check['package'])
    for path in PREP.glob('*.py'):
        ast.parse(path.read_text(),filename=str(path))
    return {**check,**recipe,'status':'D058_STANDALONE_FILE_ONLY_READY_NATIVE_NOT_EXECUTED',
            'operation_inventory':inventory,'full_D058_acceptance':False,
            'showcase_completion_count_contribution':0}
