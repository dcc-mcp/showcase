#!/usr/bin/env python3
"""D058 standalone reproduction. Default check mode is file-only; --run owns one GIMP host.

No installation, network fallback, arbitrary native scripts or GUI terminal use.
The parent owns serial GUI admission and reviews this driver before --run.
"""
import sys
sys.dont_write_bytecode = True
# Apply before importing any project helper. -B alone does not disable cache reads.
import os as _bootstrap_os
sys.pycache_prefix=_bootstrap_os.path.join(
    _bootstrap_os.path.abspath(_bootstrap_os.environ.get('TMPDIR','/tmp')),
    'd058-unused-bytecode-'+_bootstrap_os.urandom(16).hex())
if _bootstrap_os.path.lexists(sys.pycache_prefix):
    raise RuntimeError('Initial project-helper bytecode lookup prefix must be fresh')
import argparse
import asyncio
import fcntl
import json
import os
import re
import secrets
import shutil
import signal
import subprocess
import threading
import time
from dataclasses import asdict
from pathlib import Path
from urllib.parse import urlsplit
from binding import PLUGIN_SHA, no_symlinks
from lifecycle import (BUDGET, DEADLINE, FREE_FLOOR, Run, exception_tree, port_closed,
                       require, sha, unused_loopback_port)
from orbit_workflow import workflow
from static_check import check_all
PREP = Path(__file__).resolve().parent


class PilotRun(Run):
    """Keep copied lifecycle unchanged, adding fail-closed native allocation checks."""
    def budget(self, extra=0):
        super().budget(extra)
        log = self.root / 'native.log'
        if log.is_file():
            size = log.stat().st_size
            previous = getattr(self, '_allocation_scan_offset', 0)
            if size > previous:
                with log.open('rb') as stream:
                    stream.seek(max(0, previous - 256))
                    recent = stream.read(min(size - max(0, previous - 256), 8 * 1024**2)).lower()
                self._allocation_scan_offset = size
                phrases = (b'failed to allocate', b'cannot allocate', b'could not allocate',
                           b'out of memory', b'not enough memory', b'bad_alloc', b'g_malloc:')
                if any(phrase in recent for phrase in phrases):
                    self.halt('Native allocation error observed; no bypass or replay')
                    raise RuntimeError(self.halt_reason)


def finalize_cleanup(run, cleanup, previous_handlers, lock_handle):
    """Evidence failures never prevent release of process-local lifecycle state."""
    errors=cleanup.setdefault('cleanup_errors',[])
    def record(stage, exc):
        errors.append({'stage':stage,'type':type(exc).__name__,
                       'message':run.clean(str(exc))[:512]})
        cleanup['normal_owned_shutdown_pass']=False
    try:
        cleanup['peak_observed_run_bytes']=run.max_bytes
        cleanup['budget_is_stopping_threshold_not_quota']=True
        try:
            cleanup['run_bytes_at_cleanup']=run.usage()
            cleanup['free_bytes_at_cleanup']=shutil.disk_usage(run.root).free
        except BaseException as exc:
            record('cleanup_metrics',exc)
    finally:
        run.guard_done.set()
        os.environ.pop('DCC_MCP_GIMP_BRIDGE_TOKEN',None)
        cleanup['ephemeral_environment_token_removed']=True
        for sig,previous in previous_handlers.items():
            try:
                signal.signal(sig,previous)
            except BaseException as exc:
                record('signal_handler_restore',exc)
        try:
            fcntl.flock(lock_handle,fcntl.LOCK_UN)
        except BaseException as exc:
            record('lane_unlock',exc)
        finally:
            try:
                lock_handle.close()
            except BaseException as exc:
                record('lane_handle_close',exc)
    try:
        run.emergency_receipt('cleanup.json',cleanup)
    except BaseException as exc:
        record('cleanup_receipt',exc)


def execute(check, root, batch_id):
    require(not any(name.startswith(('dcc_mcp_gimp','dcc_mcp_core')) for name in sys.modules),
            'Adapter/Core must not be preimported before source-bound execution')
    import psutil
    require(os.environ.get('DISPLAY'), 'A working ordinary DISPLAY is required; no headless fallback')
    root = no_symlinks(root)
    require(root.parent.is_dir() and re.fullmatch(r'[A-Za-z][A-Za-z0-9_.-]{0,95}', root.name), 'Invalid fresh run-root parent/name')
    require(not root.exists() and not root.is_symlink(), 'Run root must be new')
    require(shutil.disk_usage(root.parent).free > FREE_FLOOR + BUDGET, 'Insufficient admission reserve')
    lock_handle = (root.parent / 'gimp-native-lane.lock').open('a')
    fcntl.flock(lock_handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
    live_hosts = []
    for proc in psutil.process_iter(['pid', 'name']):
        if (proc.info['name'] or '').lower() in ('gimp', 'gimp-3.0', 'paraview', 'godot', 'godot4'):
            live_hosts.append(proc.info)
    require(not live_hosts, 'Serial GUI admission found a running native host; parent must resolve lane ownership')
    root.mkdir()
    for name in ('profile', 'config', 'cache', 'data-home', 'tmp', 'logs', 'registry', 'checkpoints'):
        (root / name).mkdir()
    for name in ('brushes', 'dynamics', 'fonts', 'gradients', 'palettes', 'patterns', 'plug-ins', 'scripts', 'tool-presets'):
        (root / 'profile' / name).mkdir()
    plugin = root / 'profile/plug-ins/dcc-mcp-gimp/dcc-mcp-gimp.py'
    plugin.parent.mkdir()
    shutil.copyfile(check['plugin'], plugin)
    plugin.chmod(0o755)
    require(sha(plugin) == PLUGIN_SHA, 'Staged candidate plugin mismatch')
    cpus = sorted(os.sched_getaffinity(0))[:2]
    require(len(cpus) == 2, 'Two allowed CPUs required')
    os.sched_setaffinity(0, cpus)
    bridge_port = unused_loopback_port()
    token = secrets.token_urlsafe(48)  # Ephemeral memory/environment only; never a file/argument/trace.
    os.environ.pop('DCC_MCP_GIMP_BRIDGE_TOKEN_FILE', None)
    os.environ.pop('PYTHONPATH', None)
    os.environ.pop('PYTHONHOME', None)
    os.environ.update({
        'DCC_MCP_GIMP_BRIDGE_TOKEN': token, 'DCC_MCP_GIMP_BRIDGE_HOST': '127.0.0.1',
        'DCC_MCP_GIMP_BRIDGE_PORT': str(bridge_port), 'DCC_MCP_GIMP_BRIDGE_TIMEOUT': '120',
        'DCC_MCP_GIMP_ALLOWED_ROOTS': str(root), 'GIMP3_DIRECTORY': str(root / 'profile'),
        'DCC_MCP_GATEWAY_PORT': '0', 'DCC_MCP_DISABLE_DEFAULT_SKILL_PATHS': '1',
        'DCC_MCP_DISABLE_TELEMETRY': '1', 'DCC_MCP_LOG_DIR': str(root / 'logs'),
        'DCC_MCP_JOB_STORAGE_PATH': str(root / 'jobs.sqlite'), 'DCC_MCP_CHECKPOINT_DIR': str(root / 'checkpoints'),
        'DCC_MCP_REGISTRY_DIR': str(root / 'registry'), 'DCC_MCP_GIMP_BOOTSTRAP_ERRORS': str(root / 'bootstrap-errors.jsonl'),
        'TMPDIR': str(root / 'tmp'), 'XDG_CONFIG_HOME': str(root / 'config'),
        'XDG_CACHE_HOME': str(root / 'cache'), 'XDG_DATA_HOME': str(root / 'data-home'),
        'OMP_NUM_THREADS': '2', 'GEGL_THREADS': '2', 'OPENBLAS_NUM_THREADS': '2',
        'VTK_SMP_MAX_THREADS': '2', 'PYTHONDONTWRITEBYTECODE': '1',
        'PATH': '/usr/bin:/bin:' + os.environ.get('PATH', '')})
    # All adapter/Core imports follow explicit task-local environment setup.
    # -B prevents writes, not reads. Use a fresh empty lookup prefix so
    # validated adapter/Core imports cannot load the frozen environment's caches.
    fresh_cache_prefix = root / 'unused-bytecode-cache'
    require(not fresh_cache_prefix.exists() and not fresh_cache_prefix.is_symlink(), 'Bytecode lookup prefix must be fresh')
    sys.pycache_prefix = str(fresh_cache_prefix)
    sys.dont_write_bytecode = True
    run = PilotRun(root, token)
    run.package_root = check['package']
    plan=json.loads((PREP/'batch-plan.json').read_text())
    batch=next(row for row in plan['batches'] if row['id']==batch_id)
    run.batch_id=batch_id
    run.asset_ids=tuple(batch['asset_ids'])
    run.privacy_markers = (str(root), str(PREP), str(sys.prefix), str(PREP), str(check['package']))
    run.ports.add(bridge_port)
    result, error, host_identity = None, None, None
    log_thread = None
    guard = threading.Thread(target=run.watch, daemon=True, name='owned-budget-watch')
    previous_handlers = {sig: signal.getsignal(sig) for sig in (signal.SIGINT, signal.SIGTERM)}
    for sig in previous_handlers:
        signal.signal(sig, lambda signum, frame: run.halt('Operator signal ' + str(signum)))
    try:
        from dcc_mcp_gimp.bridge import GimpBridge
        from dcc_mcp_gimp.server import GimpMcpServer
        run.write('launch.json', {**check, 'root': str(root), 'cpu_affinity': cpus, 'host_executable': '/usr/bin/gimp',
                  'host_binary_sha256': sha('/usr/bin/gimp'), 'profile_selector': str(root / 'profile'),
                  'allowed_roots': [str(root)], 'ephemeral_token_policy': 'Environment/in-memory only; no token file, argv or logs',
                  'aggregate_stopping_budget_bytes': BUDGET, 'minimum_free_bytes': FREE_FLOOR, 'deadline_seconds': DEADLINE})
        run.write('package-binding.json', check)
        run.write('admitted-batch.json',batch)
        run.host = subprocess.Popen(['/usr/bin/gimp', '--new-instance', '--no-splash', '--console-messages'],
                                    cwd=root, env=dict(os.environ), stdin=subprocess.DEVNULL,
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True)
        host_identity = {'pid': run.host.pid, 'created': psutil.Process(run.host.pid).create_time(), 'owned_process_group': os.getpgid(run.host.pid)}
        run.write('owned-host.json', host_identity)
        log_thread = threading.Thread(target=run.collect_log, daemon=True, name='owned-native-log')
        log_thread.start()
        guard.start()
        bridge = GimpBridge(host='127.0.0.1', port=bridge_port, token=token, timeout=1)
        ready_deadline = time.monotonic() + 75
        status = None
        while time.monotonic() < ready_deadline:
            run.budget()
            require(run.host.poll() is None, 'Owned GIMP exited during startup; inspect native.log')
            run.bridge_attempts += 1
            try:
                status = bridge.call('gimp.get_status')
                break
            except Exception:
                time.sleep(0.5)
        require(isinstance(status, dict), 'Owned GIMP bridge did not become ready in 75 seconds')
        require(status.get('ready') is True and status.get('authenticated') is True and status.get('gimp_version') == '3.0.4', 'Native readiness/version/auth mismatch')
        require(status.get('gimp_pid') == run.host.pid and status.get('bridge_host') == '127.0.0.1' and status.get('bridge_port') == bridge_port, 'Native ownership/loopback mismatch')
        require(status.get('allowed_roots') == [str(root)] and status.get('plugin_module_path') == str(plugin), 'Native profile/plugin/root mismatch')
        require(type(status.get('main_thread_id')) is int and status.get('arbitrary_script_input') is False, 'Main-thread/typed native status unavailable')
        plugin_process = psutil.Process(status['plugin_pid'])
        require(plugin_process.ppid() == run.host.pid, 'Plugin is not child of owned host')
        run.plugin_identity = {'pid': plugin_process.pid, 'created': plugin_process.create_time()}
        listeners = [c for c in plugin_process.net_connections(kind='inet') if c.status == psutil.CONN_LISTEN and c.laddr.port == bridge_port]
        require(len(listeners) == 1 and listeners[0].laddr.ip == '127.0.0.1', 'Actual bridge listener is not owned loopback')
        run.write('native-status.json', status)
        run.server = GimpMcpServer(port=0, gateway_port=0, enable_gateway_failover=False,
                                   registry_dir=str(root / 'registry'), enable_file_logging=True,
                                   enable_job_persistence=True, enable_telemetry=False, enable_checkpoint_persistence=True,
                                   checkpoint_path=str(root / 'checkpoints/checkpoints.json'))
        require(run.server._options.gateway.port == 0 and run.server._options.gateway.enable_failover is False, 'Gateway/failover not disabled')
        require(run.server._options.observability.enable_checkpoint_persistence is True
                and run.server._options.observability.checkpoint_path == str(root / 'checkpoints/checkpoints.json'),
                'Checkpoint persistence is not explicitly task-local')
        run.write('resolved-options.json', asdict(run.server._options))
        run.server.register_builtin_actions()
        run.server.start(install_atexit_hook=False)
        endpoint = urlsplit(run.server.mcp_url)
        require(endpoint.hostname in ('127.0.0.1', 'localhost') and endpoint.port is not None, 'MCP endpoint is not loopback')
        run.ports.add(endpoint.port)
        current_listeners = [c for c in psutil.Process().net_connections(kind='inet') if c.status == psutil.CONN_LISTEN and c.laddr.port == endpoint.port]
        require(len(current_listeners) == 1 and current_listeners[0].laddr.ip in ('127.0.0.1', '::1'), 'Actual MCP listener is not owned loopback')
        result = asyncio.run(asyncio.wait_for(workflow(run, status), timeout=DEADLINE - (time.monotonic() - run.started)))
    except BaseException as exc:
        error = {'type': type(exc).__name__, 'message': run.clean(str(exc))[:1024],
                 'exception_tree': exception_tree(exc, run.clean), 'mutations_replayed': False}
        run.emergency_receipt('failure.json', error)
    finally:
        cleanup = {'owned_sigterm_requested': False, 'force_kill_used': False,
                   'server_stopped': False, 'host_exited': run.host is None}
        try:
            cleanup['owned_host_start_provenance'] = host_identity
            cleanup['owned_plugin_start_provenance'] = run.plugin_identity
            if run.host is not None:
                if run.host.poll() is None:
                    run.host.terminate()
                    cleanup['owned_sigterm_requested'] = True
                try:
                    run.host.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    cleanup['normal_sigterm_wait_timed_out'] = True
                    cleanup['remaining_owned_host_pid'] = run.host.pid
                    cleanup['remaining_owned_host_start_provenance'] = host_identity
                    cleanup['required_action'] = 'Parent must inspect the retained owned process; no force-kill or alternate route attempted'
                cleanup['host_returncode'] = run.host.returncode
                cleanup['host_exited'] = run.host.poll() is not None
            # Stop Core after the host wait so an in-flight bridge request can unblock.
            # Bound the stop observation and preserve any uncertain shutdown result.
            if run.server is not None:
                def stop_server():
                    try:
                        run.server.stop()
                        cleanup['server_stopped'] = not run.server.is_running
                    except BaseException as exc:
                        cleanup['server_stop_error'] = run.clean(str(exc))
                stop_thread = threading.Thread(target=stop_server, daemon=True, name='owned-core-stop')
                stop_thread.start()
                stop_thread.join(timeout=15)
                if stop_thread.is_alive():
                    cleanup['core_stop_observation_timed_out'] = True
            else:
                cleanup['server_stopped'] = True
            deadline = time.monotonic() + 10
            while True:
                active_plugin = False
                if run.plugin_identity is not None:
                    try:
                        p = psutil.Process(run.plugin_identity['pid'])
                        if p.create_time() == run.plugin_identity['created']:
                            cleanup['plugin_status'] = p.status()
                            active_plugin = p.status() != psutil.STATUS_ZOMBIE
                    except psutil.NoSuchProcess:
                        cleanup['plugin_status'] = 'absent'
                cleanup['owned_plugin_exited'] = not active_plugin
                cleanup['listeners_closed'] = all(port_closed(port) for port in run.ports)
                if cleanup['owned_plugin_exited'] and cleanup['listeners_closed'] or time.monotonic() > deadline:
                    break
                time.sleep(0.2)
            if log_thread is not None:
                log_thread.join(timeout=2)
            run.guard_done.set()
            if guard.ident is not None:
                guard.join(timeout=2)
            cleanup['native_log_collector_stopped'] = log_thread is None or not log_thread.is_alive()
            cleanup['normal_owned_shutdown_pass'] = all(cleanup.get(k) is True for k in ('server_stopped', 'host_exited', 'owned_plugin_exited', 'listeners_closed', 'native_log_collector_stopped'))
            cleanup['shutdown_method'] = 'Owned Popen SIGTERM then bounded wait; not an unexposed GIMP quit tool'
        except BaseException as exc:
            cleanup['normal_owned_shutdown_pass']=False
            cleanup['cleanup_exception']=exception_tree(exc,run.clean)
        finally:
            finalize_cleanup(run,cleanup,previous_handlers,lock_handle)
    if result is not None and cleanup['normal_owned_shutdown_pass'] and error is None and not run.halt_reason:
        require(run.usage() < BUDGET and shutil.disk_usage(root).free > FREE_FLOOR, 'Final budget gate failed')
        result['cleanup'] = cleanup
        result['full_D058_acceptance'] = False
        result['package_binding'] = check['package_integrity']
        artifact_paths = [root / name for name in result['artifact_names']]
        artifact_paths.extend(root / row['path'] for row in result['preclose_checkpoint_artifacts'])
        result['artifacts'] = [{'path': p.name, 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in artifact_paths]
        run.write('qualification.json', result)
        print(json.dumps({'run_root': str(root), 'status': result['status'], 'native_asset_ids': result['native_asset_ids'], 'full_D058_acceptance': False, 'MCP_events': run.events}), flush=True)
        return 0
    brief_error = None if error is None else {key: error[key] for key in ('type', 'message', 'mutations_replayed')}
    print(json.dumps({'run_root': str(root), 'status': 'FAIL_OR_BLOCKED_NO_NATIVE_PASS_CLAIM',
                      'error': brief_error, 'private_failure_receipt': str(root / 'failure.json'), 'cleanup': cleanup}), flush=True)
    return 1



def main():
    parser=argparse.ArgumentParser(description=__doc__)
    mode=parser.add_mutually_exclusive_group()
    mode.add_argument('--check',action='store_true',help='File-only check; default')
    mode.add_argument('--run',action='store_true',help='Parent-reviewed serial native pilot')
    parser.add_argument('--run-root',type=Path)
    parser.add_argument('--batch',choices=['envelopes','stamp-and-dispatch','arrival-and-parcel','delivery-status'],
                        default='envelopes',help='One reviewed batch per fresh native run')
    parser.add_argument('--adapter-source',type=Path,required=True,help='Exact reviewed adapter source directory')
    parser.add_argument('--adapter-wheel',type=Path,required=True,help='Exact reviewed adapter wheel file')
    parser.add_argument('--adapter-binding',type=Path,required=True,help='Reviewed allowlisted adapter-only binding JSON')
    args=parser.parse_args()
    check=check_all(args.adapter_source,args.adapter_wheel,args.adapter_binding)
    if not args.run:
        print(json.dumps(check,indent=2)); return 0
    require(args.run_root is not None, '--run-root must be a new output directory')
    return execute(check,no_symlinks(args.run_root),args.batch)


if __name__=='__main__':
    raise SystemExit(main())
