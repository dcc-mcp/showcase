#!/usr/bin/env python3
"""File-only selected-evidence tests; supply retained originals with --inputs.

No historical path defaults. Generic rejection tests run without private inputs;
the actual-source suite is skipped unless the operator supplies its inventory.
"""
import argparse
import copy
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest import mock
import normalize_selected_evidence as n

ROOT = Path(__file__).resolve().parent
INPUTS = None
PUBLIC = None
CROSSWALK = None


def independent_module():
    spec = importlib.util.spec_from_file_location('independent_reconstruction', ROOT/'evidence-normalization/reconstruct_selected_evidence.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class PureRejections(unittest.TestCase):
    def test_unknown_fields_rejected(self):
        with self.assertRaises(n.EvidenceError):
            n.exact_keys({'known': 1, 'surprise': 2}, {'known'})

    def test_private_paths_and_uuid_rejected(self):
        for value in ('/workspace/private/file', 'label /home/person/file', 'C:\\private\\file', 'file:///home/private', 'job 01234567-89ab-cdef-0123-456789abcdef', '127.0.0.1:9988'):
            with self.subTest(value=value), self.assertRaises(n.EvidenceError):
                n.public_safe({'name': value})

    def test_alias_lookup_is_not_implicit(self):
        alias = n.Aliases('run-01')
        with self.assertRaises(n.EvidenceError):
            alias.use('layer', 77)
        self.assertEqual(alias.use('image', 12, True), 'run-01.image-001')
        self.assertEqual(alias.use('image', 19, True), 'run-01.image-002')
        alias.use('layer', 77, True, 12)
        with self.assertRaises(n.EvidenceError):
            alias.use('layer', 77, owner=19)

    def test_duplicate_keys_and_nonfinite_rejected(self):
        for data in ('{"x":1,"x":2}', '{"x":NaN}', '{"x":Infinity}'):
            with self.subTest(data=data), self.assertRaises(n.EvidenceError):
                n.parse(data)

    def test_native_context_and_active_wrapper(self):
        wrapped = {'success': True, 'message': 'ready', 'context': {'image': {'image_id': 4}}}
        self.assertEqual(n.native_context(wrapped)['image']['image_id'], 4)
        with self.assertRaises(n.EvidenceError):
            n.native_context({'success': True, 'context': {}, 'private_path': '/private/foo'})


class RetainedEvidence(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if INPUTS is None:
            raise unittest.SkipTest('actual retained evidence requires explicit --inputs')
        cls.config = n.read_json(INPUTS)
        cls.records, cls.results, cls.crosswalk = n.build(cls.config)
        cls.source_run = cls.config['runs'][0]
        cls.root = Path(cls.source_run['directory'])
        cls.trace = n.parse_trace(cls.root/'mcp-trace.jsonl')
        cls.asset = cls.source_run['assets'][0]['asset_id']
        master = next(c for c in cls.trace['calls'] if c['request']['tool']=='save_image' and c['request']['arguments']['path'] == str(cls.root/(cls.asset+'.xcf')))
        cls.main = master['request']['arguments']['image_id']
        cls.create = next(c for c in cls.trace['calls'] if c['request']['tool']=='create_image' and n.resolve(c, cls.trace)['context']['image_id']==cls.main)
        cls.paint = next(c for c in cls.trace['calls'] if c['request']['tool']=='paint_shape' and c['request']['arguments']['image_id']==cls.main)
        cls.save = master
        cls.work = tempfile.TemporaryDirectory(prefix='selected-evidence-test-', dir=ROOT/'private-evidence')
        cls.work_root = Path(cls.work.name)
        cls.public = cls.work_root/'public'
        cls.private = cls.work_root/'private'
        cls.public.mkdir()
        cls.private.mkdir()
        for name, data in n.output_bytes(cls.records, cls.results).items():
            (cls.public/name).write_bytes(data)
        cls.crosswalk_file = cls.private/'source-crosswalk.json'
        cls.crosswalk_file.write_bytes(n.canon(cls.crosswalk)+b'\n')

    @classmethod
    def tearDownClass(cls):
        cls.work.cleanup()

    def test_actual_final_eight_162_exact_operations(self):
        self.assertEqual(self.results['creative_operation_count'], 162)
        self.assertEqual(self.results['creative_counts_by_component'], {'sealed-envelope':23, 'open-envelope':25, 'orbital-stamp':19, 'dispatch-arrow':15, 'arrival-beacon':21, 'priority-parcel':21, 'accepted-seal':17, 'return-seal':21})
        self.assertEqual(self.results['selected_record_count'], 784)
        self.assertEqual(self.results['selected_tool_counts']['create_image'], 8)
        self.assertEqual(self.results['selected_tool_counts']['create_layer'], 76)
        self.assertEqual(self.results['selected_tool_counts']['paint_shape'], 76)
        self.assertEqual(self.results['selected_tool_counts']['create_text'], 2)

    def test_actual_font_and_failed_batch_component(self):
        text = [r for r in self.records if r['tool']=='create_text']
        self.assertEqual([r['arguments']['text'] for r in text], ['07','OP'])
        for r in text:
            self.assertEqual(r['arguments']['font'], 'DejaVu Sans Book')
            self.assertEqual(r['arguments']['size'], 27)
        sealed = next(c for c in self.results['components'] if c['asset_id']=='sealed-envelope')
        self.assertEqual(sealed['batch_state'], 'failed-font-gate')
        self.assertEqual(sealed['component_state'], 'accepted-source-component')
        stamp = next(c for c in self.results['components'] if c['asset_id']=='orbital-stamp')
        self.assertEqual(len(stamp['native_text_payloads_matched_saved_xcf']), 2)
        self.assertEqual(stamp['png_readback']['semitransparent_count'], 0)

    def test_actual_public_privacy_and_readback_scope(self):
        n.public_safe(self.records)
        n.public_safe(self.results)
        for component in self.results['components']:
            self.assertEqual(component['native_reopen_count'], 3)
            self.assertEqual(len(component['artifacts']), 16)
            self.assertEqual(len(component['preview_state_checks']), 6)
            self.assertFalse(component['independent_selection_mask_readback_available'])
        self.assertIn('full raw trace publication', self.results['limits'])

    def test_actual_independent_inverse_reconstruction(self):
        result = independent_module().check(self.public, self.crosswalk_file)
        self.assertEqual(result['creative_calls'], 162)
        self.assertEqual(result['native_artifact_hashes_checked'], 128)

    def test_actual_fresh_regeneration_from_originals(self):
        result = n.verify_reconstruction(INPUTS, self.public, self.crosswalk_file)
        self.assertEqual(result['selected_records'], 784)

    def test_actual_unpaired_call_rejected(self):
        p = self.work_root/'unpaired.jsonl'
        p.write_bytes(self.trace['lines'][self.create['request_line']-1])
        with self.assertRaisesRegex(n.EvidenceError, 'unpaired'):
            n.parse_trace(p)

    def test_actual_request_response_mismatch_rejected(self):
        p = self.work_root/'mismatched.jsonl'
        response = copy.deepcopy(self.create['response'])
        response['arguments']['width'] += 1
        p.write_bytes(n.canon(self.create['request'])+b'\n'+n.canon(response)+b'\n')
        with self.assertRaisesRegex(n.EvidenceError, 'identity mismatch'):
            n.parse_trace(p)

    def test_actual_missing_failed_and_incomplete_jobs_rejected(self):
        jid = n.resolve(self.create, self.trace)['job_id']
        for condition in ('missing', 'failed', 'incomplete'):
            trace = dict(self.trace, jobs=copy.deepcopy(self.trace['jobs']))
            if condition == 'missing':
                trace['jobs'].pop(jid)
            elif condition == 'failed':
                trace['jobs'][jid][-1][1]['status'] = 'failed'
            else:
                trace['jobs'][jid][-1][1]['status'] = 'running'
            with self.subTest(condition=condition), self.assertRaises(n.EvidenceError):
                n.resolve(self.create, trace)

    def test_actual_wrong_job_tool_and_identity_rejected(self):
        jid = n.resolve(self.create, self.trace)['job_id']
        for field, value in (('tool','gimp_session__paint_shape'), ('core_job_id','01234567-89ab-cdef-0123-456789abcdef')):
            trace = dict(self.trace, jobs=copy.deepcopy(self.trace['jobs']))
            trace['jobs'][jid][-1][1][field] = value
            with self.subTest(field=field), self.assertRaises(n.EvidenceError):
                n.resolve(self.create, trace)

    def test_actual_unknown_argument_and_private_name_rejected(self):
        original = n.resolve(self.create, self.trace)
        for key, value in (('surprise',True), ('name','/home/private/person/file')):
            call = copy.deepcopy(self.create)
            call['request']['arguments'][key] = value
            with self.subTest(key=key), self.assertRaises(n.EvidenceError):
                n.normalized_call(call, original, n.Aliases(self.source_run['run_id']), self.root, self.asset, self.main)

    def test_unallowlisted_selected_tool_rejected(self):
        call = copy.deepcopy(self.create)
        call['request']['tool'] = 'execute_arbitrary_script'
        with self.assertRaisesRegex(n.EvidenceError, 'unallowlisted selected tool'):
            n.normalized_call(call, n.resolve(self.create, self.trace), n.Aliases(self.source_run['run_id']), self.root, self.asset, self.main)

    def test_actual_unknown_result_field_rejected(self):
        complete = copy.deepcopy(n.resolve(self.create, self.trace))
        complete['context']['unexpected'] = 'private data'
        with self.assertRaisesRegex(n.EvidenceError, 'unknown/unallowlisted'):
            n.normalized_call(self.create, complete, n.Aliases(self.source_run['run_id']), self.root, self.asset, self.main)

    def test_actual_wrong_layer_result_identity_rejected(self):
        complete = copy.deepcopy(n.resolve(self.paint, self.trace))
        aliases = n.Aliases(self.source_run['run_id'])
        aliases.use('image', self.main, True)
        aliases.use('layer', self.paint['request']['arguments']['layer_id'], True, self.main)
        complete['context']['layer_id'] += 1
        with self.assertRaisesRegex(n.EvidenceError, 'wrong native layer'):
            n.normalized_call(self.paint, complete, aliases, self.root, self.asset, self.main)

    def test_actual_unsafe_output_and_wrong_component_rejected(self):
        for value in (str(self.root/'..'/(self.asset+'.xcf')), '/tmp/'+self.asset+'.xcf', str(self.root/'wrong-component.xcf')):
            with self.subTest(path=value), self.assertRaises(n.EvidenceError):
                n.component_filename(value, self.root, self.asset)

    def test_actual_metadata_unknown_field_rejected(self):
        inspect = next(c for c in self.trace['calls'] if c['request']['tool']=='inspect_image' and c['request']['arguments']['image_id']==self.main)
        metadata = copy.deepcopy(n.resolve(inspect, self.trace)['context']['metadata'])
        metadata['private_surprise'] = '/home/private'
        with self.assertRaisesRegex(n.EvidenceError, 'unknown/unallowlisted'):
            n.validate_metadata(metadata)

    def test_actual_wrong_artifact_mapping_rejected(self):
        config = copy.deepcopy(self.config)
        config['runs'][0]['assets'][0]['artifacts'][0]['sha256'] = '0'*64
        with self.assertRaisesRegex(n.EvidenceError, 'wrong accepted component artifact identity'):
            n.build(config)

    def test_actual_published_argument_and_result_tamper_rejected(self):
        checker = independent_module()
        target = self.work_root/'tampered-public'
        target.mkdir(exist_ok=True)
        for name, data in n.output_bytes(self.records, self.results).items():
            (target/name).write_bytes(data)
        for part in ('arguments', 'result'):
            modified = copy.deepcopy(self.records)
            idx = next(i for i, r in enumerate(modified) if r['tool']=='paint_shape')
            if part == 'arguments': modified[idx][part]['color'][0] += 1
            else: modified[idx][part]['painted'] = False
            (target/'selected-operations.jsonl').write_bytes(b''.join(n.canon(r)+b'\n' for r in modified))
            with self.subTest(part=part), self.assertRaises(ValueError):
                checker.check(target, self.crosswalk_file)

    def test_private_crosswalk_tamper_rejected(self):
        changed = copy.deepcopy(self.crosswalk)
        changed['records'][0]['source_lines'][0] += 2
        path = self.work_root/'wrong-crosswalk.json'
        path.write_bytes(n.canon(changed))
        with self.assertRaises(ValueError):
            independent_module().check(self.public, path)

    def test_output_directory_overlap_rejected_before_write(self):
        with mock.patch.object(n, 'build', return_value=(self.records,self.results,self.crosswalk)):
            forbidden = self.root/'not-created-by-test'
            with self.assertRaisesRegex(n.EvidenceError, 'overlaps retained run'):
                n.write_outputs(INPUTS, forbidden, self.private)
            self.assertFalse(forbidden.exists())
            with self.assertRaisesRegex(n.EvidenceError, 'nonnested'):
                n.write_outputs(INPUTS, self.public, self.public/'private')

    def test_explicit_generated_packet_if_supplied(self):
        if not PUBLIC or not CROSSWALK:
            self.skipTest('optional --public-dir and --crosswalk not supplied')
        self.assertEqual(independent_module().check(PUBLIC, CROSSWALK)['selected_records'], 784)
        self.assertEqual(n.verify_reconstruction(INPUTS, PUBLIC, CROSSWALK)['creative_calls'], 162)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs')
    parser.add_argument('--public-dir')
    parser.add_argument('--crosswalk')
    args, rest = parser.parse_known_args()
    INPUTS, PUBLIC, CROSSWALK = args.inputs, args.public_dir, args.crosswalk
    unittest.main(argv=[__file__, *rest], verbosity=2)
