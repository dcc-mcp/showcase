"""Host-free rejection tests; positive all-eight closure requires real native runs."""
import json
import copy
import tempfile
import unittest
from pathlib import Path

from verify_kit_runs import (PREP, component_artifact_names, require_component_inventory,
                            reviewed_adapter_identity, verify_composite, verify_preview,
                            verify_runs, verify_structure)


class KitClosureTests(unittest.TestCase):
    def setUp(self):
        temporary=tempfile.TemporaryDirectory(prefix='d058-kit-closure-')
        self.addCleanup(temporary.cleanup)
        self.root=Path(temporary.name)

    def test_fewer_than_four_completed_batches_cannot_claim_full_reproduction(self):
        with self.assertRaisesRegex(RuntimeError,'exactly one explicit completed run'):
            verify_runs([self.root])

    def test_duplicate_run_paths_cannot_inflate_completion(self):
        with self.assertRaisesRegex(RuntimeError,'Duplicate run roots'):
            verify_runs([self.root]*4)

    def test_historical_component_batch_cannot_close_new_standalone_recipe(self):
        roots=[self.root/str(i) for i in range(4)]
        for root in roots:root.mkdir()
        (roots[0]/'qualification.json').write_text(json.dumps({
            'status':'PASS_BOUNDED_NATIVE_BATCH_VISUAL_REVIEW_REQUIRED','batch_id':'stamp-and-dispatch'}))
        with self.assertRaisesRegex(RuntimeError,'historical/partial/unqualified'):
            verify_runs(roots)

    def test_unknown_standalone_batch_cannot_replace_a_required_pair(self):
        roots=[self.root/str(i) for i in range(4)]
        for root in roots:root.mkdir()
        (roots[0]/'qualification.json').write_text(json.dumps({
            'status':'PASS_STANDALONE_NATIVE_BATCH_VISUAL_REVIEW_REQUIRED','batch_id':'invented'}))
        with self.assertRaisesRegex(RuntimeError,'Wrong or repeated batch identity'):
            verify_runs(roots)

    def test_missing_qa_file_cannot_pass_a_component_manifest(self):
        complete=component_artifact_names('sealed-envelope')
        self.assertEqual(len(complete),16)
        require_component_inventory('sealed-envelope',complete)
        for omitted in ('sealed-envelope-dark-64.png','sealed-envelope-light-composite.xcf',
                        'sealed-envelope-reopened.png'):
            with self.assertRaisesRegex(RuntimeError,'Required per-role'):
                require_component_inventory('sealed-envelope',complete-{omitted})

    def test_adapter_identity_is_checked_against_reviewed_allowlist(self):
        entry=json.loads((PREP/'reviewed-adapter-bindings.json').read_text())['bindings'][0]
        binding=json.loads((PREP/entry['filename']).read_text())
        run={'source_commit':entry['commit'],'source_tree':entry['tree'],'versions':binding['runtime_versions'],
             'matched_package_files':42,'package_integrity':{'source_files':69,
                'binding_sha256':entry['sha256'],'wheel_sha256':binding['wheel']['sha256']}}
        self.assertEqual(reviewed_adapter_identity(run)[0],entry['commit'])
        for key in ('source_commit','source_tree'):
            bad=copy.deepcopy(run);bad[key]='0'*40
            with self.assertRaisesRegex(RuntimeError,'identity differs'):
                reviewed_adapter_identity(bad)
        bad=copy.deepcopy(run);bad['package_integrity']['binding_sha256']='0'*64
        with self.assertRaisesRegex(RuntimeError,'reviewed allowlist'):
            reviewed_adapter_identity(bad)

    def test_reopen_structure_and_selection_are_recomputed_not_trusted_flags(self):
        reference=json.loads((PREP/'accepted-component-reference.json').read_text())['components'][0]
        saved=copy.deepcopy(reference['canonical_native_structure'])
        for number,row in enumerate(saved['layers'],1):
            row['layer_id']=number;row['parent_id']=None
        ids={row['name']:row['layer_id'] for row in saved['layers']}
        saved['selected_layer_ids']=[ids[name] for name in reference['selected_layer_names']]
        loaded=copy.deepcopy(saved);verify_structure(saved,loaded,reference)
        loaded['layers'][0]['opacity']=25
        with self.assertRaisesRegex(RuntimeError,'Recomputed native'):
            verify_structure(saved,loaded,reference)
        loaded=copy.deepcopy(saved);loaded['selected_layer_ids']=[]
        with self.assertRaisesRegex(RuntimeError,'selected layer names'):
            verify_structure(saved,loaded,reference)

    def test_preview_preservation_and_identity_are_required_not_just_size(self):
        facts={'dimensions':[128,128]}
        proof={'png_facts':facts,'source_before_after_equal':True,'selected_layers_equal':True,
               'native_text_and_metadata_equal':True,'active_image_id_before_after':5,
               'source_state_sha256':'a'*64}
        verify_preview(proof,facts,128)
        for change in ({'source_before_after_equal':False},{'selected_layers_equal':False},
                       {'native_text_and_metadata_equal':False},{'active_image_id_before_after':None},
                       {'active_image_id_before_after':True},{'source_state_sha256':None}):
            with self.assertRaises(RuntimeError):verify_preview({**proof,**change},facts,128)

    def test_composite_alpha_and_background_pixels_are_measured(self):
        color=[24,35,43,255];pixels=bytes(color)*(512*512)
        verify_composite((512,512,pixels),color)
        with self.assertRaisesRegex(RuntimeError,'composite opacity'):
            verify_composite((512,512,b'\0\0\0\0'+pixels[4:]),color)
        with self.assertRaisesRegex(RuntimeError,'background corner'):
            verify_composite((512,512,bytes([1,2,3,255])+pixels[4:]),color)


if __name__=='__main__':unittest.main()
