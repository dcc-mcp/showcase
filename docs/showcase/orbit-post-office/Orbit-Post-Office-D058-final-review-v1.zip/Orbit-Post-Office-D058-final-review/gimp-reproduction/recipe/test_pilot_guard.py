"""Host-free tests for schema rejection and native allocation stopping behavior."""
import asyncio
import builtins
import contextlib
import importlib.util
import io
import json
import os
import signal
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, Mock, patch

import jsonschema

from orbit_workflow import FONT_FACE, Native, active_image_id, select_font_face, verify_text_creation
from reproduce_orbit import PilotRun, execute, finalize_cleanup
from static_check import validate_inventory

ROOT=Path(__file__).resolve().parent


class PilotGuardTests(unittest.TestCase):
    def test_preimported_adapter_rejected_before_any_setup_mutation(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary)/'not-created'
            with patch.dict(sys.modules,{'dcc_mcp_core.preimported_test':object()}), \
                 patch.dict(os.environ,{'DCC_MCP_GIMP_BRIDGE_TOKEN':'PREEXISTING-TEST-TOKEN'}), \
                 patch('reproduce_orbit.subprocess.Popen') as launch:
                with self.assertRaisesRegex(RuntimeError,'must not be preimported'):
                    execute({},root,'envelopes')
                self.assertEqual(os.environ['DCC_MCP_GIMP_BRIDGE_TOKEN'],'PREEXISTING-TEST-TOKEN')
                self.assertFalse(root.exists());launch.assert_not_called()

    def test_import_failure_has_cleanup_receipt_and_no_native_launch(self):
        package=Path(importlib.util.find_spec('dcc_mcp_gimp').origin).parent
        check={'package':str(package),'plugin':str(package/'gimp_plugin/dcc_mcp_gimp.py')}
        original_import=builtins.__import__;old_prefix=sys.pycache_prefix
        def failed_import(name,*args,**kwargs):
            if name.startswith('dcc_mcp_gimp'):
                raise ImportError('CONTROLLED_IMPORT_FAILURE')
            return original_import(name,*args,**kwargs)
        self.addCleanup(setattr,sys,'pycache_prefix',old_prefix)
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary)/'import-fault'
            with patch.dict(os.environ,{'DISPLAY':':test'}), \
                 patch('psutil.process_iter',return_value=[]), \
                 patch('reproduce_orbit.os.sched_getaffinity',return_value={0,1}), \
                 patch('reproduce_orbit.os.sched_setaffinity'), \
                 patch('reproduce_orbit.unused_loopback_port',return_value=43123), \
                 patch('reproduce_orbit.port_closed',return_value=True), \
                 patch('reproduce_orbit.subprocess.Popen') as launch, \
                 patch('builtins.__import__',side_effect=failed_import), \
                 contextlib.redirect_stdout(io.StringIO()):
                result=execute(check,root,'envelopes')
                self.assertEqual(result,1)
                launch.assert_not_called()
                self.assertNotIn('DCC_MCP_GIMP_BRIDGE_TOKEN',os.environ)
            failure=json.loads((root/'failure.json').read_text())
            cleanup=json.loads((root/'cleanup.json').read_text())
            self.assertEqual(failure['message'],'CONTROLLED_IMPORT_FAILURE')
            self.assertIsNone(cleanup['owned_host_start_provenance'])
            self.assertTrue(cleanup['normal_owned_shutdown_pass'])
            self.assertTrue(cleanup['ephemeral_environment_token_removed'])

    def test_actual_completed_native_font_record_selects_explicit_book_face(self):
        evidence=json.loads((ROOT/'test-fixtures/observed-font-list.json').read_text())
        self.assertEqual(select_font_face(evidence),FONT_FACE)

    def test_font_selection_never_silently_aliases_family_or_other_style(self):
        for name in ('DejaVu Sans','DejaVu Sans Bold','DejaVu Sans Condensed','DejaVu Sans Mono Book'):
            with self.assertRaisesRegex(RuntimeError,'Explicit native regular face'):
                select_font_face({'result':{'context':{'fonts':[name],'match_count':1,'truncated':False}}})

    def test_truncated_ambiguous_or_malformed_font_inventory_is_not_missing_font(self):
        valid={'fonts':[FONT_FACE],'match_count':1,'truncated':False}
        for change in ({'truncated':True},{'match_count':2},{'match_count':True},
                       {'fonts':[FONT_FACE,FONT_FACE],'match_count':2},{'truncated':None}):
            with self.assertRaises(RuntimeError):
                select_font_face({'result':{'context':{**valid,**change}}})

    def test_missing_exact_font_stops_before_image_or_text_creation(self):
        native=Native(Mock(),Mock())
        native.complete=AsyncMock(return_value={'result':{'fonts':['DejaVu Sans Bold'],'match_count':1,'truncated':False}})
        asset=next(a for a in json.loads((ROOT/'design.json').read_text())['assets'] if a['id']=='orbital-stamp')
        with self.assertRaisesRegex(RuntimeError,'Explicit native regular face'):
            asyncio.run(native.asset(asset))
        native.complete.assert_awaited_once_with('list_fonts',{'query':'DejaVu Sans','limit':256})

    def test_native_font_discovery_precedes_first_image_mutation(self):
        native=Native(Mock(),Mock())
        native.complete=AsyncMock(side_effect=[{'result':{'fonts':[FONT_FACE],'match_count':1,'truncated':False}},RuntimeError('bounded test stop')])
        asset=next(a for a in json.loads((ROOT/'design.json').read_text())['assets'] if a['id']=='orbital-stamp')
        with self.assertRaisesRegex(RuntimeError,'bounded test stop'):
            asyncio.run(native.asset(asset))
        self.assertEqual([row.args[0] for row in native.complete.await_args_list],['list_fonts','create_image'])

    def test_text_result_requires_editable_exact_content_font_and_size(self):
        args={'text':'07','size':27}
        valid={'is_text':True,'text':'07','font':FONT_FACE,'font_size':27}
        verify_text_creation({'result':valid},args,FONT_FACE)
        for change in ({'is_text':False},{'text':'OP'},{'font':'fallback'},{'font_size':26}):
            with self.assertRaisesRegex(RuntimeError,'Native editable text creation differs'):
                verify_text_creation({'result':{**valid,**change}},args,FONT_FACE)

    def test_cleanup_metrics_and_receipt_failure_still_release_state(self):
        with tempfile.TemporaryDirectory() as temporary:
            run=PilotRun(Path(temporary),'TEST-ONLY-EPHEMERAL')
            run.usage=Mock(side_effect=RuntimeError('Unexpected symlink in owned run root'))
            run.emergency_receipt=Mock(side_effect=OSError('Cannot write receipt'))
            lock=Mock(); cleanup={'normal_owned_shutdown_pass':True}
            with patch.dict(os.environ,{'DCC_MCP_GIMP_BRIDGE_TOKEN':'TEST-ONLY-EPHEMERAL'}):
                with patch('reproduce_orbit.signal.signal') as restore, patch('reproduce_orbit.fcntl.flock') as unlock:
                    finalize_cleanup(run,cleanup,{signal.SIGTERM:signal.SIG_DFL},lock)
                    restore.assert_called_once_with(signal.SIGTERM,signal.SIG_DFL)
                    unlock.assert_called_once()
                    lock.close.assert_called_once()
                    self.assertNotIn('DCC_MCP_GIMP_BRIDGE_TOKEN',os.environ)
            self.assertTrue(run.guard_done.is_set())
            self.assertFalse(cleanup['normal_owned_shutdown_pass'])
            self.assertEqual([row['stage'] for row in cleanup['cleanup_errors']],
                             ['cleanup_metrics','cleanup_receipt'])

    def test_actual_active_image_wrapper_cannot_false_pass_as_none(self):
        self.assertEqual(active_image_id({'result':{'data':{'image':{'image_id':71}}}}),71)
        for value in ({'image_id':71},{'image':None},{'image':{'image_id':None}},
                      {'image':{'image_id':True}},{'image':{'image_id':0}}):
            with self.assertRaisesRegex(RuntimeError,'Active native image ID'):
                active_image_id(value)

    def test_allof_rejection_occurs_before_dispatch(self):
        runtime=json.loads((ROOT/'observed-native-schemas.json').read_text())['paint_shape']
        source={**runtime,'allOf':[{'if':{'properties':{'shape':{'const':'polygon'}}},
                                   'then':{'required':['points']},'else':{'required':['bounds']}}]}
        run=Mock(); session=Mock()
        native=Native(run,session)
        native.catalog={'paint_shape':{'inputSchema':runtime}}
        native.source_schemas={'paint_shape':source}
        with self.assertRaises(jsonschema.ValidationError):
            asyncio.run(native.call('paint_shape',{'image_id':1,'layer_id':1,
                        'shape':'polygon','color':[0,0,0,255],'bounds':[0,0,8,8]}))
        session.call_tool.assert_not_called()
        run.trace.assert_not_called()

    def test_native_allocation_message_stops_only_owned_host(self):
        with tempfile.TemporaryDirectory() as temporary:
            run=PilotRun(Path(temporary),'TEST-ONLY-EPHEMERAL')
            run.host=Mock(); run.host.poll.return_value=None
            (run.root/'native.log').write_text('GEGL failed to allocate 4194304 bytes\n')
            with self.assertRaisesRegex(RuntimeError,'Native allocation error'):
                run.budget()
            run.host.terminate.assert_called_once_with()
            run.host.kill.assert_not_called()
            self.assertTrue(run.stop.is_set())

    def test_allocation_phrase_across_log_appends_is_detected(self):
        with tempfile.TemporaryDirectory() as temporary:
            run=PilotRun(Path(temporary),'TEST-ONLY-EPHEMERAL')
            log=run.root/'native.log'
            log.write_text('GIMP native renderer started\nfailed to allo')
            run.budget()
            with log.open('a') as stream:
                stream.write('cate buffer\n')
            with self.assertRaisesRegex(RuntimeError,'Native allocation error'):
                run.budget()
            self.assertIsNone(run.host)

    def test_actual_pinned_inventory_retains_expected_rejections(self):
        import importlib.util
        candidate=Path(importlib.util.find_spec('dcc_mcp_gimp').origin).parent
        inventory=validate_inventory(candidate)
        self.assertEqual(inventory['pilot_authoring_operations'],48)
        self.assertEqual(inventory['all_asset_authoring_operations'],162)
        self.assertEqual(len(inventory['invalid_shape_expected_rejections']),2)
        self.assertTrue(all(row['source_rejected'] for row in inventory['invalid_shape_expected_rejections']))


if __name__=='__main__':
    unittest.main()
