# Artwork and font scope

Orbit Post Office is one original eight-icon fictional postal UI kit. Original
artwork rights are reserved. No MIT, CC0 or additional artwork license is granted.

Only the orbital stamp uses the explicitly discovered DejaVu Sans Book face for
its two native editable text layers. `DejaVu-font-notice.txt` is the scoped upstream
distribution notice; no font binary is bundled. Font/software licenses do not
license the original artwork. Other icons contain no font glyphs.

Adapter and copied helper software retain their existing upstream rights. Source
and helper origins are recorded in the separate hash/provenance manifests.
