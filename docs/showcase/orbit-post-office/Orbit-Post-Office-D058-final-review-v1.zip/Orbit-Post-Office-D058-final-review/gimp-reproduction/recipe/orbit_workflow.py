"""Bounded D058 continuation batches. Geometry is typed paint_shape caller input."""
import asyncio
import json
import re
import time
from pathlib import Path

from lifecycle import (canonical_image, field, has_failure, image_from_result,
                       require, sha, unwrap)
from png_readback import decode_png, rgba_sha
from orbit_readback import assert_asset_png, png_facts, verify_text_saved

PREP = Path(__file__).resolve().parent
PILOT_IDS = ('sealed-envelope', 'open-envelope')
FONT_FAMILY = 'DejaVu Sans'
FONT_FACE = 'DejaVu Sans Book'
BACKGROUNDS = {'dark': [24, 35, 43, 255], 'light': [247, 244, 234, 255]}


def authoring_operations(asset, image_id=1):
    """Same input compiler is used by file-only schema checks and native calls."""
    operations = [('create_image', {'width':512, 'height':512,
                   'name':'transparent substrate', 'background_color':[0,0,0,0]})]
    for layer in asset['layers_bottom_to_top']:
        operations.append(('create_layer', {'image_id':image_id, 'name':layer['name']}))
        operations.append(('paint_shape', {'image_id':image_id, 'layer_id':1,
                           **{k:v for k,v in layer.items() if k != 'name'}}))
    for text in asset['editable_text']:
        operations.append(('create_text', {'image_id':image_id, 'font':FONT_FACE, **text}))
    return operations


def pixel(decoded, x, y):
    width, height, rgba = decoded
    require(0 <= x < width and 0 <= y < height, 'Fixture sample outside bounds')
    i = (y * width + x) * 4
    return list(rgba[i:i+4])


def near(actual, expected, tolerance=1):
    return len(actual) == len(expected) and all(abs(a-b) <= tolerance for a,b in zip(actual,expected))


def difference(before, after):
    return {key:{'before':before.get(key),'after':after.get(key)}
            for key in sorted(set(before) | set(after)) if before.get(key) != after.get(key)}


def selected_names(info):
    names={row['layer_id']:row['name'] for row in info['layers']}
    require(all(layer_id in names for layer_id in info['selected_layer_ids']),
            'Selected native layer missing from layer inventory')
    return [names[layer_id] for layer_id in info['selected_layer_ids']]


def active_image_id(result):
    """get_active_image deliberately wraps native image info under 'image'."""
    image=field(result,'image')
    require(isinstance(image,dict) and type(image.get('image_id')) is int
            and image['image_id']>0, 'Active native image ID is missing or incorrectly wrapped')
    return image['image_id']


def verify_text_creation(result, arguments, exact_font):
    require(field(result,'is_text') is True and field(result,'text')==arguments['text']
            and field(result,'font')==exact_font and field(result,'font_size')==arguments['size'],
            'Native editable text creation differs from requested content/font/pixel size')


def select_font_face(result):
    """Select one explicit observed regular face; never alias or silently substitute."""
    names=field(result,'fonts')
    count=field(result,'match_count')
    truncated=field(result,'truncated')
    require(isinstance(names,list) and len(names)<=256
            and all(isinstance(value,str) and 0<len(value)<=256 for value in names),
            'Native font discovery returned an invalid bounded name list')
    require(type(count) is int and 0<=count<=100000 and type(truncated) is bool,
            'Native font inventory count/truncation readback missing')
    require(truncated is False and count==len(names),
            'Native font inventory is incomplete; cannot classify exact face availability')
    require(len(set(names))==len(names), 'Native font names are ambiguous duplicates')
    require(FONT_FACE in names, 'Explicit native regular face DejaVu Sans Book is unavailable')
    return FONT_FACE


class Native:
    def __init__(self, run, session):
        self.run, self.session, self.catalog = run, session, {}
        self.assets = []

    async def discover(self):
        found, cursor, pages = {}, None, 0
        while True:
            self.run.budget()
            page = await self.session.list_tools(cursor=cursor)
            self.run.trace({'kind':'tools/list','request_cursor':cursor,
                            'response':page.model_dump(mode='json')})
            found.update({tool.name:tool.model_dump(mode='json') for tool in page.tools})
            cursor=page.nextCursor; pages+=1
            require(pages <= 32, 'Unexpected tools pagination length')
            if not cursor:
                self.catalog = found
                return

    def actual(self, logical):
        names=[name for name in self.catalog if name == logical or name.endswith('__'+logical)]
        require(len(names) == 1, 'Missing/ambiguous discovered tool: '+logical)
        return names[0]

    async def call(self, logical, args):
        import jsonschema
        self.run.budget()
        name=self.actual(logical)
        jsonschema.validate(args,self.catalog[name]['inputSchema'])
        if logical in getattr(self, 'source_schemas', {}):
            jsonschema.validate(args,self.source_schemas[logical])
        # Keep arguments before awaiting a native call, including failed/uncertain calls.
        self.run.trace({'kind':'tools/call-request','tool':name,'arguments':args})
        raw=(await self.session.call_tool(name,args)).model_dump(mode='json')
        self.run.trace({'kind':'tools/call','tool':name,'arguments':args,'response':raw})
        require(not raw.get('isError'), 'MCP tool error: '+name)
        payload=unwrap(raw)
        require(not has_failure(payload), 'Tool returned failure: '+name)
        return payload

    async def complete(self, logical, args):
        result=await self.call(logical,args)
        job=field(result,'job_id')
        if job is None:
            return result
        began=time.monotonic()
        while time.monotonic()-began < 180:
            state=await self.call('jobs_get_status',{'job_id':job,'include_result':True})
            terminal=field(state,'status')
            if terminal == 'completed':
                require(not has_failure(state), 'Failure inside completed native job')
                return state
            require(terminal not in ('failed','cancelled','interrupted'),
                    'Native job terminal failure: '+str(terminal))
            await asyncio.sleep(.2)
        raise TimeoutError('Native job deadline reached; no mutation replay')

    async def inspect(self, image_id):
        result=await self.complete('inspect_image',{'image_id':image_id,'include_metadata':True})
        info=image_from_result(result)
        for key in ('name','file_name','file_path_allowed','selected_layer_ids'):
            info[key]=field(result,key)
        require(info['bridge_owned_display'] is True, 'Unexpected foreign image')
        return info

    async def images(self):
        rows=field(await self.complete('list_images',{}),'images')
        require(isinstance(rows,list), 'Missing native image inventory')
        return [row['image_id'] for row in rows]

    async def checkpoint(self, image_id, name):
        path=self.run.root/name
        require(not path.exists(), 'Checkpoint must be new; never overwrite originals')
        before=await self.inspect(image_id)
        result=await self.complete('save_image',{'image_id':image_id,'path':str(path),'overwrite':False})
        require(path.read_bytes().startswith(b'gimp xcf') and field(result,'sha256') == sha(path),
                'Native XCF checkpoint hash/header mismatch')
        after=await self.inspect(image_id)
        require(after['dirty'] is False and canonical_image(after) == canonical_image(before),
                'Checkpoint changed editable structure or failed to clean image')
        require(after['selected_layer_ids'] == before['selected_layer_ids'],
                'Checkpoint changed selected layers')
        text_evidence=verify_text_saved(path,after)
        self.run.write(name+'.proof.json',{'xcf_sha256':sha(path),
                       'native_saved_structure':after,'text_parasites':text_evidence,
                       'save_state_changes':difference(before,after)})
        return path,after

    async def export(self, image_id, name):
        path=self.run.root/name
        before=await self.inspect(image_id)
        result=await self.complete('export_image',{'image_id':image_id,'path':str(path),'overwrite':False})
        require(field(result,'sha256') == sha(path), 'Native export hash differs')
        after=await self.inspect(image_id)
        require(canonical_image(after) == canonical_image(before), 'Export changed editable structure')
        require(after['selected_layer_ids'] == before['selected_layer_ids'], 'Export changed selected layers')
        # Export may change metadata, dirty state, timestamps and file association.
        self.run.write(name+'.export-state.json',{'state_changes':difference(before,after),
                       'native_structure_equal':True,'selected_layers_equal':True,
                       'selection_mask_preservation_independently_qualified':False,
                       'container_sha256':sha(path),'png_facts':png_facts(path)})
        return path,decode_png(path)

    async def preview(self, image_id, name, size):
        before=await self.inspect(image_id)
        ids=await self.images()
        active=active_image_id(await self.complete('get_active_image',{}))
        path=self.run.root/name
        result=await self.complete('export_preview',{'image_id':image_id,'path':str(path),
                                   'max_width':size,'max_height':size,'overwrite':False})
        require(field(result,'output_dimensions') == [size,size], 'Native preview dimensions differ')
        require(field(result,'published') is True and field(result,'interpolation') == 'nohalo',
                'Preview native publication/interpolation unverified')
        for key in ('temporary_image_deleted','context_restored'):
            require(field(result,key) is True, 'Native preview cleanup not attested')
        require(field(result,'source_image_mutated') is False and field(result,'upscaled') is False,
                'Native preview source/upscale contract failed')
        fingerprint=field(result,'source_state_sha256')
        require(isinstance(fingerprint,str) and re.fullmatch(r'[0-9a-f]{64}',fingerprint),
                'Missing native preview source-state digest')
        require(field(result,'sha256') == sha(path), 'Preview file digest differs')
        after=await self.inspect(image_id)
        require(before == after and ids == await self.images(), 'Preview changed source or image inventory')
        require(active == active_image_id(await self.complete('get_active_image',{})),
                'Preview changed active image')
        require(not list(self.run.root.glob('.dcc-preview-*')), 'Preview staging retained')
        pixels=decode_png(path)
        require(pixels[:2] == (size,size), 'Decoded native preview dimensions differ')
        self.run.write(name+'.proof.json',{'source_before_after_equal':True,
                       'active_image_id_before_after':active,
                       'source_state_sha256':fingerprint,'selected_layers_equal':True,
                       'selection_mask_check':'Native export_preview internally compares its full source fingerprint',
                       'independent_selection_mask_readback_available':False,
                       'native_text_and_metadata_equal':True,'png_facts':png_facts(path),
                       'visual_review':'PENDING_HUMAN_OR_IMAGE_INSPECTION'})
        return path,pixels

    async def close(self, image_id):
        info=await self.inspect(image_id)
        require(info['dirty'] is False and info['bridge_owned_display'] is True, 'Refuse dirty/foreign close')
        result=await self.complete('close_image',{'image_id':image_id,'discard_changes':False})
        require(field(result,'closed') is True and field(result,'discarded_changes') is False,
                'Owned clean close failed')

    async def fixture(self):
        """Qualify exactly the shape/mode/property/fill operations this pilot needs."""
        made=await self.complete('create_image',{'width':96,'height':96,'name':'fixture substrate',
                                               'background_color':[0,0,0,0]})
        image_id=field(made,'image_id'); substrate=field(made,'created_layer_id')
        require(type(image_id) is int and type(substrate) is int, 'Fixture native IDs unavailable')
        await self.complete('fill_layer',{'image_id':image_id,'layer_id':substrate,'color':[80,120,200,128]})
        _,filled=await self.export(image_id,'fixture-fill-rgba.png')
        require(all(near(list(filled[2][i:i+4]),[80,120,200,128])
                    for i in range(0,len(filled[2]),4)), 'Native fill encoded RGBA/alpha differs')
        await self.complete('fill_layer',{'image_id':image_id,'layer_id':substrate,'color':[0,0,0,0]})
        _,clear=await self.export(image_id,'fixture-fill-clear.png')
        require(set(clear[2][3::4]) == {0}, 'Native clear fill did not preserve transparent alpha')
        shapes=[
            {'name':'fixture rectangle','shape':'rectangle','bounds':[8,8,64,64], 'color':[200,160,120,255]},
            {'name':'fixture ellipse','shape':'ellipse','bounds':[44,40,36,36], 'color':[48,119,120,128]},
            {'name':'fixture polygon','shape':'polygon','points':[[12,12],[64,12],[38,64]],'color':[224,108,65,255]}]
        layer_ids=[]
        for shape in shapes:
            made=await self.complete('create_layer',{'image_id':image_id,'name':shape['name']})
            layer_id=field(made,'layer_id'); layer_ids.append(layer_id)
            before=await self.inspect(image_id)
            result=await self.complete('paint_shape',{'image_id':image_id,'layer_id':layer_id,
                                       **{k:v for k,v in shape.items() if k != 'name'}})
            after=await self.inspect(image_id)
            require(field(result,'painted') is True, 'Native paint not attested')
            require(after['selected_layer_ids'] == before['selected_layer_ids'], 'Paint changed selected layers')
        _,normal=await self.export(image_id,'fixture-shapes-normal.png')
        require(near(pixel(normal,10,10),[200,160,120,255]), 'Rectangle sample differs')
        require(near(pixel(normal,38,20),[224,108,65,255]), 'Polygon sample differs')
        require(near(pixel(normal,76,56),[48,119,120,128]), 'Ellipse straight-alpha sample differs')
        require(pixel(normal,0,0)[3] == 0 and pixel(normal,90,90)[3] == 0, 'Shapes leaked to corners')
        require(any(0<a<255 for a in normal[2][3::4]), 'Native alpha edges missing')
        polygon=layer_ids[-1]
        await self.complete('set_layer_mode',{'image_id':image_id,'layer_id':polygon,'mode':'multiply'})
        mode_info=await self.inspect(image_id)
        require(next(r for r in mode_info['layers'] if r['layer_id']==polygon)['mode']=='multiply',
                'Native multiply mode readback differs')
        _,multiplied=await self.export(image_id,'fixture-multiply.png')
        require(pixel(multiplied,38,20) != pixel(normal,38,20), 'Multiply did not alter overlap pixels')
        await self.complete('set_layer_mode',{'image_id':image_id,'layer_id':polygon,'mode':'normal'})
        await self.complete('set_layer_properties',{'image_id':image_id,'layer_id':polygon,
                            'name':'fixture renamed polygon','visible':False,'locked':True,'opacity':50})
        properties=await self.inspect(image_id)
        row=next(r for r in properties['layers'] if r['layer_id']==polygon)
        require(row['name']=='fixture renamed polygon' and row['visible'] is False
                and row['locked'] is True and row['opacity']==50 and row['mode']=='normal',
                'Native layer properties differ')
        _,hidden=await self.export(image_id,'fixture-properties-hidden.png')
        require(near(pixel(hidden,38,20),[200,160,120,255]), 'Hidden layer still contributes pixels')
        await self.complete('set_layer_properties',{'image_id':image_id,'layer_id':polygon,
                            'name':'fixture polygon','visible':True,'locked':False,'opacity':50})
        _,half=await self.export(image_id,'fixture-properties-half-opacity.png')
        require(pixel(half,38,20) != pixel(normal,38,20) and pixel(half,38,20) != pixel(hidden,38,20),
                '50-percent opacity did not affect actual pixels')
        await self.complete('set_layer_properties',{'image_id':image_id,'layer_id':polygon,'opacity':100})
        _,restored=await self.export(image_id,'fixture-properties-restored.png')
        require(restored == normal, 'Property/mode reset did not restore all decoded RGBA')
        path,info=await self.checkpoint(image_id,'fixture-qualified.xcf')
        baseline=canonical_image(info); source_sha=sha(path)
        await self.close(image_id)
        reopened=field(await self.complete('open_image',{'path':str(path)}),'image_id')
        loaded=await self.inspect(reopened)
        require(canonical_image(loaded)==baseline, 'Fixture XCF reopen changed native properties')
        require(selected_names(loaded)==selected_names(info), 'Fixture XCF reopen changed selected layer names')
        _,again=await self.export(reopened,'fixture-reopened.png')
        require(again==normal and sha(path)==source_sha, 'Fixture reopen changed pixels or saved source bytes')
        await self.checkpoint(reopened,'fixture-reopened-checkpoint.xcf')
        await self.close(reopened)
        proof={'status':'PASS_TINY_NATIVE_TYPED_OPERATIONS', 'canvas':[96,96],
               'qualified_shapes':['rectangle','ellipse','polygon'],
               'qualified_modes':['normal','multiply'],
               'qualified_properties':['name','visible','locked','opacity'],
               'fill_encoded_rgba_and_alpha_checked':True,
               'paint_selected_layer_ids_preserved':True,
               'paint_selection_mask_bytes_preservation_qualified':False,
               'paint_selection_mask_limit':'Not independently exposed by the typed catalog',
               'fixture_full_rgba_reopen_equal':True,
               'native_text_tested':False,'unused_modes_or_feather_qualified':False}
        self.run.write('fixture-qualification.json',proof)
        require(await self.images()==[], 'Fixture did not release its native images')

    async def asset(self, asset):
        name=asset['id']
        native_font=None
        if asset['editable_text']:
            fonts=await self.complete('list_fonts',{'query':FONT_FAMILY,'limit':256})
            native_font=select_font_face(fonts)
            names=field(fonts,'fonts')
            self.run.write(name+'-native-font-discovery.json',{
                'query':FONT_FAMILY,'limit':256,'native_names':names,'chosen_exact_name':native_font,
                'match_count':field(fonts,'match_count'),'truncated':field(fonts,'truncated'),
                'explicit_selection':'Observed Book face for the planned DejaVu Sans regular upright family',
                'silent_fallback_used':False,'selection_policy':'font-policy.json',
                'source':'Actual typed native list_fonts response',
                'font_file_bundled':False,'notice_reference':'DejaVu-font-notice.txt'})
        self.run.write(name+'-checkpoint.json',{'status':'AUTHORING_STARTED','asset_id':name,
                       'planned_shape_layers':len(asset['layers_bottom_to_top'])})
        operations=authoring_operations(asset)
        made=await self.complete(*operations[0])
        image_id=field(made,'image_id'); current_layer=None
        require(type(image_id) is int, 'Missing authored image ID')
        for tool,template in operations[1:]:
            args={**template,'image_id':image_id}
            if tool == 'paint_shape':
                args['layer_id']=current_layer
            elif tool == 'create_text':
                require(native_font is not None and args['font']==native_font,
                        'Text attempted before exact native font discovery')
            result=await self.complete(tool,args)
            if tool == 'create_layer':
                current_layer=field(result,'layer_id')
                require(type(current_layer) is int, 'Missing native shape layer ID')
            elif tool == 'create_text':
                verify_text_creation(result,args,native_font)
        info=await self.inspect(image_id)
        expected_names=[t['name'] for t in reversed(asset['editable_text'])]
        expected_names += [x['name'] for x in reversed(asset['layers_bottom_to_top'])] + ['transparent substrate']
        require([r['name'] for r in info['layers']] == expected_names, 'Authored layer order/names differ')
        require(sum(r['is_text'] for r in info['layers']) == len(asset['editable_text']), 'Native text count differs')
        for expected in asset['editable_text']:
            actual=next(row for row in info['layers'] if row['name']==expected['name'])
            require(actual['is_text'] and actual['text']==expected['text']
                    and actual['text_font']==native_font and actual['offsets']==[expected['x'],expected['y']],
                    'Native text content/font/placement readback differs')
        require(all(r['parent_id'] is None and not r['is_group'] and r['visible']
                    and not r['locked'] and r['opacity']==100 for r in info['layers']),
                'Unexpected authoring layer properties')
        xcf,saved=await self.checkpoint(image_id,asset['source_file'])
        xcf_sha=sha(xcf); canonical=canonical_image(saved)
        png,pixels=await self.export(image_id,asset['output_file'])
        # The stamp's outer silhouette has exact integer/axis-aligned edges.
        # Its antialiased interior artwork is composited over an opaque stamp.
        # Binary source alpha is therefore valid; counts are still measured.
        facts=assert_asset_png(png,require_fractional=name!='orbital-stamp')
        previews=[]
        for size in (128,64):
            preview,_=await self.preview(image_id,f'{name}-{size}.png',size)
            previews.append(preview.name)
        _,post_preview=await self.export(image_id,name+'-after-previews.png')
        require(pixels==post_preview and sha(xcf)==xcf_sha, 'Preview cycle changed source pixels/file')
        await self.checkpoint(image_id,name+'-after-export-checkpoint.xcf')
        await self.close(image_id)
        reopened=field(await self.complete('open_image',{'path':str(xcf)}),'image_id')
        loaded=await self.inspect(reopened)
        require(canonical_image(loaded)==canonical, 'Asset XCF reopen changed editable native structure')
        require(selected_names(loaded)==selected_names(saved), 'Asset XCF reopen changed selected layer names')
        text_saved=verify_text_saved(xcf,loaded)
        _,again=await self.export(reopened,name+'-reopened.png')
        require(pixels==again and sha(xcf)==xcf_sha, 'Asset XCF reopen pixel/source-file mismatch')
        self.run.write(name+'-reopen-state.json',{'saved':saved,'loaded':loaded,
                       'canonical_native_structure_equal':True,
                       'selected_layer_names_equal':True,
                       'metadata_changes':difference(saved.get('metadata',{}),loaded.get('metadata',{})),
                       'native_text':text_saved,'decoded_rgba_equal':True,
                       'png_container_byte_identity_claimed':False,
                       'authoring_xcf_bytes_preserved':True})
        await self.checkpoint(reopened,name+'-reopened-checkpoint.xcf')
        await self.close(reopened)
        composites=[]
        for label,color in BACKGROUNDS.items():
            image=field(await self.complete('open_image',{'path':str(xcf)}),'image_id')
            before=await self.inspect(image)
            require(canonical_image(before)==canonical, 'Composite source reopen differs')
            substrate=next(row['layer_id'] for row in before['layers'] if row['name']=='transparent substrate')
            await self.complete('fill_layer',{'image_id':image,'layer_id':substrate,'color':color})
            composite,composite_pixels=await self.export(image,f'{name}-{label}.png')
            require(set(composite_pixels[2][3::4])=={255}, 'Native background composite is not opaque')
            require(near(pixel(composite_pixels,0,0),color), 'Native composite corner differs from requested background')
            for size in (128,64):
                small,_=await self.preview(image,f'{name}-{label}-{size}.png',size)
                composites.append(small.name)
            composite_xcf,_=await self.checkpoint(image,f'{name}-{label}-composite.xcf')
            composites.extend([composite.name,composite_xcf.name])
            await self.close(image)
            require(sha(xcf)==xcf_sha, 'Composite modified authoring XCF')
        metadata={'asset_id':name,'purpose':asset['meaning'],'width_px':512,'height_px':512,
                  'pixel_format':'RGBA / 8 bits per channel / straight alpha',
                  'alpha_min_max':facts['alpha_min_max'],
                  'alpha_edge_count':facts['fractional_edge_count'],
                  'encoded_color_space':facts['encoded_color_space_chunks'],
                  'alpha_edge_expectation':('Fractional alpha measured but not required: integer-aligned stepped outer silhouette; no artwork change to manufacture edge alpha.'
                                            if name=='orbital-stamp' else 'Fractional alpha required and measured for this silhouette/shadow.'),
                  'png_readback':facts,'native_asset':xcf.name,'native_layer_names':expected_names,
                  'native_shape_layer_count':len(asset['layers_bottom_to_top']),
                  'native_editable_text_count':len(asset['editable_text']),
                  'source_xcf_sha256':xcf_sha,'png_sha256':sha(png),'rgba_sha256':rgba_sha(pixels),
                  'native_color_profile':loaded['color_profile'],
                  'native_typed_color_encoding':loaded['typed_color_encoding'],
                  'colorspace_equality_across_apps_claimed':False,
                  'rights_source':'Original artwork; rights reserved. No MIT/CC0 artwork grant.',
                  'font_notice':('DejaVu Sans Book used for this asset’s native text only; see DejaVu-font-notice.txt. No font file bundled.'
                                 if asset['editable_text'] else 'No font glyphs used in this asset.'),
                  'native_font_discovered':native_font,
                  'text_size_evidence':('create_text returns the requested pixel size; inspect_image does not independently expose size. Saved text metadata and preview fingerprints verify persistence.'
                                        if asset['editable_text'] else 'Not applicable; no text in this asset.'),
                  'mcp_recipe_reference':'reproduce_orbit.py + orbit_workflow.py + design.json',
                  'method':'Typed native GIMP MCP paint_shape on separate editable layers; native save/reopen/export',
                  'preview_files':previews,'native_background_composites':composites,
                  'technical_gates':'PASSED_FOR_THIS_ASSET',
                  'visual_qa':'PENDING_ACTUAL_128PX_64PX_AND_DARK_LIGHT_INSPECTION',
                  'cross_app_godot_native_gate':'NOT_EXECUTED',
                  'full_kit_complete':False,'showcase_completion_count_contribution':0}
        self.run.write(name+'-metadata.json',metadata)
        self.run.write(name+'-checkpoint.json',{'status':'TECHNICAL_GATES_PASSED_VISUAL_REVIEW_PENDING',
                       'asset_id':name,'xcf_sha256':xcf_sha,'png_sha256':sha(png)})
        self.assets.append(metadata)
        self.run.write('pilot-progress.json',{'completed_technical_assets':[a['asset_id'] for a in self.assets],
                       'visual_review_pending':True,'full_kit_complete':False})
        require(await self.images()==[], 'Sequential asset left native images open')


async def workflow(run, status):
    import httpx
    import yaml
    from mcp import ClientSession
    from mcp.client.streamable_http import streamable_http_client
    # Keep HTTPX environment-aware. Never bypass configured proxy/auth policy.
    async with httpx.AsyncClient(timeout=httpx.Timeout(120,read=180)) as http:
        async with streamable_http_client(run.server.mcp_url,http_client=http) as (read,write,_):
            async with ClientSession(read,write) as session:
                run.trace({'kind':'initialize','response':(await session.initialize()).model_dump(mode='json')})
                native=Native(run,session)
                await native.discover()
                await native.call('search_skills',{'query':'gimp'})
                await native.call('get_skill_info',{'skill_name':'gimp-session'})
                await native.call('load_skill',{'skill_name':'gimp-session'})
                await native.discover()
                run.write('discovered-tool-catalog.json',native.catalog)
                source=yaml.safe_load((Path(run.package_root)/'skills/gimp-session/tools.yaml').read_text())['tools']
                native.source_schemas={row['name']:row['input_schema'] for row in source}
                observed=json.loads((PREP/'observed-native-schemas.json').read_text())
                for row in source:
                    actual=native.catalog[native.actual(row['name'])]['inputSchema']
                    require(actual==observed[row['name']], 'Runtime schema differs from observed pinned schema: '+row['name'])
                run.write('schema-normalization.json', {
                    'source_schema_validation_also_enforced':True,
                    'known_runtime_omission':'paint_shape inputSchema omits source allOf conditions',
                    'invented_capabilities':False})
                current=await native.complete('get_status',{})
                for key in ('gimp_pid','plugin_pid','main_thread_id','plugin_module_path','allowed_roots','gimp_version'):
                    require(field(current,key)==status[key], 'Native identity changed: '+key)
                require(field(current,'command_count')==25, 'Typed native catalog count differs')
                require(await native.images()==[], 'Owned host is not fresh')
                await native.fixture()
                design=json.loads((PREP/'design.json').read_text())
                assets={a['id']:a for a in design['assets']}
                selected=run.asset_ids
                for asset_id in selected:
                    await native.asset(assets[asset_id])
                require(len({asset['rgba_sha256'] for asset in native.assets})==len(selected),
                        'Distinct assets have identical decoded RGBA')
                return {'status':'PASS_STANDALONE_NATIVE_BATCH_VISUAL_REVIEW_REQUIRED',
                        'batch_id':run.batch_id,'native_asset_ids':list(selected),'planned_asset_count':8,
                        'completed_native_asset_count':len(selected),
                        'native_shape_layers':sum(len(assets[a]['layers_bottom_to_top']) for a in selected),
                        'native_editable_text_layers':sum(len(assets[a]['editable_text']) for a in selected),
                        'native_MCP_events':run.events,
                        'visual_review':'PENDING','full_D058_acceptance':False,
                        'cross_app_godot_native_gate':'NOT_EXECUTED',
                        'showcase_completion_count_contribution':0,
                        'artifact_names':sorted(p.name for p in run.root.iterdir()
                            if p.is_file() and p.suffix in ('.xcf','.png')),
                        'preclose_checkpoint_artifacts':[]}
