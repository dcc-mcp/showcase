# Orbit Post Office standalone reproduction

The prior standalone recipe completed four fresh GIMP runs for all eight approved
asset IDs: 76 native shape layers and two editable text layers. This new revision
changes documentation and reviewed source identity only. All Python helpers, design
bytes and creative call arguments remain unchanged. The merged adapter source is
byte-identical to the qualified public head and rebuilds the exact qualified wheel.
See ../REPRODUCE.md and ../qualification-continuity.json. No new native run of this
revision or merged commit is claimed; historical proof remains under ../history/.

## Explicit operator inputs

Provide an exact reviewed adapter source directory, complete wheel and adapter-only
binding JSON. The corresponding runtime must already be installed. There is no
automatic installation, network download or source substitution.

```sh
python -B reproduce_orbit.py --check \
  --adapter-source /your/reviewed/adapter-source \
  --adapter-wheel /your/reviewed/dcc_mcp_gimp-0.4.1-py3-none-any.whl \
  --adapter-binding adapter-bindings/merged-943e2cd.json
```

All 69 source files, 42 installed package files, the complete wheel, imported
package location/caches and recipe/helper bytes must match. The current reviewed
binding is merged commit 943e2cd6855da6f4876032bc124556e3eac54bc9, tree
300e1eacf12871b9e7cc10297653718a40e97d22. This is exactly the tree of public
PR 15 head aa519354a568dfe1f6ec4ce96385e6cf3bd29638, used for the four fresh
standalone runs. Earlier production
native proofs identify a3b45aaa237aef954247c8571fb0762afe5cface. Their runtime and
whole wheel are byte-identical, but their complete source trees differ in a test
file; those source identities are not interchangeable. A future merge identity
requires its own reviewed binding. The current merge has that explicit binding.

Source identity covers the 69 declared tracked files; unrelated source-directory
cache files are not execution inputs. The installed package has a closed inventory,
verified caches and a fresh bytecode lookup prefix before native runtime imports.
The CLI sets a separate fresh lookup prefix before importing its project helpers;
bytecode writes are disabled. Use a fresh CLI process rather than an embedded
interpreter with previously imported helpers or adapter/Core modules.

No D015 artwork, master, baseline, old candidate recipe or original-run directory
is a runtime input. Reusable helper origins are recorded by hash. The adapter-only
binding contains source/package/wheel identities, without historical example inputs.

## Bounded native execution

After confirming exclusive ownership of the serial GUI lane, add `--run`, a fresh `--run-root`
and exactly one batch: `envelopes`, `stamp-and-dispatch`, `arrival-and-parcel`, or
`delivery-status`. All eight creative authoring sequences total 162 typed calls.
Each batch starts the qualified tiny fixture, then authors two assets sequentially.

After four real completed runs, `verify_kit_runs.py` accepts their four explicit
`--run-root` inputs and a fresh `--output` path. It refuses historical/partial runs,
mixed bindings, repeated roles and changed artifacts, and recomputes native source
readbacks. It cannot substitute for independent selected-trace reconstruction or
actual visual approval, and cannot claim the engine gate.

Limits remain one GIMP host, two allowed CPUs, 600 seconds, a 256 MiB aggregate
output stopping budget and 1 GiB free floor. Gateway/failover/telemetry remain off.
HTTPX remains environment-aware. The owned host is stopped with ordinary SIGTERM;
exit code 1 and native warnings remain observations distinct from wrapper success.

Every source has named editable layers, native save/reopen, full decoded RGBA
checks, native 128/64px previews and dark/light native composites. Export metadata
changes are distinguished from pixel and structure preservation. Native text
requires fresh complete discovery of exact DejaVu Sans Book; no face fallback is
allowed. The stamp has a valid binary-alpha outer silhouette, and OP/07 is decorative
microtype at 64px. Paint selection-mask bytes and cross-app color equality remain
independently unqualified.

## Evidence and validation

Selected-evidence normalization is a separate file-only operation with explicitly
supplied trace/run paths. Full raw traces and source crosswalks remain private.
Public selected records must preserve actual arguments/results while normalizing
only declared paths and volatile IDs, and must be independently reconstructed from
their original requests and completed jobs. Historical V2 remains a stopped batch
with one separately accepted sealed component.

Run host-free tests with explicit `D058_TEST_ADAPTER_SOURCE`,
`D058_TEST_ADAPTER_WHEEL` and `D058_TEST_ADAPTER_BINDING` environment variables.
The unchanged historical binding tests explicitly assert public head aa519354;
set D058_TEST_ADAPTER_BINDING to adapter-bindings/public-aa519354.json for that
test suite, using the same byte-identical merged source and wheel. Check the new
merged-943e2cd binding separately with the documented CLI --check command. Tests
cover relocation, source-test-file/wheel corruption, unreviewed bindings and an
audited check-mode process that forbids native/network activity and unrelated
input reads.

The four recorded GIMP runs establish the tested-environment reproduction milestone.
This revision inherits that evidence through unchanged executable/design bytes; it
is not a new native run, cross-machine qualification, Godot integration or site
publication. Those separate claims require their own execution and review.

seal_recipe.py is retained historical qualification-maintenance code. Do not run it
as a reproduction step or to accept changed source, wheel, helper or artwork bytes.
