# Orbit Post Office standalone reproduction

This implementation is being checked without launching GIMP. It preserves the
eight approved asset IDs and exact design bytes: 76 native shape layers and two
editable text layers. A fresh all-eight native reproduction remains required.
Historical original outputs and frozen V3 are unchanged.

## Explicit operator inputs

Provide an exact reviewed adapter source directory, complete wheel and adapter-only
binding JSON. The corresponding runtime must already be installed. There is no
automatic installation, network download or source substitution.

```sh
python -B reproduce_orbit.py --check \
  --adapter-source /your/reviewed/adapter-source \
  --adapter-wheel /your/reviewed/dcc_mcp_gimp-0.4.1-py3-none-any.whl \
  --adapter-binding adapter-bindings/public-aa519354.json
```

All 69 source files, 42 installed package files, the complete wheel, imported
package location/caches and recipe/helper bytes must match. The current reviewed
binding is public PR 15 head aa519354a568dfe1f6ec4ce96385e6cf3bd29638. Historical
native proofs identify a3b45aaa237aef954247c8571fb0762afe5cface. Their runtime and
whole wheel are byte-identical, but their complete source trees differ in a test
file; those source identities are not interchangeable. A future merge identity
requires its own reviewed binding.

Source identity covers the 69 declared tracked files; unrelated source-directory
cache files are not execution inputs. The installed package has a closed inventory,
verified caches and a fresh bytecode lookup prefix before native runtime imports.
The CLI sets a separate fresh lookup prefix before importing its project helpers;
bytecode writes are disabled. Use a fresh CLI process rather than an embedded
interpreter with previously imported helpers or adapter/Core modules.

No D015 artwork, master, baseline, old candidate recipe or original-run directory
is a runtime input. Reusable helper origins are recorded by hash. The adapter-only
binding contains source/package/wheel identities, without historical example inputs.

## Bounded native execution

Only after the parent admits the serial GUI lane, add `--run`, a fresh `--run-root`
and exactly one batch: `envelopes`, `stamp-and-dispatch`, `arrival-and-parcel`, or
`delivery-status`. All eight creative authoring sequences total 162 typed calls.
Each batch starts the qualified tiny fixture, then authors two assets sequentially.

After four real completed runs, `verify_kit_runs.py` accepts their four explicit
`--run-root` inputs and a fresh `--output` path. It refuses historical/partial runs,
mixed bindings, repeated roles and changed artifacts, and recomputes native source
readbacks. It cannot substitute for independent selected-trace reconstruction or
actual visual approval, and cannot claim the engine gate.

Limits remain one GIMP host, two allowed CPUs, 600 seconds, a 256 MiB aggregate
output stopping budget and 1 GiB free floor. Gateway/failover/telemetry remain off.
HTTPX remains environment-aware. The owned host is stopped with ordinary SIGTERM;
exit code 1 and native warnings remain observations distinct from wrapper success.

Every source has named editable layers, native save/reopen, full decoded RGBA
checks, native 128/64px previews and dark/light native composites. Export metadata
changes are distinguished from pixel and structure preservation. Native text
requires fresh complete discovery of exact DejaVu Sans Book; no face fallback is
allowed. The stamp has a valid binary-alpha outer silhouette, and OP/07 is decorative
microtype at 64px. Paint selection-mask bytes and cross-app color equality remain
independently unqualified.

## Evidence and validation

Selected-evidence normalization is a separate file-only operation with explicitly
supplied trace/run paths. Full raw traces and source crosswalks remain private.
Public selected records must preserve actual arguments/results while normalizing
only declared paths and volatile IDs, and must be independently reconstructed from
their original requests and completed jobs. Historical V2 remains a stopped batch
with one separately accepted sealed component.

Run host-free tests with explicit `D058_TEST_ADAPTER_SOURCE`,
`D058_TEST_ADAPTER_WHEEL` and `D058_TEST_ADAPTER_BINDING` environment variables.
Binding tests include relocation, source-test-file/wheel corruption, unreviewed
bindings and an audited check-mode process that forbids native/network activity
and unrelated input reads.

Neither this implementation nor the component continuity ZIP establishes fresh
all-eight portability, native Godot integration or site publication. Those gates
require actual separately recorded execution and review.
