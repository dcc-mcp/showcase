# Reproduce the qualified GIMP workflow

Use new directories throughout. Preserve the component manifest and frozen recipe checks. Commands below prepare software and run the author's recipe; review them before executing. The recipe itself never installs, downloads or silently substitutes software or fonts.

## 1. Prepare the supported platform

The demonstrated environment is Linux x86_64, CPython 3.12.14 and zlib 1.3.2. The exact compressed-wheel digest was qualified with that Python/zlib combination. The native recipe uses Linux affinity APIs and fcntl and launches `/usr/bin/gimp`; this is not a Windows/macOS reproduction recipe.

Provide GIMP 3.0.4 at `/usr/bin/gimp`, a working ordinary graphical DISPLAY, GIMP's Python 3 plug-in support with the Gimp 3.0, Gegl 0.4, Gio and GLib GI namespaces, and a system Python capable of importing those namespaces. The bundled bridge's shebang uses `/usr/bin/env python3`; the recipe explicitly prepends `/usr/bin:/bin` to the host PATH so its system Python must supply GI support. The recipe's separate orchestration environment does not itself install GIMP or GI. Use the native application's official installation workflow and a graphical session supported by that installation. Native application binaries are not included.

Provide DejaVu Sans Book. The recipe requires fresh complete native font discovery and rejects missing, ambiguous or truncated discovery; no fallback face is accepted. `recipe/font-policy.json` records the supporting font-file SHA-256 `57f73e11f51999432bf7ab22ce55b6f945d5eca1bf824404cfa9ec2e3718c84e`, but that hash is not proof of the exact file GIMP resolves. The scoped notice is `recipe/DejaVu-font-notice.txt`; no font binary is bundled. Other font/platform builds have not been shown to yield identical pixels. OP/07 remain editable at 27px and decorative microtype at 64px.

Native admission requires two allowed CPUs, no other GIMP/ParaView/Godot host using the serial lane, working loopback networking, and more than 1 GiB plus 256 MiB free before a run. Each run has one owned host, a 600-second deadline, a 256 MiB aggregate output stopping threshold and a 1 GiB reserve. The threshold is not a hard filesystem quota. Existing HTTPX proxy/environment behavior is retained, including SOCKS support; no proxy bypass is introduced.

## 2. Obtain the exact public source

From this component directory, create a fresh source checkout:

```sh
git init source
git -C source fetch --depth=1 https://github.com/dcc-mcp/dcc-mcp-gimp.git 943e2cd6855da6f4876032bc124556e3eac54bc9
git -C source checkout --detach FETCH_HEAD
git -C source rev-parse HEAD HEAD^{tree}
```

The two output lines must be:

```text
943e2cd6855da6f4876032bc124556e3eac54bc9
300e1eacf12871b9e7cc10297653718a40e97d22
```

This is the merged source of [GIMP PR #15](https://github.com/dcc-mcp/dcc-mcp-gimp/pull/15). Its 69 tracked files exactly match the aa519354 public head used for the four completed standalone runs. `recipe/adapter-bindings/merged-943e2cd.json` binds that source, all 42 package files and the entire wheel. A complete exported snapshot of this source also works because recipe admission verifies file contents rather than requiring a Git directory. Do not use a floating branch or substitute an arbitrary package release.

## 3. Rebuild the exact adapter wheel

`build-requirements.txt` pins build 1.6.1, Hatchling 1.32.4, packaging 26.3, pathspec 1.1.1, pluggy 1.6.0, pyproject-hooks 1.3.3, tomlkit 0.15.1 and trove-classifiers 2026.9.21.13. Use the demonstrated Python/zlib combination and retain LF source bytes:

```sh
python3.12 -m venv build-env
build-env/bin/python -m pip install -r build-requirements.txt
SOURCE_DATE_EPOCH=1580601600 PYTHONDONTWRITEBYTECODE=1 \
  build-env/bin/python -B -m build --no-isolation --outdir dist source
sha256sum dist/dcc_mcp_gimp-0.4.1-py3-none-any.whl
```

This builds an sdist and then its wheel. Expected result: 97,073 bytes; SHA-256 `adb43849349ca54944bd9280a8497d90bca77e6726733c3fca5991164fe1a1ad`. All wheel ZIP timestamps are 2020-02-02 00:00:00. A fresh exact-merge build independently reproduced these bytes using `--no-isolation` and already installed build inputs, without installing dependencies. The outer build interpreter rejected socket audit events; that hook is not a whole-process-tree network capture. That check used already available exact build dependencies; the commands above give a new operator the ordinary package-registry preparation route. Current registry availability and a completely new machine's installation are not independently certified by this component.

Stop if the size or digest differs. Compare source files, Python/zlib and build-tool versions. Do not edit a binding, relax a hash check or run `recipe/seal_recipe.py` to accept a different output. Neither the adapter's 0.4.1 version string nor equivalent package contents alone satisfy the required whole-wheel check.

## 4. Prepare a separate orchestration runtime

The exact checked runtime versions are Core/server/CLI 0.20.41, MCP SDK 1.30.0, HTTPX 0.28.1 and the locally rebuilt GIMP adapter 0.4.1. The helper imports additionally require psutil 7.2.2, PyYAML 6.0.3 and jsonschema 4.26.0; socksio 1.0.0 supplies the qualified SOCKS transport support. The runtime requirements name those inputs. The complete observed Python distribution list is supplied as constraints for transitive resolution; it does not instruct pip to install unrelated build/test packages.

```sh
python3.12 -m venv runtime-env
runtime-env/bin/python -m pip install \
  --constraint qualified-runtime-constraints.txt \
  --requirement runtime-requirements.txt \
  dist/dcc_mcp_gimp-0.4.1-py3-none-any.whl
```

Use the runtime's explicit Python path without activating it as the native host's default Python. The recipe checks all 42 adapter files across source, wheel and installed package and rejects shadowing, special files and unverified bytecode. Dependencies are obtained from the normal official package registry; no private runtime or copied environment is required by the recipe. This revision did not freshly install that dependency set, and exact transitive/native-platform byte equivalence is not claimed.

## 5. Check, then run four bounded batches

From this component directory, verify files first:

```sh
runtime-env/bin/python -B recipe/reproduce_orbit.py --check \
  --adapter-source source \
  --adapter-wheel dist/dcc_mcp_gimp-0.4.1-py3-none-any.whl \
  --adapter-binding recipe/adapter-bindings/merged-943e2cd.json
```

This check launches no native host and does not establish that DISPLAY, GI, GIMP or fonts work. For each native batch, use the same three explicit adapter arguments and replace `--check` with `--run --batch BATCH --run-root FRESH_DIRECTORY`. Run serially, once each: `envelopes`, `stamp-and-dispatch`, `arrival-and-parcel`, `delivery-status`. Create the output parent beforehand; each run directory must not exist and its basename must start with a letter and use only letters, digits, underscores, dots or hyphens. For example:

```sh
mkdir outputs
runtime-env/bin/python -B recipe/reproduce_orbit.py --run \
  --batch envelopes --run-root outputs/envelopes-01 \
  --adapter-source source \
  --adapter-wheel dist/dcc_mcp_gimp-0.4.1-py3-none-any.whl \
  --adapter-binding recipe/adapter-bindings/merged-943e2cd.json
```

Stop on failure, retain partial output and investigate before another mutation. A wrapper exit of 0 is distinct from GIMP's recorded exit of 1 after requested SIGTERM; the historical native shutdown warnings remain disclosed. No arbitrary code execution through MCP or alternate native control route is part of this workflow.

After all four successful runs:

```sh
runtime-env/bin/python -B recipe/verify_kit_runs.py \
  --run-root outputs/envelopes-01 \
  --run-root outputs/stamp-and-dispatch-01 \
  --run-root outputs/arrival-and-parcel-01 \
  --run-root outputs/delivery-status-01 \
  --output outputs/four-run-closure.json
```

Use fresh runs consistently under this revision; do not mix them with historical recipe/source bindings. Inspect the actual masters and 128/64px previews, including light/dark composites. Native structure and decoded RGBA comparisons distinguish PNG timestamp metadata from image changes. Visual review, source-selection-mask qualification and cross-application color equality remain separate concerns.

Fresh runs produce private raw logical SDK traces and receipts. Selected-evidence normalization/reconstruction takes explicit fresh inputs and a private crosswalk. Preserve private outputs, review selected evidence for publication, and do not publish an entire run directory. Historical inverse reconstruction requires the retained historical originals; public summaries and hashes alone do not reproduce that private audit.
