# Rights and scoped notices

Original Orbit Post Office artwork, game scene/script/content, recipe and data remain rights reserved. This candidate adds no artwork, game-content, MIT or CC0 license grant.

`notices/Godot-MCP-addon-MIT.txt` is the unchanged upstream software notice for `game/addons/dcc_mcp_godot/` and the upstream software scope of the referenced Godot patch. It does not license the original game or art. The GIMP adapter notice is `gimp-reproduction/software/UPSTREAM-ADAPTER-LICENSE.txt`; original recipe/artwork terms remain `gimp-reproduction/recipe/RIGHTS.md`.

`notices/DejaVu-font-notice.txt` preserves the existing font notice. GIMP's orbital-stamp text uses DejaVu Sans Book. No font binaries or native application binaries are included. Existing notices in unchanged reference archives retain their original scope.
