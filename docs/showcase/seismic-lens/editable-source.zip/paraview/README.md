# Seismic Lens: native ParaView views

Copy the entire native/paraview directory together. Open any of its five .pvsm states in ParaView 5.13.2, choosing the adjacent data directory if prompted. The five states use relative data paths. All five copied-state presentations and PNGs were verified with the original input unavailable.

For typed MCP reproduction, follow reproduce/BUILD_AND_RUN.md from this paraview component directory. It identifies the current public source, exact wheel, installed bytes and existing native proof. The code creates a fresh owned host and refuses an existing output root. No arbitrary external state admission through MCP is implied.

input-generation/generate_analytic_input.py is the separately included deterministic original data generator. It creates a new field-refinement-v2 directory beside itself and refuses an existing one. It is input preparation, not a DCC operation or a physics solver. Its hash is recorded by the combined delivery manifest. The separate reproduce/MANIFEST.json retains the exact sealed reproduction packet inventory.

All field coordinates and scalar units are illustrative. The top-level METHODS.md and RIGHTS.md govern the case material; the upstream software notice has its separately identified scope.
